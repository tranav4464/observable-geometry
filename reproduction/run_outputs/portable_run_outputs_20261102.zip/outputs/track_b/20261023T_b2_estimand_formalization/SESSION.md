# B2 estimand formalization audit

**Gate:** B2, IN_PROGRESS  
**Decision this work may change:** whether the active held-load task has a complete, mathematically explicit computational contribution suitable for independent challenge, or must be narrowed/pivoted before implementation.

## Smallest useful check

Audit the active B2 specification against the goal brief's requirements for estimand, variables, units, assumptions, operational reliability, output, decision relevance, hand-worked example, limiting/failure cases, matched alternatives, and falsification. Add only the missing formal definition; do not add a new algorithm or claim novelty.

## Inputs and roles

- `docs/track_b/B2_NEUROFLOWNET_SPEC.md`: current candidate task and protocol.
- `docs/track_b/GATE_REGISTER.json`: authoritative B2 exit criteria and status.
- `docs/track_b/METHOD_MATRIX.md` and focused primary-source audits: nearest methods and claim boundary.
- Goal objective file: required mathematical definition and no-synthetic-data boundary.

## Expected artifact

A self-contained formal task definition with an explicit empirical risk/contrast, predictive reliability summary, a purely algebraic example, limiting and failure cases, and the research decision the evaluation informs. Update the session record, B2 spec, evidence/decision ledgers, gate evidence list, and live review status.

## Interpretation

Pass for this audit only if the defined quantity is computed exclusively from measured real-data outer-fold outcomes, all model selection remains inside outer-training data, participants are the population uncertainty unit, and the document clearly states that this is an evaluation contribution rather than a new algorithm. This does not pass B2; independent technical review and the full prior-art/data-protocol review remain required.

## Stop condition

If the task cannot support a researcher decision without overstating what measured scalp/iEEG data show, recommend narrowing or pivoting rather than inventing a novelty claim. Do not fit models, inspect confirmation outcomes, or create synthetic data for this audit.

## Verification performed

- Updated the active B2 specification with the measured-target estimand, participant-level NRMSE aggregation, inner-validation baseline selection, participant-level paired contrast, marginal interval coverage/calibration gap, and claim boundary.
- Added a symbolic residual example and limiting cases only; no neural signals or synthetic dataset were created or evaluated.
- Updated the independent-review packet to request a challenge of the estimand and decision interpretation.
- `scripts/research/validate_gate_register.py`: PASS; 177 evidence paths checked.
- `tests/test_track_b_gates.py`: 7 passed.
- `scripts/research/update_review_status.py`: PASS; live B0–B3 summary refreshed.

B2 remains IN_PROGRESS. The formal definitions make the candidate evaluation auditable; they do not establish novelty, predictive performance, practical utility, or independent review.


### Reliability aggregation refinement

A second-pass audit found that per-participant/load/contact coverage was specified, but the group-level calibration and width summary was not. The B2 spec now averages contacts equally within participant/load, then averages load folds within participant; participant bootstrap intervals are required, load-specific group summaries remain visible, and detailed contact results are preserved. The independent reviewer packet now asks whether this aggregation masks load/contact failures. This is a specification refinement only.
