# B1 real-data and forward-model audit

Run ID: `20261023T_b1_gbf_case_audit`  
Decision: PASS for the selected Localize-MI sub-01 development case, at the bounded nominal source-distinguishability and pulse-artifact scope.

## Decision being made

Can the existing real Localize-MI release and its participant-specific forward model support the stated one-head-model demonstration with traceable data, geometry, sensor, reference, and target definitions?

## Evidence and checks

- The local dataset identifies itself as Localize-MI, BIDS 1.2.0, and CC-BY-NC-SA 4.0. Its Git HEAD is `d7a123d3067213281f106b343c71f28c30e4dd60`, matching the metadata commit in the sealed Track A manifest. The full dataset record reports seven participants and 61 sessions with known intracranial stimulation contacts and high-density scalp EEG.
- The selected case is sub-01/run-01: 38 recorded epochs, 8 kHz, −250 to +10 ms, K13–K14 stimulation at 1 mA. The selected sensor contract is 236 good EEG channels, recorded in volts, exactly ordered against the supplied forward solution, with average reference applied consistently to data, leadfield, and covariance.
- The individual supplied forward solution contains 8,196 fixed-orientation cortical vertices. The source midpoint is transformed from the recorded FreeSurfer surface coordinates into the forward-model frame; the recorded transform round-trip error is zero. The midpoint is 1.88 mm from the nearest modeled cortical vertex, so cortical projection is explicitly an approximation.
- The covariance and preprocessing contract is frozen in `docs/FOUNDATION_PROTOCOL.md`: dataset baseline correction, noise estimated from −200 to −50 ms, 10% diagonal shrinkage for the nominal signature calculation, and explicit scaling assumptions for averaged trials.
- The known contact pair is a ground-truth reference only for the measured stimulation pulse artifact. The dataset authors warn that stimulation artifacts are non-physiological; they cannot validate localization of endogenous or distributed physiological activity. The run remains one-participant development evidence.
- Re-ran `scripts/validate_case.py` under the new unsealed run ID `b1_gbf_case_validation_20261023`; it independently reread the real epoch array, channel/event metadata, forward solution, electrode coordinates, contact coordinates, and head-to-surface transform. It passed with 0.0082 mm maximum scalp sensor-position difference and 0 mm contact-transform round-trip error. This wrote only `outputs/b1_gbf_case_validation_20261023/case_validation.json` and did not touch the sealed release.
- Re-ran the read-only sealed Track A verifier against `tracka_release_20261022_v2`. It returned PASS, exit 0, and rechecked all manifest-listed inputs, release artifacts, and source snapshot. The manifest pins GBFs commit `99fc7c6e8afbd2e3e68a700c5f1fa1483b90f49e`; the vendored license is BSD 3-Clause. Independent parity on the selected real inputs remains `2.2314636763005833e-13` relative Frobenius difference, not a full paper-benchmark reproduction.

## Gate decision and limits

B1 passes for this single, verified, real development case. It does not pass population-level or physiological-source validation, nor does it calibrate a probability of distinguishability. No additional participant outcomes, signal samples, model fitting, or synthetic data were used in this audit. An independent reviewer should assess the formal B2 estimand and interpretation before B2 can pass.

Exact machine-readable evidence: [`case_audit.json`](case_audit.json).
