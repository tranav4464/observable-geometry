# Development-only EasyReg point-transform audit

This audit applies a pinned MNI152Lin-to-MNI152NLin6Asym EasyReg field to released electrode coordinates for sub-01 through sub-03, then samples Harvard–Oxford labels. It reads no event rows or neural signals and no confirmation participants.

The result is an explicit, reproducible coordinate-map variant. Paired-field round-trip error checks numerical direction/interpolation consistency but does not establish anatomical accuracy, individual localization, or WBEN fidelity. The BIDS coordinate sidecar is absent, and the WBEN contact-assignment rule remains underspecified. See `audit_easyreg.json` and `contact_mapping_easyreg.csv`.
