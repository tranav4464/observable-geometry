# B2 prior-art audit: load-modulated state-space dynamics

## Decision this audit can change

Can a load-conditioned transition matrix, such as `A(k) = A0 + k A1`, be defended as the project's mathematical contribution, or should it be treated only as a comparator/modeling choice?

## Scope and procedure

Primary-source literature screen of condition-dependent latent dynamical systems and working-memory-load-dependent connectivity. No project dataset files, neural signals, event outcomes, confirmation participants, or synthetic data were accessed or generated.

## Findings

1. **Condition-modulated latent state-space dynamics are established.** The primary CLDS paper models latent dynamics as `x[t+1] = A(u[t]) x[t] + b(u[t]) + noise`, where observed experimental conditions index a family of linear systems. Its condition-to-parameter mapping can be nonlinear and learned. A linear load modulation is therefore a restricted instance of an established model family, not a novel mathematical method. Source: [Modeling Neural Activity with Conditionally Linear Dynamical Systems](https://pmc.ncbi.nlm.nih.gov/articles/PMC11888554/), especially Eqs. 1a–1c and the discussion of experimental covariates.

2. **Working-memory load modulation of connectivity is also established.** Dima et al. analyzed load-dependent effective connectivity in a verbal working-memory task; Huang et al. compared connectivity across n-back load conditions; Eryilmaz et al. decoded working-memory load from functional connectivity in 177 healthy participants. These use different modalities and endpoints from WBEN, but preempt a general claim that load-dependent connectivity itself is new. Sources: [Dima et al. 2014](https://pmc.ncbi.nlm.nih.gov/articles/PMC6869395/), [Huang et al. 2022](https://doi.org/10.1177/1071181322661139), [Eryilmaz et al. 2020](https://doi.org/10.1016/j.neuroimage.2020.116895).

3. **The exact on004752 load question is occupied in adjacent ways.** Yang et al. report iEEG power decoding for set sizes 4, 6, and 8 and load-related interregional synchronization in this task family. This does not directly answer scalp-only prediction of held-out iEEG waveforms across a held-out load, but it means a load effect or an iEEG load decoder cannot be the claimed contribution. Source: [Yang et al. 2025](https://pubmed.ncbi.nlm.nih.gov/40593531/).

## Decision

Reject `A(k) = A0 + k A1`, smooth load-dependent parameters, or load-dependent connectivity as a novelty claim. Such models may be retained as fair comparators or as a practically useful extension only if they fit the chosen data/task, are compared under matched splits, and improve a prespecified real-data prediction or researcher decision. The cross-load scalp-to-iEEG task remains an empirical challenge candidate, not a new algorithm. No method novelty is established by this audit.

## Limitation and next step

This is a bounded primary-source screen, not an exhaustive review. It does not establish whether any new task-specific method can add value. Continue B2 by fixing a target/model interface that the real paired recordings support, then compare the complete nearest methods. Do not implement a new estimator merely to preserve a novelty label.
