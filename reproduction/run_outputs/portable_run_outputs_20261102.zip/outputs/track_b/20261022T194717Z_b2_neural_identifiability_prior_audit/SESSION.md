# B2 focused prior-art audit: neural-model identifiability

**Run ID:** `20261022T194717Z_b2_neural_identifiability_prior_audit`  
**Decision this work can change:** whether an edge-wise WBEN profile can be described as a distinct mathematical contribution, and what B2 must compare before a contribution is selected.  
**Inputs:** primary article records and full-text methods for prior work on parameter identifiability in neural population models and DCM. No project dataset files or participant outcomes were opened. No synthetic data or signal fixtures were generated.  
**Pass/fail interpretation:** a close prior method using the same mathematical object in neural dynamical models defeats a broad method-novelty claim; it does not prove that a carefully bounded WBEN application has no scientific or software value.  
**Stop condition:** stop this focused search once the nearest neural-model precedents and their actual methods have been verified; do not infer novelty from absence in these two papers.

## Sources inspected

1. Hartoyo et al. (2019), [“Parameter estimation and identifiability in a neural population model for electro-cortical activity,” PLOS Computational Biology](https://doi.org/10.1371/journal.pcbi.1006694). This primary paper fits a 22-parameter neural population model to resting EEG spectra from 82 participants. It assesses parameter identifiability and sloppiness using parameter sampling, marginal posterior comparisons, and Fisher information matrix eigenanalysis. It reports only one individual parameter consistently constrained across participants and roughly five constrained parameter combinations. This is directly relevant evidence that neural-population model parameters fitted to EEG can be highly non-identifiable. It does not use WBEN or paired scalp/iEEG working-memory recordings, and its target and model are different.

2. Arand et al. (2015), [“Assessing parameter identifiability for dynamic causal modeling of fMRI data,” Frontiers in Neuroscience](https://doi.org/10.3389/fnins.2015.00043). This primary paper applies profile likelihood to DCM parameters, introduces the DCMident toolbox, and evaluates how acquisition specifications affect practical identifiability. It reports that identifiability depends on data and model design and that dense connectivity can yield non-identifiable parameters. It is direct prior art for profile-likelihood identifiability analysis in a neural effective-connectivity model, although its measurement modality and model differ from WBEN.

3. Raue et al. (2009), [“Structural and practical identifiability analysis of partially observed dynamical models by exploiting the profile likelihood,” Bioinformatics](https://doi.org/10.1093/bioinformatics/btp358). Previously recorded in D033; supports the general-method precedent.

4. He et al. (2026), [“Virtual iEEG from Scalp EEG: Charting the Landscape of Source Imaging, Intracranial Inference and Reconstruction”](https://arxiv.org/abs/2608.26998). Previously recorded in D033; the review explicitly distinguishes prediction from observability, identifiability, fidelity, and utility for scalp-to-iEEG work.

## Finding

The general candidate “profile a WBEN transition/edge parameter, refit nuisance parameters, and report whether the data constrain it” uses an established identifiability tool and is closely anticipated by neural-model applications. The exact model, modality, dataset, and decision context may be a new application, but that alone does not establish a new mathematical method. The evidence is sufficient to reject the current candidate as a *method-novelty claim* absent a sharper algorithmic distinction. It is not evidence that the diagnostic would be useless as a component of a reproducible challenge build.

This literature does not decide whether the most useful TKS contribution should instead be a different exact estimand, a software implementation that enables a new reproducible comparison, or a rigorously scoped empirical finding. That decision remains open. No replacement contribution is selected by this audit.

## Decision consequence

- Do not describe generic or WBEN-specific profile likelihood as a new mathematical method.
- Keep an edge profile, if implemented, as an established diagnostic or exploratory analysis unless a concrete algorithmic distinction is found and tested.
- B2 must broaden the close-method comparison to include neural-population identifiability and DCMident, then either define a genuinely distinct contribution or select an honest reproduction/challenge objective without a novelty claim.
- No dataset task, target map, split, or held-out evaluation was chosen or changed by this literature-only audit.

## Evidence limits

This is a targeted audit, not an exhaustive systematic review. It verifies that close neural-model precedents exist, enough to reject broad novelty language. It does not prove that every possible WBEN-specific technique is preempted. The project must compare any future candidate against the nearest paper and code at the level of equations, outputs, target decision, and evaluation.
