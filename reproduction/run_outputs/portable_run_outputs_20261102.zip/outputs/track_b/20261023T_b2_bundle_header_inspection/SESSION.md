# Header inventory session

The first header-only script attempt stopped because this NumPy version does not expose the private `_read_array_header` helper used in the script. It read ZIP member headers only and failed before any array payload was read. The corrected script uses NumPy's public version-specific header readers and completed successfully. See `header_inventory.py` and `header_inventory.txt`.

This inventory reads shape/dtype headers for stored arrays; it does not decompress their data. The earlier accidental `data` array load is documented separately in `ACCESS_NOTE.md`.
