# B2 artifact access note

Date: 2026-10-23. This note records an unplanned access during a metadata inspection.

A command used `np.load(..., allow_pickle=False)` and indexed every key in `outputs/tracka_release_20261022_v2/prepared_bundle.npz` to print shapes and dtypes. This decompressed the recorded EEG array under key `data` (236 x 2,081, float64) into memory. Its values were not printed, plotted, filtered, summarized, or used in a calculation. No labels, new participant data, confirmatory outcomes, model fits, or synthetic neural data were accessed or generated. The operation was metadata inspection on the already sealed Track A development bundle, but technically it read the signal array; it must not be described as a no-signal-access operation.

Further package inventory in this folder uses ZIP member headers only and does not read array payloads. This note does not modify the sealed Track A bundle or its manifest.
