# CAST primary-source audit

Date: 2026-10-23

## Scope and source set

Audited arXiv:2605.18897v1 and the official NEMAR record for ds004752. This was literature-only: no local confirmation-participant outcomes or signal files were accessed and no model was trained.

## What CAST reports

CAST is an arXiv preprint submitted 17 May 2026. It describes a multiscale 8/16/32-sample patch encoder, Transformer, and contact-aware decoder producing channel-wise 2-second iEEG waveform estimates. The preprint reports evaluations on GIN and ds004752. For each held-out participant, its encoder is trained on the other participants, after which 20% of that participant's paired recordings are used for decoder calibration and the remaining 80% for evaluation. The paper's own description therefore supports *cross-subject transfer with subject-specific iEEG calibration*, not zero-shot decoding. Channel selection is also based on the calibration portion. Reported scores and ablations remain unverified preprint claims.

The paper resamples to 200 Hz, windows data into 2-second segments with 1-second overlap, and z-scores each channel-window independently. This evaluates normalized within-window shape; native-unit amplitude reconstruction is not established by the described pipeline. The paper does not say whether the calibration/test partition is blocked or separated by a temporal gap. Since adjacent windows share one second of raw samples, split construction must be clarified before treating the reported test set as independent. This is an unresolved risk, not proof that leakage occurred.

## Data-task discrepancy and exact overlap

CAST labels OpenNeuro ds004752 as a “visual categorization” task in its overview and methods. The official NEMAR record describes the same dataset as a 15-participant modified Sternberg *verbal working-memory* task, with encoding, maintenance, recall and set-size metadata. CAST reports 14 ds004752 participants after excluding sub-10. The manuscript does not reconcile the task description or say whether its calibration/test split holds out any set size.

CAST directly occupies generic cross-subject scalp-to-iEEG waveform reconstruction on the very dataset considered for this project. We cannot claim that capability as our contribution. Its paper does not report a test condition where one complete working-memory load is absent from calibration/training and then evaluated from scalp EEG. That leaves a narrower held-load evaluation question as a candidate, not as established novelty.

The arXiv full text has no explicit data/code availability section and links no implementation repository in the inspected record. No public code was verified. This does not prove none exists elsewhere.

## Decision and gate consequence

D057 withdraws generic cross-subject waveform reconstruction on ds004752 as a novelty claim. Do not treat CAST as a matched baseline until task labels, split construction, normalization, and code are independently reconciled. Keep held-load evaluation provisional pending the remaining direct task-conditioned prior-art audit. B2 remains IN_PROGRESS.

## Sources

- CAST arXiv v1: https://arxiv.org/abs/2605.18897
- Official dataset record: https://nemar.org/dataset/on004752

## Data handling

No local signal data, event outcomes, reserved participants, or model outputs were accessed.
