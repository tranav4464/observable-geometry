# 200 Hz real-data compatibility audit for the waveform-model candidate

Run ID: `20261023T_b1_200hz_candidate_task_audit`  
Decision question: Do development-only paired recordings in the pinned on004752 release support event-aligned EEG/iEEG epochs on a common 200 Hz grid, as required for a NeuroFlowNet-like waveform model?  
Outcome: **PASS for technical data compatibility only.** This does not select NeuroFlowNet, reproduce its model, establish prediction performance, resolve novelty, or authorize access to confirmation participants.

## Scope and procedure

- Dataset: local NEMAR on004752 v1.0.0 / OpenNeuro ds004752 v1.0.1.
- Participants: development-only sub-01 through sub-03; 14 paired sessions.
- Every event row in those development sessions was checked for paired EEG/iEEG counts, matching task fields, 8-second duration, 1-based contiguous trial numbering, exact native sample counts, and equal corrected zero-based epoch boundaries (`(begSample - 1)/fs` through `endSample/fs`).
- For one real trial in each session, signal data were read to verify native 200 Hz scalp EEG and 2,000 Hz iEEG and finite output after per-epoch iEEG resampling to 200 Hz using `scipy.signal.resample_poly(up=1, down=10)`. No signal values were saved.
- No event rows or signal samples from sub-04 through sub-15 were opened. No synthetic data were generated or used.
- Machine-readable results and per-file SHA-256 hashes are in `audit.json`. The reproducible procedure is `audit_200hz_alignment.py`.

## Result

All 14 paired sessions passed the corrected alignment and shape checks. Recorded session trial counts range from 46 to 50; paired events remain aligned and contiguous from trial 1. Native 8-second arrays map to 1,600 time samples at 200 Hz for both modalities after iEEG downsampling. This demonstrates that the release can support a 200 Hz event-locked input/output representation on the development subset.

The check is not a complete preprocessing protocol. It does not establish that the paper's exact segment normalization, filtering, windowing, split or model-training procedure transfers to this dataset. It does not verify the NeuroFlowNet implementation, model output quality, load-shift performance, physical-unit calibration, or any anatomical interpretation.

## Failed first attempt and correction

The first run stopped at sub-02/ses-01 because the audit script incorrectly required exactly 50 event rows in every session. The existing metadata audit records real sessions with 46–50 rows. This was a faulty audit assumption, not a data-alignment failure. The script was corrected to require a non-empty, contiguous 1-based trial sequence and matching paired rows, then rerun. The initial traceback is preserved in `first_attempt_failure.txt`; the corrected run is the `audit.json` result above.

## Decision effect

The 200 Hz route is technically possible on the development subset, so sample-rate compatibility alone is not a reason to reject a clean-room waveform-model baseline. The project route remains unresolved because the existing provisional WBEN build and the contact-waveform task have different estimands; NeuroFlowNet is direct prior art on the waveform task, its inspected repository has no declared license, and held-load task overlap remains unverified. Keep B2 in progress and do not fit any Track B model before the task/base decision and required independent challenge are complete.
