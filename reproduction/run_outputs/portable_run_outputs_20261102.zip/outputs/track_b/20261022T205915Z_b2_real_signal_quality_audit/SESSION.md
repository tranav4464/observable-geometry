# B2 real-signal window-quality audit

## Session identity

- Run ID (UTC): `20261022T205915Z_b2_real_signal_quality_audit`
- Date/operator: 2026-10-23 local; Codex
- Gate and status before work: B2, IN_PROGRESS
- Git commit / working-tree state: workspace root has no `.git` directory, so no commit hash is available.
- Environment: `.venv` Python; CPU, no GPU needed
- Dataset: NEMAR `on004752` v1.0.0, development participants sub-01 through sub-03 only

## Decision this work can change

- Decision question: does the candidate 50-Hz final-maintenance window contain non-finite or exactly constant channel-trial traces that require a prespecified quality exclusion beyond the dataset's Artifact flag?
- Why this is the earliest open gate: B2 must define trial/channel exclusions before the primary real-data model fit.
- Smallest decisive check: read paired EDF epochs for the 14 development sessions, explicitly handle blank EDF units using channel-table `μV`, resample whole 8-s epochs with the current declared polyphase recipe, and count finite/zero-variance channel-trial windows in `[4,6)` s.
- Expected artifact: deterministic audit script, per-participant/modality summary counts and amplitude/scale summaries; no raw signals saved.
- Stop condition: if event pairing, units, sample rates, epoch length, or finite checks fail, stop and preserve the failure; do not infer a new filter or quality threshold from the same data.

## Inputs and leakage check

- Read `events.tsv`, `channels.tsv`, fixed EDF headers, and real signal samples from paired EEG/iEEG recordings for sub-01 to sub-03 only.
- The audit includes only rows marked `Artifact==0` for the quality summary; it does not introduce further exclusions.
- Confirmation participants sub-04 to sub-15 were not read. No synthetic data were created. No model was fit and no predictive outcome was computed.
- For EDFs with blank physical-dimension fields, MNE receives the explicit `units='uV'` override validated in the prior scale audit; returned volts are converted back to microvolts for descriptive metrics.
- The candidate pipeline is applied to each complete event-relative epoch before extracting `[200:300]`; no values from one trial are used to alter another trial.

## Prespecified interpretation

- Pass for this narrow check: all eligible event pairs align; every window is finite; no channel-trial window has exact zero standard deviation; the metric report is reproducible.
- Fail: any malformed event pair, unexpected sampling rate/shape, nonfinite window, or exact zero-variance channel-trial window. A fail would require an explicit, train-only rule and sensitivity audit, not automatic channel deletion.
- Amplitude and variability summaries are descriptive only. They are not sensor-noise estimates and do not justify a clipping or physiological-artifact threshold.

## Decision and follow-up

- Outcome: supported with limits
- Command: `.venv/Scripts/python.exe scripts/research/audit_dev_signal_window_quality.py --dataset-root data/track_b/on004752_v1.0.0 --output outputs/track_b/20261022T205915Z_b2_real_signal_quality_audit/signal_window_quality.json`
- Result: all 14 paired development sessions and 629 `Artifact==0` trials passed event/unit/rate/window checks. The 50-Hz maintenance windows contained 41,192 channel-trial traces (6,968 EEG and 34,224 iEEG); none had non-finite samples or exactly zero variance. Peak and SD quantiles vary by participant and modality, so no amplitude threshold is inferred.
- SHA-256 script: `EA3666B917B8C71AE4E34CFFC593B000BEB3B3AFD24DB2E7FF4DE8F13F28D61C`.
- SHA-256 result: `FCE07CFC28AA9EB1744F4F1E73EE376B5373CACC85310941419BE476D201FCD7`.
- Decision: no extra development-data channel/trial exclusion is supported by this finite/constant check. Retain the dataset `Artifact` flag and fold-local training safeguards for nonfinite/zero-variance channels as provisional rules. Do not claim the data are artifact-free or that the check detects physiological artifacts, clipping, or acquisition-filter problems.
- Keep B2 IN_PROGRESS. This check establishes neither signal quality in the scientific sense, power, prediction, nor model adequacy.

