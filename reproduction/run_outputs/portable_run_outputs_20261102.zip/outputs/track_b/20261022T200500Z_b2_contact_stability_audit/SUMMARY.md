# Development contact-identity audit

This metadata-only check found identical SEEG channel-name sets across every available development session for each participant, with every channel name joining to an electrode metadata row:

| Participant | Sessions | Same named SEEG contacts in every session |
|---|---:|---:|
| sub-01 | 4 | 48/48 |
| sub-02 | 7 | 64/64 |
| sub-03 | 3 | 40/40 |

This removes the need for an atlas map if the endpoint is prediction at the **same recorded contact labels within each participant**. It does not tell us where a contact is anatomically, prove that its physiology is unchanged, or demonstrate prediction. It therefore opens a feasible B2 fallback, but it does not resolve WBEN's regional observation operator or pass B2. The contact-level task would need to be named as a WBEN-inspired adaptation or a separate model, not a faithful reproduction of the regional WBEN analysis.

The audit reads only `*_channels.tsv` and `*_electrodes.tsv` for sub-01 through sub-03. It does not read event rows, signal samples, or any confirmation participant data. See `contact_stability.json` and the reproducible script `scripts/research/audit_dev_contact_stability.py`.
