# B2 feasibility audit: development contact-label stability

## Session identity

- Run ID (UTC): `20261022T200500Z_b2_contact_stability_audit`
- Date/operator: 2026-10-22 UTC / Codex
- Gate and status before work: B2 IN_PROGRESS; B-1, B0, B1 PASS; B3-B8 NOT_STARTED.
- Git commit / working-tree state: workspace has no discoverable `.git` directory at the project root; files are tracked by the desktop workspace context only.
- Environment lock / CPU-GPU: metadata-only Python standard library audit; CPU; no GPU workload.
- Data and code versions/hashes: NEMAR `on004752` v1.0.0 local release; only `*_electrodes.tsv` and `*_channels.tsv` for `sub-01` through `sub-03`.

## Decision this work can change

- One decision question: Can a within-participant, contact-level measured-iEEG task avoid the unresolved atlas mapping while retaining target-channel identity across the development participant's sessions?
- Why is this the earliest unresolved gate on the critical path? B2 cannot lock a regional target without a defensible atlas map; contact identity is the smallest metadata-only check of the prescribed fallback.
- Smallest decisive check: Compare the intersection of SEEG channel names in each participant's electrode and channel metadata across all available development sessions.
- Expected artifact: A reproducible JSON inventory of contact overlap and metadata consistency, with no event, signal, or held-out participant reads.
- Stop condition: If recording contacts do not map to electrode metadata or stable labels are absent across the participant's sessions, do not proceed with a same-contact cross-load endpoint without a new target definition.

## Inputs and leakage check

- Inputs opened/read: `data/track_b/on004752_v1.0.0/sub-01..sub-03/**/ieeg/*_electrodes.tsv` and `*_channels.tsv` only.
- Metadata, signal, image, or outcome data: Electrode/channel metadata only.
- Development or held-out role: Development participants sub-01 through sub-03.
- Could any input reveal a confirmatory outcome? No. No confirmation participants, event rows, or signal samples were accessed.
- Allowed transformations / preprocessing: Tabular identity/type/status inventory only; no coordinate transforms or signal processing.

## Prespecified interpretation

- Pass condition: Each development participant has a nonempty intersection of recorded SEEG channel labels across all sessions and those labels join to electrode metadata; then a contact-level within-participant task is feasible without atlas correspondence.
- Fail/falsification condition: Missing or inconsistent contact identities prevent defining the same measured target across sessions.
- What result would change the next decision? A pass allows B2 to consider a contact-level prediction task as a distinct challenge adaptation; it does not pass B2 or establish novelty. A fail requires revising the target or abandoning that task.
- Baselines / negative controls: Not assessed in this metadata-only feasibility check.

## Execution record

- Exact command: `python scripts/research/audit_dev_contact_stability.py --dataset-root data/track_b/on004752_v1.0.0 --output outputs/track_b/20261022T200500Z_b2_contact_stability_audit/contact_stability.json`
- Seeds and configuration: None.
- Warnings, exclusions, failures: Status fields are absent from these channel tables, so the audit cannot separate good/bad channels; no signal-level quality conclusion is made.
- Outputs and checksums: `contact_stability.json`; compact results are summarized in `SUMMARY.md`.
- CPU reference and GPU parity evidence: Not applicable.
- Independent metric/oracle check: Manual inspection of the first development TSV headers/rows confirmed `name` columns; script asserts each session's channel labels join to the electrode table.

## Decision and follow-up

- Outcome: PASS for the metadata feasibility question; B2 remains IN_PROGRESS.
- Interpretation limited to: All SEEG channel names join to electrode metadata and are stable across the available sessions for each development participant: sub-01 48/48 across 4 sessions; sub-02 64/64 across 7; sub-03 40/40 across 3. This supports defining same-label measured contact targets within a participant without atlas correspondence. It does not establish anatomical identity, physiology stability, or predictive performance.
- Ledger/matrix/protocol updates: Record contact-level target feasibility as supported with limits; keep regional WBEN map unresolved.
- Next earliest gate action: Compare the contact-level task's exact input/target/split with direct scalp-to-iEEG prior art and specify an architecture that does not silently claim the WBEN regional model. Then either pivot formally or return to a validated regional map.
- Reviewer and review result: Self-review confirmed all results derive from development `channels.tsv` and `electrodes.tsv` only; no events, signals, or confirmation participants were accessed.
