# B2 specification review freeze v6

- Active route: GBFs reproduction/reverse-engineering and nominal source distinguishability under one verified participant-specific forward model.
- Frozen specification: `B2_GBF_SPEC_review_v6.md`.
- SHA-256: `c38d54b0c37199eb018eb0c6247d76af62644ca161648c1fa492a0d55ef9cb98`.
- Change from v5: corrected the source-ambiguity citation to match the linked primary PMC paper record.
- Review status: awaiting unaffiliated technical review; no approval implied.
- No signal samples, new outcomes, model fitting, or synthetic neural data were accessed or generated.
