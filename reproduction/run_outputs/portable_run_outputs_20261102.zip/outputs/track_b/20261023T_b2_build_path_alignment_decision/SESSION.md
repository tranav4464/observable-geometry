# B2 build-path alignment decision

## Decision affected

Select a coherent software build path after discovering that the candidate real-data task and the selected WBEN model expose different outputs.

## Evidence reviewed

- WBEN's NeurIPS paper describes joint scalp EEG/iEEG state estimation and regional connectivity inference, not a supervised scalp-only translator for held-out contact waveforms. The local B3 reference implements the state-space equations but has not passed paper-fidelity or real-data validation.
- The candidate B2 held-load task predicts recorded common-reference iEEG contact waveforms from scalp EEG alone at a set size withheld from that participant's paired training data.
- NeuroFlowNet directly targets scalp-to-iEEG waveform generation on the same source cohort, but its paper's held-trial/session tests do not report a fully held-out load. Its public repository snapshot has no declared license and contains reproducibility differences documented in the earlier audit.
- CAST and Dong et al. further preempt generic waveform reconstruction; their inspected task/split details do not establish the exact held-load endpoint. The 2026 review identifies calibration and split unit as central to the claim.
- The all-participant channel-schema audit verifies the candidate scalp inputs and stable participant contact labels, but it does not verify event-count eligibility or model performance.

## Alternatives

1. **Treat contact prediction as a direct WBEN reproduction.** Rejected: target and output are different. That would misstate what was reproduced and make the primary comparison invalid.
2. **Replace WBEN with NeuroFlowNet as the base.** Not selected: it matches the waveform target more closely, but its published tests do not cover the held-load challenge, the repository has no declared code license, and its comparison protocol needs independent reimplementation and matched data access. Reimplementation from its paper remains a fallback if B2 review finds the two-part WBEN path incoherent.
3. **Keep a two-part, one-lineage build.** Selected provisionally: (a) reproduce WBEN's regional state-space analysis from the paper and real paired data, preserving its mapping/optimizer ambiguities; (b) implement a separately named scalp-only contact-state adaptation derived from the same linear-Gaussian/Kalman ideas and test it on the held-load contact-waveform endpoint against the training-mean and causal-FIR baselines. The two parts share a model lineage and dataset but have distinct outputs, claims, and score tables.

## Scope and claim rules

- The WBEN reproduction is assessed for equation-to-code and real-data analysis fidelity, not by the contact-waveform prediction score.
- The contact-state adaptation is assessed only against baselines with the same contact target, scalp inputs, splits, and tuning budget. It is called WBEN-informed, not faithful WBEN.
- Do not claim that the adaptation is a new algorithm. Any future mathematical contribution must survive B2 prior-art review and B4 real-data evaluation; otherwise the final build is a replication/challenge benchmark.
- Do not combine scores from the two parts into a single headline metric.
- Before any model fitting, the independent reviewer must decide whether this two-part structure is coherent and useful. If rejected, reopen the base/task choice; do not relabel the contact model as WBEN.

## Status and stop rule

This is a provisional architecture decision for review, not a B2 pass or model-fitting authorization. B2 remains IN_PROGRESS because exact task-level prior-art overlap and independent technical review remain unresolved. Do not inspect sealed event outcomes or fit any Track B model until the gate conditions pass.

## Data boundary

Literature and existing metadata/code records only. No dataset event rows, confirmation outcomes, signal fits, or synthetic data accessed or generated in this decision.
