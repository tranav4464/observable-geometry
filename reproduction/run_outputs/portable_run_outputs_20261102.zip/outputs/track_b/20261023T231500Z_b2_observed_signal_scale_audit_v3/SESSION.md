# B2 real development-recording scale and EDF/BIDS unit audit

**Run ID:** `20261023T231500Z_b2_observed_signal_scale_audit_v3`  
**Decision this audit can change:** the unit-handling rule for real EEG/iEEG loading and whether observed fixation variability can calibrate the state-space observation noise.  
**Inputs:** paired EDFs and BIDS `channels.tsv` / `events.tsv` for 14 development-only sessions from sub-01 through sub-03. No confirmation participants were opened.  
**Output:** `signal_scale_audit.json`; no signal samples were saved.

## Procedure and verification

The script checked every EDF signal's physical-dimension header fields, verified channel order and `μV` units against `channels.tsv`, then called MNE `read_raw_edf(..., units="uV")` as its documentation instructs when EDF units are missing. MNE returns SI volts; the output summary converts those values back to microvolts. All artifact-unflagged trial intervals were taken from real event tables, checked as 8-second pairs, resampled to 50 Hz, and summarized over fixation `[0,1)` and final maintenance `[4,6)`. No model was fitted and no synthetic data were generated.

## Results

The corrected counts are 176, 319, and 134 artifact-unflagged trials for sub-01, sub-02, and sub-03 respectively. Median per-channel, per-trial temporal SDs in μV:

| Participant | EEG fixation | EEG maintenance | iEEG fixation | iEEG maintenance |
|---|---:|---:|---:|---:|
| sub-01 | 24.17 | 11.79 | 60.40 | 57.68 |
| sub-02 | 13.13 | 15.40 | 32.67 | 40.54 |
| sub-03 | 21.14 | 21.11 | 38.07 | 40.68 |

## Decision and limits

The released EDFs omit physical-dimension labels while the BIDS channel tables declare `μV`. The project loader must pass those units explicitly to MNE (or implement an equivalently verified conversion) before normalization. Do not infer units from MNE's default `n/a` metadata or multiply its unscaled numeric values blindly.

These SDs describe observed brain-plus-instrument variability, not sensor noise. The fixation interval contains ongoing neural recordings and is not an empty-room measurement. Therefore the audit does not estimate WBEN's `P` or `S`, validate the paper's appendix values 1 and 0.1, or determine an optimal model covariance. Any contact-model covariance remains an effective prediction parameter, not a measurement-noise claim.

The v1 first pass is invalid because it applied an erroneous `1e6` factor. It is documented at `outputs/track_b/20261023T221500Z_b2_observed_signal_scale_audit/SESSION.md`. The v2 corrected sidecar-based interpretation is in `outputs/track_b/20261023T223500Z_b2_observed_signal_scale_audit_v2/`; this v3 reruns it through MNE's documented unit override.

## Primary documentation

- MNE `read_raw_edf` documents the `units` argument for files whose units are missing: <https://mne.tools/stable/generated/mne.io.read_raw_edf.html>
- BIDS requires a physical-unit value for each channel in `channels.tsv`: <https://bids-specification.readthedocs.io/en/v1.4.0/04-modality-specific-files/03-electroencephalography.html>
