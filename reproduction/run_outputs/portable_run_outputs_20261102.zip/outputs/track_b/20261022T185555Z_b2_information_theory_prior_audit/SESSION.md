# B2 prior-art audit: scalp–sEEG information-theoretic analysis

**Run ID:** `20261022T185555Z_b2_information_theory_prior_audit`  
**Access date:** 2026-10-23 (Asia/Kolkata)  
**Purpose:** determine whether a conditional-information or predictive-score contribution is already occupied, and what exact comparison remains unresolved.  
**Data exposure:** no local participant files, event rows, or signal samples accessed. No synthetic data or tests used.

## Sources inspected

1. IEEE Xplore record for Phillips et al., *Characterizing the relationship of non-invasive and invasive neural recordings: An information-theoretic analysis of the scalp and stereo electroencephalography*, Asilomar Conference on Signals, Systems, and Computers 2025, DOI `10.1109/IEEECONF67917.2025.11443669`: <https://doi.org/10.1109/IEEECONF67917.2025.11443669>.
2. Conference session listing for the paper: <https://cmsworkshops.com/Asilomar2025/view_session.php?SessionID=1063>.
3. Houston Methodist Scholars author/institution record: <https://scholars.houstonmethodist.org/en/publications/characterizing-the-relationship-of-non-invasive-and-invasive-neur/>.

The publisher's indexed abstract says the study analyzes synchronized scalp EEG and sEEG using Spearman correlation, mutual information, and directed information across spatial, temporal, and spectral relationships. It reports an inverse relationship between intracranial signal depth and frequency content and examines directed information for temporal windows. The conference metadata identify the work as a 2025 Asilomar paper, pages 1602–1606.

## What this establishes

- Mutual information and directed information have already been applied to quantify scalp–intracranial EEG relationships. Their use, or relabeling them as a new “conditional contribution” framework, is not a defensible novelty claim.
- Scalp-to-intracranial association and depth/frequency effects are not open generic claims.
- The published study is a direct prior-art comparator for the broad idea that information-theoretic scores can characterize links between scalp EEG and sEEG.

## What remains unresolved

The accessible publisher/author abstract does not establish the exact cohort, contact-level target, task conditions, conditioning variables, train/test split, predictive distribution, uncertainty unit, or whether the paper evaluates task-context-conditioned held-out prediction across working-memory loads. The full proceedings paper was not available through the accessible publisher record during this audit. No paywall or paid access was attempted.

Therefore this source refutes a generic information-theory novelty claim but does **not** yet prove that the narrower working-memory cross-load challenge is already answered. B2 must compare the full method and exact evaluation question before keeping that challenge. The conditional log-score difference remains an ordinary evaluation statistic, not a new estimator.

## Decision consequence

Keep B2 open. Do not claim the proposed log-score or information-theoretic quantity as a new mathematical method. Retain a within-participant, held-out working-memory challenge only as a candidate task, subject to exact task-level prior-art comparison and a frozen real-data protocol. If no distinctive researcher-facing question survives, document reproduction/challenge only.
