# B2 measurement-definition audit: reference and sidecar provenance

## Session identity

- Run ID (UTC): `20261022T202000Z_b2_reference_provenance_audit`
- Date/operator: 2026-10-22 UTC / Codex
- Gate: B2 IN_PROGRESS; B-1, B0, B1 PASS; B3-B8 NOT_STARTED.
- Data: NEMAR `on004752` v1.0.0; development participants sub-01 through sub-03.
- Environment: Python standard library; CPU only.

## Decision this work can change

- Question: Do the paired session sidecars and channel tables declare the EEG/iEEG referencing needed to define a contact-waveform target?
- Smallest check: Inventory `EEGReference`, `iEEGReference`, hardware/software filter declarations, and channel-level reference/status fields across the 14 development pairs.
- Expected artifact: Per-session JSON inventory and a concise consistency summary.
- Stop condition: If the reference is absent or inconsistent, do not claim absolute or cross-participant comparable voltages; define the endpoint as within-recording referenced signal or reject waveform targets.

## Inputs and access boundary

- Inputs: EEG and iEEG `*_eeg.json` / `*_ieeg.json` and `*_channels.tsv` for sub-01 through sub-03 only.
- Metadata only; no event rows, signal samples, or confirmation participant files.
- No synthetic data are created.

## Prespecified interpretation

- Pass: Sidecars declare a consistent reference convention that supports a clearly bounded recorded-signal endpoint.
- Inconclusive: A generic reference description limits interpretation or varies across sessions.
- Limitation: Sidecar declarations document reference setup but do not verify the acquisition hardware or the exact physical reference contact.

## Execution

- Command: `python scripts/research/audit_dev_reference_provenance.py --dataset-root data/track_b/on004752_v1.0.0 --output outputs/track_b/20261022T202000Z_b2_reference_provenance_audit/reference_audit.json`
- Output: `reference_audit.json` and `SUMMARY.md`.

## Decision

- Outcome: **SUPPORTED WITH LIMITS.** All 14 development pairs report the same generic EEG reference declaration (electrode near the vertex) and the same iEEG declaration (common intracranial reference). Neither modality's channel table provides a per-channel reference or status column. Software-filter declarations are `n/a`; hardware sidecars declare 0.5-Hz high-pass and 1,000-Hz low-pass, but the EDF header audit found the per-channel prefilter strings blank and the channel-table cutoff fields conflict with the sidecars/BIDS semantics.
- Interpretation: This supports a narrowly defined within-participant target of the recorded iEEG traces under the dataset's declared common reference. It does not establish absolute voltages, exact physical reference contacts, cross-reference amplitude comparability, or verified acquisition filtering.
- Next: Define predictions in the recorded reference and freeze a defensible common digital preprocessing pipeline after model/task selection. Keep acquisition-filter provenance as a limitation. The audit does not resolve B2's task/model compatibility, exact metric/baselines, or novelty questions.

## Summary artifact

See `SUMMARY.md` and `reference_audit.json`. This run read metadata only from development participants sub-01 through sub-03; no event rows, signal samples, or confirmation participants were accessed.
