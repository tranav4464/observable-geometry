# Reference-provenance audit summary

The metadata-only audit covered all 14 paired development sessions for sub-01 through sub-03. Every scalp EEG sidecar declares an electrode near the vertex as its reference; every iEEG sidecar declares a common intracranial reference. The declarations are stable across the audited sessions, but they do not identify the exact physical reference contact or independently verify the acquisition hardware.

The target can therefore be described only as the **recorded iEEG waveform under the dataset's declared common intracranial reference**. It is not an absolute voltage, a reference-independent source signal, or proof that amplitudes are comparable across recording/reference systems. The EEG and iEEG channel tables contain neither a per-channel `reference` nor a `status` column. Software-filter metadata is `n/a`; sidecars declare 0.5-Hz high-pass and 1,000-Hz low-pass, while channel-table cutoff fields conflict with those declarations and EDF per-channel prefilter strings are blank. Acquisition filter provenance remains unresolved.

No events, signal samples, or confirmation-participant files were read. This resolves the wording of the reference-limited target, but does not complete B2: task/model compatibility, preprocessing, split, metrics, matched baselines, and the contribution decision remain open.
