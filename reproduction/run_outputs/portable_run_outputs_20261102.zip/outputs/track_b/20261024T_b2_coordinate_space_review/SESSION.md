# Coordinate-space review: Harvard–Oxford lookup withdrawn

**Decision:** The previous 374/760 label count is withdrawn as anatomical and feasibility evidence.

The lookup sampled a Harvard–Oxford atlas in MNI152NLin6Asym using electrode coordinates produced by a pipeline that indicates SPM12 OldNorm's linear ICBM152-derived template. No inter-template transform was applied. A generic `MNI` metadata label does not make those coordinates interchangeable. The saved mapping is retained only as a record of the computation.

This review inspected the prior audit metadata and public source/documentation only. It did not read EEG/iEEG signals, event rows, or confirmation participants. A documented candidate exists: NiSpace exposes EasyReg-based fields between MNI152Lin (SPM12) and MNI152NLin6Asym (FSL), but its public function resamples images. It documents that the source-grid `bak_field` maps points forward while the target-grid `fwd_field` supports image pull-resampling; using the wrong field can shift locations by about 1–2 mm. A future atlas map requires an independently implemented and checked point transform, exact coordinate convention, reproducible field/version/hash, geometric/sensitivity validation, and the exact WBEN contact-assignment rule. Otherwise B2 must choose an endpoint that avoids atlas correspondence.

Primary references and structured details are in `coordinate_space_review.json`.
