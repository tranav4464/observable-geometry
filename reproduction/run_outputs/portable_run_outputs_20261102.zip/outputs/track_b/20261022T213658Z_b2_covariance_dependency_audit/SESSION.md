# B2 covariance estimator dependency and environment audit

## Session identity

- Run ID (UTC): `20261022T213658Z_b2_covariance_dependency_audit`
- Gate before work: B−1, B0, B1 PASS; B2 IN_PROGRESS
- Decision this audit can change: which reproducible covariance shrinkage implementation to name for the contact-state adaptation without altering the sealed Track A environment.
- Inputs: official scikit-learn API and release records; current foundation and GPU Python versions; existing Track B model-interface audit.
- Data boundary: no local recordings, event rows, held-out participants, model fits, synthetic data, or synthetic signal fixtures were accessed or generated.

## Findings

- The official scikit-learn API provides `sklearn.covariance.ledoit_wolf(X, assume_centered=False, block_size=1000)`, returning the shrunk covariance and the estimated shrinkage coefficient. Its documented target is `(1 - shrinkage) * empirical_covariance + shrinkage * trace(empirical_covariance)/p * I`.
- The official PyPI record lists scikit-learn 1.9.1, released 10 September 2026, as the current stable release and requires Python >=3.11. The project foundation environment is Python 3.12.14; the separate historical Track B GPU environment is Python 3.10.11 and cannot use this pinned version.
- Covariance estimation for the small contact/scalp matrices can run on the CPU. The GPU is not needed for this step; no performance or GPU claim is made.

## Decision

Pin scikit-learn 1.9.1 as a Track B CPU-only dependency in `requirements-trackb-cpu.txt`, which includes the existing foundation requirements by reference. Do not change the sealed foundation requirements or the Python 3.10 GPU environment. At B3, create a separate Python 3.12 Track B CPU environment and verify the covariance API/version before using it. If the available runtime cannot resolve the pinned stack, document the failure and evaluate a separately audited NumPy implementation before any model fit.

The Ledoit–Wolf estimate is a regularized residual covariance for prediction, not physical sensor noise. Time samples are autocorrelated; the estimator's coefficient is a numerical shrinkage rule, not a calibrated uncertainty claim. Retain diagonal-covariance and failure-condition sensitivity checks for B4, using only permitted real development recordings after B2 passes.

## Pass/fail interpretation

- Pass for reproducibility selection: one documented, pinned, CPU-compatible covariance implementation is identified without modifying Track A.
- No empirical conclusion: no covariance was estimated from neural data and no prediction model was fitted.
- Stop condition: do not install into or alter Track A environments; proceed to model fitting only after B2 and the independent protocol review pass.

## Primary sources

- scikit-learn 1.9.1 Ledoit–Wolf API: <https://scikit-learn.org/stable/modules/generated/sklearn.covariance.ledoit_wolf.html>
- scikit-learn covariance estimation guide: <https://scikit-learn.org/stable/modules/covariance>
- PyPI release record: <https://pypi.org/project/scikit-learn/>
