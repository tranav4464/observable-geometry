# B2 v8 frozen specification record

Frozen review copy: `B2_GBF_SPEC_review_v8.md`  
SHA-256: `7c3f078032b6b361cfba98b10e60ea5d052832ad26a7fd5c5c814ece2c354059`  
Independent verifier: `scripts/research/recompute_gbf_cpu64.py`, SHA-256 `2beb2c8b008883e6d3ce51010af855156fd3865d0b25cfae0d09963e30594d88`.

Changes since v7: exact discrete-output requirements and numeric tolerances are now fixed before the independent numerical run. The verifier passed syntax/help checks only; it has not read or calculated from model arrays. The verifier hashes the prepared-bundle archive as bytes but, when eventually run, indexes only named leadfield/covariance and coordinates/comparison keys; it does not decompress the stored EEG `data` array. A prior development-array access during an unrelated metadata command is disclosed in `outputs/track_b/20261023T_b2_bundle_header_inspection/ACCESS_NOTE.md`.

No model arrays, signal values, outcomes, or synthetic neural data were accessed while making this v8 specification copy.
