# B2 sequence-boundary and model-order contract audit

## Session identity

- Run ID (UTC): `20261022T205200Z_b2_multisequence_contract`
- Date/operator: 23 October 2026, Codex
- Gate before work: B2 IN_PROGRESS; B-1, B0, B1 PASS
- Data: none; read-only source-code and published-method review
- No GPU, no synthetic signals/data, no confirmation outcomes

## Decision question

Can the current WBEN reference fit support the proposed 2-second held-load trial endpoint without inventing transitions across separate trials, and what model order matches the published real-data method?

## Sources inspected

- `src/observable_geometry/analysis/wben.py`, especially `_validate_model`, `_m_step`, `fit_wben_k1`, and `kalman_rts_smoother`.
- `scripts/research/run_physical_wben_development.py` was read only to verify that it is explicitly a synthetic development runner; it was not run.
- `docs/track_b/B3_WBEN_IMPLEMENTATION.md` for the current K=1 implementation limits.
- Yang & Liu, NeurIPS 2025, Appendix A.4 (official proceedings PDF), which specifies a second-order VAR for the real-data analysis, the 8-second epochs, final two maintenance seconds, and 50-Hz downsampling.

## Findings and mathematical requirement

The current `fit_wben_k1` accepts one `T × m` array, fits first-order dynamics, and its M-step counts every adjacent pair in that array. Concatenating multiple trials would falsely treat the end of one trial and start of the next as adjacent states. It also does not match the paper's stated second-order real-data model.

For independent trial sequences `Y^(r)` with length `T_r` and VAR order `K=2`, compute the likelihood as `Σ_r log p(Y^(r) | θ)` with a fresh, fixed initial-state distribution per trial. Sum transition sufficient statistics only over `t=K,…,T_r−1`; the transition count is `Σ_r (T_r−K)`, which is `98N` for `N` 100-sample trials. The process-noise update denominator must use that count. For test trials, run a fresh scalp-only filter per trial and do not carry latent state across trials or use held-out iEEG in any filtering, normalization, or model-selection step.

An order-2 companion-state representation makes its process-noise covariance singular by construction. The current code requires positive-definite process covariance, so it cannot be adapted by simply changing the transition matrix. A multi-sequence order-2 implementation needs a numerically valid positive-semidefinite-noise treatment (or a mathematically equivalent VAR(2) EM derivation) plus independent verification before use.

## Interpretation and next action

This audit falsifies direct use of the current K=1/single-sequence implementation for the proposed protocol. B2 should specify an independent-trial, order-2 model contract and distinguish the contact-level adaptation from faithful reproduction of WBEN's atlas/region model. Do not train a model until preprocessing, target/observation operators, baseline, metric, uncertainty, and independent protocol review are complete. This is an implementation requirement, not a novelty claim.
