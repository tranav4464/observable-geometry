# B2 feasibility audit: paired channel inventory

## Session identity

- Run ID (UTC): `20261022T201000Z_b2_paired_channel_inventory`
- Date/operator: 2026-10-22 UTC / Codex
- Gate and status before work: B2 IN_PROGRESS; B-1, B0, B1 PASS; B3-B8 NOT_STARTED.
- Workspace state: no `.git` directory is present at the project root.
- Environment: Python standard-library metadata audit on CPU.
- Data version: NEMAR `on004752` v1.0.0, development participants sub-01 through sub-03.

## Decision this work can change

- Decision question: Are scalp channel identities and acquisition references stable across the same sessions as the iEEG targets, and do the released channel tables provide explicit channel-quality flags?
- Why this is the earliest unresolved gate: A contact-level predictor must have a consistent scalp input schema, and missing channel-quality metadata changes preprocessing and exclusion design.
- Smallest useful check: Compare EEG/iEEG `channels.tsv` schemas, channel names, units, and sampling metadata, plus EEG sidecar reference, for the 14 development sessions.
- Expected artifact: JSON summary and session-level inventory.
- Stop condition: If scalp channel schemas differ materially across sessions or channel status cannot be established, do not freeze a common input interface without a training-only quality rule.

## Inputs and leakage check

- Inputs: EEG `channels.tsv`, EEG `eeg.json`, and iEEG `channels.tsv` for sub-01 through sub-03 only.
- Role: Development metadata.
- Data types: Metadata only; no event rows, signal samples, or confirmation participants.
- Note: One exploratory read of sub-01's EEG channel header and sidecar initiated this check; no outcomes or signal values were inspected.

## Prespecified interpretation

- Pass: Stable, joinable scalp channel names support a fixed within-participant input schema.
- Fail: Variable channel names or inconsistent references require a subject/session-specific mapping.
- Interpretation limit: Metadata do not prove equal signal quality, reference implementation, usable channels, or model performance. Missing bad-channel flags must remain a known limitation.

## Execution

- Command: `python scripts/research/audit_dev_paired_channel_inventory.py --dataset-root data/track_b/on004752_v1.0.0 --output outputs/track_b/20261022T201000Z_b2_paired_channel_inventory/inventory.json`
- No random seed, preprocessing, model, or GPU use.
- Outputs: `inventory.json` and its script.

## Decision

- Outcome: Failed run after writing JSON; console rendering raised a Windows cp1252 `UnicodeEncodeError` on the microvolt symbol. Preserve the output and failure as-is; do not use this run as verification.
- Next step: Re-run with ASCII-safe JSON output under a new run ID. Keep B2 open.
