# Phillips et al. full-text access recheck

## Session identity

- Date: 2026-10-23
- Gate: B2 formal specification, still IN_PROGRESS
- Decision affected: whether Phillips et al. (2025) directly tests the candidate held-out set-size scalp-only prediction of recorded iEEG contact waveforms, or only establishes adjacent scalp–sEEG dependence analyses.
- Inputs: IEEE Xplore record for DOI `10.1109/IEEECONF67917.2025.11443669`; Houston Methodist Scholars record; official Asilomar 2025 advance program; OpenAIRE metadata; targeted exact-title/full-text searches.
- Data boundary: publication-access investigation only. No local recordings, event rows, confirmation outcomes, model fits, or synthetic signals accessed or generated.

## Search and access result

The Houston Methodist institutional publication record exposes the abstract, bibliographic record, and DOI link, but no manuscript attachment. The IEEE Xplore document endpoint returned an access/JavaScript challenge in this environment; the IEEE abstract record remains accessible. The official Asilomar advance program confirms that the paper was listed in session TP8b1.7, but contains no methods or results. OpenAIRE and other search-index records reproduce bibliographic metadata/abstract text rather than the five-page paper. An OpenAlex DOI record reports closed access, no OA URL, and no repository full text. Exact-title searches for an author manuscript or public PDF returned no verified full text. The ResearchGate results located during the search were for the authors' separate 2026 EEG source-estimation review, not this conference paper.

## What can and cannot be concluded

The accessible abstract establishes that Phillips et al. analyze synchronous scalp EEG and sEEG using Spearman correlation, mutual information, and directed information across spatial, temporal, and spectral relationships, and discuss temporal windows and depth/frequency effects. This preempts a broad claim that scalp–sEEG dependence or information-theoretic characterization is new.

The accessible records do not reveal the cohort, task, target variable, conditioning variables, split unit, held-out conditions, estimators in detail, or whether any predictive evaluation targets measured iEEG contact waveforms. Therefore exact overlap with a scalp-only, fully held-out working-memory set-size prediction task remains **unknown**. Lack of a public manuscript in this search is not evidence of novelty. Do not infer a task distinction from the abstract's silence.

## Decision and next action

- Keep B2 IN_PROGRESS; this retrieval attempt does not satisfy the task-level comparison or independent-review requirement.
- Preserve Phillips et al. as prior art for scalp–sEEG dependence, with exact predictive-task overlap explicitly unknown.
- If a lawful full-text copy becomes available through the user or an authorized library/account, compare cohort, input, target, covariates, split, condition holdout, metrics, and code/data access before revising the task decision.
- Until then, do not make a priority or novelty claim and do not fit a Track B model.

## Records inspected

- [IEEE Xplore document record](https://ieeexplore.ieee.org/document/11443669) (full-text endpoint inaccessible here)
- [Houston Methodist Scholars publication record](https://scholars.houstonmethodist.org/en/publications/characterizing-the-relationship-of-non-invasive-and-invasive-neur/)
- [Official Asilomar 2025 advance program](https://asilomarssc.org/AS25_AdvanceProgram_v006.pdf)
- [OpenAIRE bibliographic record](https://oamonitor.ireland.openaire.eu/national/search/publication?pid=10.1109%2Fieeeconf67917.2025.11443669)
- [OpenAlex DOI record](https://api.openalex.org/works/https://doi.org/10.1109/IEEECONF67917.2025.11443669) (reports no open-access location or repository full text)

