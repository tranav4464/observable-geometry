# B2 task-window phase mapping audit

## Session identity

- Run ID (UTC): `20261022T204000Z_b2_maintenance_window_mapping`
- Date/operator: 23 October 2026, Codex
- Gate before work: B2 IN_PROGRESS; B-1, B0, B1 PASS
- Environment: metadata-only Python audit; no GPU required
- Dataset: pinned NEMAR on004752 v1.0.0

## Decision this work can change

Map the task's final-two-second maintenance analysis window onto the released 8-second paired EEG/iEEG trial epoch, or leave the primary candidate time window unresolved. This is the earliest remaining timing ambiguity for the B2 held-load candidate.

## Inputs and access boundary

- Read Appendix A.4 of the primary WBEN paper, Yang & Liu, NeurIPS 2025, directly from the official proceedings PDF. The retrieved PDF SHA-256 was `2c55f55c187ebc55c4e560f9859d0c11bc809af22055564f6842218a78ad6efc`; Appendix A.4 states epoch phases [0,1), [1,3), [3,6), [6,8) seconds, specifically uses the final two seconds of maintenance, and downsamples both modalities to 50 Hz.
- Read primary-source task timing from Boran et al. 2020, [Scientific Data](https://pmc.ncbi.nlm.nih.gov/articles/PMC6972902/), Methods and Fig. 3.
- Read the aligned NEMAR companion dataset's trial timing, [dataset page](https://nemar.org/dataset/nm000363), which describes probe-relative spike times and maps them to the paired epoch as `onset(nTrial) + spike_time + 6 s`.
- Read only `events.tsv` files for the 14 paired development sessions from sub-01 through sub-03. The script verifies 686 8-second event bounds and sampling-grid sample counts.
- No EDF payload, signal sample, confirmation participant, model outcome, or generated/synthetic signal was read or produced.

## Derivation and result

WBEN Appendix A.4 directly defines the epoch phases: fixation [0,1), encoding [1,3), maintenance [3,6), response [6,8), and explicitly selects the final two seconds of maintenance. NEMAR's trial alignment independently places probe onset at +6 s relative to the released trial onset. Thus the final two maintenance seconds are [4,6) s. On the paper's 50 Hz grid, this half-open interval maps to zero-based sample slice `[200:300]`, 100 samples per trial. The original dataset's Fig. 3 independently uses the final two seconds of maintenance for EEG/iEEG spectra.

The metadata check passed for all 14 development pairs and 686 trials. This confirms the task-phase/sample-index mapping, not signal quality, exact physiological phase synchronization, predictive performance, statistical power, or novelty. The endpoint remains a candidate protocol choice pending preprocessing and metric decisions. The WBEN PDF specifies the common 50 Hz target rate but not the digital anti-alias filter/resampling implementation. That omission, plus conflicting BIDS cutoff metadata and blank EDF prefilter fields, keeps the preprocessing-reproduction claim unresolved.

## Exact command and artifact

```powershell
python scripts\track_b\audit_dev_maintenance_window.py --dataset-root data\track_b\on004752_v1.0.0 --output outputs\track_b\20261022T204000Z_b2_maintenance_window_mapping\window_audit.json
```

Result: `window_audit.json`.

## Decision and next action

Record `[4,6)` as the evidence-supported candidate for the held-load challenge and keep it distinct from WBEN's full-epoch, phase-network analysis. Do not call B2 complete. Next, finish the filtering/channel-quality contract, model boundary and per-trial state reset, baseline, scoring, and uncertainty plan; then obtain independent review before accessing confirmation outcomes.
