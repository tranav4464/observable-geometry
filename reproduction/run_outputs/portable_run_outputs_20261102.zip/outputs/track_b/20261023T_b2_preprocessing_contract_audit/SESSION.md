
## Erratum added 2026-10-23

The original frequency-response calculation used `firwin(101, 0.1, window=('kaiser', 5.0))` and incorrectly attributed that separate filter to SciPy's default `resample_poly(up=1, down=10)`. Inspection of the installed SciPy 1.18.1 source shows `half_len = 10 * max_rate`, so the actual default design uses 201 taps. The real-trial resampling calls in this run did invoke SciPy's actual default and remain valid; only the separately calculated tap count and response summary were wrong. The crop-versus-full-trial relative differences are recomputed and unchanged in `outputs/track_b/20261023T_b2_preprocessing_contract_audit_v2/resampling_audit.json`. Do not use the v1 filter-response values; preserve them here as the original error record.
