# B2 feasibility derivation: scalp-only WBEN inference for held-out iEEG

**Decision this derivation can change:** whether the selected WBEN state-space model can be evaluated on a held-out measured-iEEG target without allowing test iEEG into inference.

**Scope:** algebraic derivation from the audited WBEN model, not implementation or validation. No signals, event rows, reserved participants, synthetic data, or model outputs were accessed or generated.

## Model form

WBEN uses a VAR(p) latent state with scalp and intracranial observation equations:

`x_t = Σ_{k=1}^p Φ_k x_{t-k} + n_t`

`y_t = L x_t + w_t`

`z_t = C x_t + e_t`

Augment the VAR into a first-order state `s_t = [x_tᵀ, x_{t-1}ᵀ, …, x_{t-p+1}ᵀ]ᵀ`. Then `s_t = F s_{t-1} + q_t`, scalp data satisfy `y_t = H_y s_t + w_t`, and the held-out iEEG output is `z_t = H_z s_t + e_t`, where `H_y = [L, 0, …, 0]` and `H_z = [C, 0, …, 0]`.

## Leakage-safe inference mode implied by the model

1. Fit model parameters and noise covariances using training trials only, where both scalp EEG `y` and regional iEEG `z` are available to the WBEN training algorithm.
2. For each held-out trial, initialize the latent-state prior from training-only estimates. At test time, run the Kalman filter using only the held-out scalp sequence `y_1:T`. The held-out iEEG sequence is not passed into the filter or smoother.
3. At each time point, predict `ẑ_t = H_z m_{t|t}`, where `m_{t|t}` is the scalp-only latent-state posterior mean. The predictive covariance is `H_z P_{t|t} H_zᵀ + R_z`, with `P_{t|t}` from the scalp-only filter and `R_z` estimated from training data.
4. Compare `ẑ` to the measured held-out `z` only after predictions are frozen. This evaluates prediction of the specified measured regional iEEG signal under the chosen map. It does not validate the full latent network, unobserved regions, or causal edges.

For an offline full-trial analysis, an RTS smoother may use all scalp samples `y_1:T`; it must still exclude every held-out iEEG sample. For an online BCI-style claim, use the causal filter only. These are different deployment settings and must not be pooled into one endpoint.

## What this establishes

The WBEN state-space equations admit a mathematically coherent scalp-only test-time prediction mode. Therefore the model/task mismatch is not a mathematical impossibility. However, the paper does not report this held-out-iEEG evaluation, and deriving the mode does not make it a faithful reproduction of the paper's reported real-data analysis. It is a proposed inference adaptation that must be explicitly labeled and tested against matched real-data baselines.

The derivation depends on a valid training/test target operator `C`, a known region map, a fitted lead-field operator `L`, training-only parameter estimation, and an agreed temporal relation. `C` is still blocked by the unresolved contact-to-Harvard–Oxford mapping. A defensible named mapping variant could support only a limited application claim, not exact WBEN fidelity, unless the authors' contact-assignment rule is recovered.

## Feasibility decision

**Pass:** an inference-only construction exists that prevents test-iEEG leakage and follows the linear-Gaussian model.

**Not passed:** code implementation, real-data predictive feasibility, exact regional map, protocol lock, and mathematical novelty.

**Stop condition:** if a training-only `C` cannot be established without unsupported anatomy, do not report regional WBEN prediction; pivot to an explicitly contact-level model/task and reopen the base selection. Do not substitute a direct regression model while labeling it WBEN.

## Primary method source

- Yang & Liu, NeurIPS 2025, official record and paper: https://proceedings.neurips.cc/paper_files/paper/2025/hash/82a6afb1f666daaeec8da4d775452bc7-Abstract-Conference.html
- Local equation audit: `docs/track_b/B0_WBEN_NEURIPS_2025_AUDIT.md`
