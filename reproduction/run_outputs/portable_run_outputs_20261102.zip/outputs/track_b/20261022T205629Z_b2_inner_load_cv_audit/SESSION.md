# B2 inner load-holdout tuning split feasibility

## Session identity

- Run ID (UTC): `20261022T205629Z_b2_inner_load_cv_audit`
- Date/operator: 2026-10-23 local; Codex
- Gate and status before work: B2, IN_PROGRESS
- Git commit / working-tree state: no `.git` directory is present at the workspace root; no commit hash available.
- Environment lock / CPU-GPU: metadata-only Python audit; CPU, no GPU required
- Dataset: pinned NEMAR `on004752` v1.0.0; only event tables for sub-01 through sub-03

## Decision this work can change

- Decision question: is the current five-fold random whole-trial inner split appropriate for choosing hyperparameters for the candidate held-load transfer endpoint, or should inner validation hold out one of the two outer-training loads?
- Why this is the earliest unresolved gate: B2 must freeze leakage-safe splits and a tuning rule aligned with the estimand before any model fitting.
- Smallest decisive check: count artifact-flagged and unflagged trials in two leave-one-source-load-out inner folds for each participant × outer held-load combination.
- Expected artifact: deterministic script, JSON counts, and this audit record.
- Stop condition: if any inner fit or validation partition is empty, reject this split candidate; nonempty counts alone do not establish adequate power or model feasibility.

## Inputs and leakage check

- Input files: `data/track_b/on004752_v1.0.0/sub-01` through `sub-03`, `ses-*/eeg/*_events.tsv` only.
- Read fields: event metadata (`SetSize`, `Artifact`, and available row/session identifiers); no EDF or signal payload.
- Role: development participants only. Participants sub-04 through sub-15 remain sealed.
- Eligibility: report all trials and `Artifact==0` descriptive counts separately. The latter is not a final signal-quality inclusion rule.
- Transformations: none beyond grouping metadata rows by participant, session, set size, and outer/inner split.
- No synthetic data created.

## Prespecified interpretation

- Pass for feasibility: all 18 participant × outer-load × inner-fold partitions have positive fit and validation counts under the descriptive artifact-unflagged count; record all-trial counts too.
- Fail: any empty partition or inconsistent load/session mapping.
- A successful count audit would support only split feasibility. It would not establish statistical power, independence of repeated sessions, model fit, transfer accuracy, or utility.
- Compare the design to the prior five-fold trial split: the old split spreads both available loads across inner train/validation, so it primarily estimates interpolation among observed loads rather than the candidate's unseen-load transfer.

## Execution record

- Command: `.venv/Scripts/python.exe scripts/research/audit_dev_inner_load_holdout.py --dataset-root data/track_b/on004752_v1.0.0 --output outputs/track_b/20261022T205629Z_b2_inner_load_cv_audit/inner_load_holdout_counts.json`
- Result: all 18 expected folds were nonempty; minimum fit and validation counts were 46 all-trial rows and 44 `Artifact==0` rows.
- Independent output checks asserted the expected fold count, zero empty descriptive folds, and the explicit no-signal/no-confirmation/no-synthetic flags.
- SHA-256 script: `9D481EB6C94EBCA101A116C54C5AEA8F80A90E2B8F3493290EDF1ED51B15A4D1`.
- SHA-256 result: `A015CCD53EECB81613C2BED3E0AF9BD6E718B4735C7652164497167E9D33AF9E`.
- GPU not used; this metadata count task has no relevant GPU workload.

## Decision and follow-up

- Outcome: supported with limits
- The metadata check produced all 18 expected folds (3 development participants × 3 outer held loads × 2 inner directions). Every fit and validation fold is nonempty: the minimum all-trial count is 46, and the minimum `Artifact==0` descriptive count is 44. The inner folds include all sessions and therefore do not test session transfer. See `inner_load_holdout_counts.json`.
- Decision: supersede the five-fold trial-randomized split as the preferred tuning design for the held-load candidate. For each outer held-load evaluation, use two inner folds that train on one source load and validate on the other. This mimics a load shift and keeps the outer held load untouched. Average the two validation-load NRMSE values equally within each outer training set, with each target contact weighted equally; calculate normalization scales from each inner fit partition only. This remains a protocol candidate until independent review and model-fitting feasibility checks.
- The count result does not establish power, model convergence, performance, or session/participant transfer. Keep B2 IN_PROGRESS.
- Next earliest action: specify the candidate tuning grid, failure/tie rules, and exact score implementation, then review the complete B2 task before any model fit.

