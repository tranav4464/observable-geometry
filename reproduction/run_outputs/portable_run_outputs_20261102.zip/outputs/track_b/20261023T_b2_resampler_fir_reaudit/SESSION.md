# B2 resampler FIR specification re-audit

## Decision record before inspection

- Run ID: `20261023T_b2_resampler_fir_reaudit`
- Gate: B2, IN_PROGRESS
- Decision: Does the existing 101-tap filter-response description match SciPy 1.18.1 `resample_poly(up=1, down=10, window=('kaiser', 5.0))` used by the active real-data preprocessing path?
- Why now: The active spec calls 101 taps the polyphase filter, while SciPy's standard default design may use a different length. Incorrect filter-response attribution could misstate the preprocessing adaptation.
- Smallest decisive check: inspect the installed SciPy 1.18.1 implementation and compute its FIR length/response from source-defined parameters; compare with the existing reported 101-tap diagnostic.
- Inputs: installed package source, existing audit script and JSON. No EEG/iEEG files, event rows, or synthetic signal values.
- Expected artifact: a new, immutable correction record stating the actual tap count and updated response, or evidence that the existing figure is correct.
- Pass interpretation: current spec and audit distinguish the real resampler's filter from any separately computed diagnostic filter.
- Stop condition: if the installed version/source cannot be verified, do not replace the existing figure; leave the discrepancy unresolved.
- Restrictions: no neural data access, no synthetic data, no model fit, no alteration of raw data or previous audit output.

## Scope amendment before execution

The original source-inspection check found a real tap-count discrepancy. To ensure the corrected specification reflects the filter used on actual data, this re-audit will rerun the existing 14-session real development-only compatibility check with the same real first trial from sub-01..03 and corrected FIR-response calculation. It will write to a new versioned output directory and will not overwrite the original audit. No confirmation participant files or synthetic data will be accessed or generated.

## Execution findings

- Installed SciPy was 1.18.1. Its inspected `resample_poly` source uses `half_len=10*max_rate` and `numtaps=2*half_len+1`; for `up=1`, `down=10`, this is 201 taps. The original B2 audit's explicit `firwin(101, 0.1, ...)` response calculation was not the default resampler filter.
- The active resampling script was corrected to compute the response from SciPy's actual source-defined defaults and to write a new v2 output without overwriting the original audit. It reprocessed the same one real first trial in each of the 14 development sessions using the actual SciPy resampler; all shapes and finite checks passed. The full-trial versus crop-first difference remained mean 2.3384%, maximum 5.4842%.
- Correct 201-tap response: mean +0.0061 dB over 0.5–50 Hz, mean −2.7329 dB over 90–100 Hz, and mean −68.1762 dB over 110–200 Hz. The v1 response numbers are superseded; its real-trial resampling and crop-boundary comparisons remain valid.
- New authoritative output: `outputs/track_b/20261023T_b2_preprocessing_contract_audit_v2/resampling_audit.json`; corrected reusable script: `scripts/research/audit_b2_resampling_preprocessing.py`.
- No confirmation participants, synthetic signals/data, or model fitting were used.

## Decision

The actual preprocessing path was always using SciPy's 201-tap default. The active specification had misstated the filter length and response because the audit diagnostic reconstructed the wrong coefficient vector. The active B2 spec now records the correct filter and response, and the old audit session is annotated with this erratum. This does not alter the chosen resampling call or the observed real-data compatibility result; it corrects its reported filter characterization.
