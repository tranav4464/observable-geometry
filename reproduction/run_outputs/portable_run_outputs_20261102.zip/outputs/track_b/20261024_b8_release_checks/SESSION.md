# B8 release-check session

- Run date: 2026-10-24
- Scope: package, CLI, saved-output parity, and applicable software tests for the bounded GBFs build.
- No held-out participants or new EEG outcomes were accessed.
- The active test suite passes 76/76 tests with the plain `python -m pytest -q` command and no exclusions; machine-readable results and logs are in this directory.
- Wheel 0.1.2 was built from a fresh source-only staging copy to avoid stale contents in the repository build directory.
- The clean Python 3.12.14 / NumPy 2.5.4 install reports version 0.1.2, excludes archived simulator modules, and reproduces exact CSV bytes, NPZ arrays, and compared summary metrics from the same sealed model-only bundle (8,196 sources; 40,980 rows).
- Wheel SHA-256: `dc8b241e0320c901d98cf65dc626c8d1131c2f2b6caae6a4bb51b916cce02100`.
- The failed 0.1.1 stale-build check and wheel are retained under `failed_artifacts/` and `clean_install_parity_stale_build_failure_01.json`.
- Data-derived bundle remains under ignored `tmp/`; the source package contains no Localize-MI records or derivative arrays.
- Gate status: B8 IN_PROGRESS. External review or independently witnessed reproduction and final source-snapshot verification remain open.
