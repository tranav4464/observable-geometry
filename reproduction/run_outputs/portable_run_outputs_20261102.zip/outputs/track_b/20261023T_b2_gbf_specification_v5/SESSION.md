# B2 specification review freeze v4

- Active review route: GBFs reproduction/reverse-engineering and nominal source distinguishability under one verified participant-specific forward model.
- Frozen specification: `B2_GBF_SPEC_review_v4.md`.
- SHA-256: `4e9389043b87e967dd02cd84b577f626e9f953e6cfc06bf9ec78a5d4c8cf5e93`.
- Change from v3: explicitly distinguish the GBFs geometric-basis inverse from the direct vertex-level forward-signature diagnostic.
- Review status: awaiting unaffiliated technical review; no approval implied.
- No signal samples, new outcomes, model fitting, or synthetic neural data were accessed or generated.
