# B2 preprocessing contract audit

## Session identity

- Run ID (UTC): `20261022T222100Z_b2_preprocessing_contract_audit`
- Date/operator: 2026-10-23 local time, Codex
- Gate and status before work: B2, IN_PROGRESS
- Workspace state: no Git metadata at workspace root; edits tracked in the run record and decision log.
- Environment: primary-source review plus development-only real-recording preprocessing check; no model training.
- Pinned data: NEMAR on004752 v1.0.0 / OpenNeuro ds004752 v1.0.1.

## Decision this work can change

- Question: Can we specify a deterministic, comparable, test-time-valid 200 Hz preprocessing path for the selected scalp-to-iEEG waveform task using only source-supported properties and permitted development data?
- Why this is the earliest unresolved gate: the current B2 contract explicitly leaves filters, target construction, and exact correspondence to the paper's signal processing open; training before resolving these could make the benchmark uninterpretable.
- Smallest decisive check: reconcile the NeuroFlowNet paper's denoising/downsampling/normalization description with the pinned BIDS metadata and existing verified 200 Hz alignment; identify fixed signal-processing choices versus target-derived transforms and evaluate one development trial through the proposed linear resampler.
- Expected artifact: a source-to-protocol table, real-signal processing audit with no metrics about predictive performance, and a bounded preprocessing recommendation in the active B2 spec.
- Stop condition: if the original acquisition filtering or exact NeuroFlowNet implementation details are not recoverable from primary sources, mark paper-fidelity unresolved and choose a fully specified common-band adaptation rather than infer undocumented filters.

## Inputs and leakage check

- Primary source: NeuroFlowNet v3 full text, Methods 3.2, at https://arxiv.org/html/2603.03354v3.
- Data sources: pinned BIDS sidecars and channel tables; only development participants sub-01 through sub-03 may be opened for event/sample checks.
- Reserved participants: sub-04 through sub-15 event values and signal samples remain unopened; no image or neural outcome from them is used.
- No model fitting, threshold tuning against held-load outcomes, or synthetic dataset generation.

## Prespecified interpretation

- A source-specified filtering or normalization step can be called a reproduction choice only if its order and parameters are explicit in the paper or official acquisition record.
- Fixed anti-alias filtering for 2,000-to-200 Hz decimation is an engineering requirement; it must be explicit, shared across models, and applied separately within event epochs to prevent cross-trial leakage.
- Any transform whose parameters are estimated from target iEEG must not be available to the predictor. If such a transform defines the scored target, describe the endpoint as a transformed/denoised recorded waveform and do not claim full-band physical-amplitude recovery.
- A paper detail that cannot be recovered from source material is an adaptation or unresolved limitation, not a guessed exact replication.

## Execution record

- Primary-source check: He et al., NeuroFlowNet v3, Methods §3.2, https://arxiv.org/html/2603.03354v3 (opened 2026-10-23). It specifies sym4 3-level DWT denoising with a segment-level MAD universal threshold, zero-phase anti-alias low-pass before downsampling, 200 Hz target rate, 1-second windows with 90% overlap for training and no overlap for evaluation, and segment-wise z-scoring. It does not specify numeric anti-alias cutoff/transition, filter coefficients, exact polyphase routine/boundary rule, how its per-segment normalization is inverted to physical units, or fully unambiguous denoising/window ordering. It explicitly cautions that denoising's transient-morphology effect was not evaluated.
- Dataset metadata check: the pinned sub-01/ses-04 EEG and iEEG sidecars report hardware high-pass 0.5 Hz and low-pass 1,000 Hz. The scalp `channels.tsv` values conflict, and the development EDF headers have blank prefilter strings across all channels. Existing header audit: `outputs/track_b/20261022T201600Z_b2_edf_header_filter_audit/SUMMARY.md`. Effective acquisition filtering therefore remains unresolved; no field was silently corrected.
- Failed environment attempt preserved in this record: `.venv_trackb_gpu\Scripts\python.exe scripts/research/audit_b2_resampling_preprocessing.py` stopped before reading data because that environment has no `mne` module. The dataset audit environment was then identified by import check and used successfully.
- Successful command: `.venv\Scripts\python.exe scripts/research/audit_b2_resampling_preprocessing.py` (MNE 1.13.2, NumPy 2.5.4, SciPy 1.18.1). It used MNE's explicit `units="uV"` override supported by the prior channels-table/unit audit, and explicit polyphase filter/boundary arguments. It read the first real paired trial in each of 14 development sessions across sub-01 through sub-03, saved no signal samples, and never opened sub-04 through sub-15. No synthetic data or model fit was used. The script recorded hashes of each EDF read.
- Result: all 14 real trials mapped from 2000 Hz to 200 Hz with finite arrays of 1,600 samples per 8-second epoch and 400 samples in `[4,6)`. `scipy.signal.resample_poly(up=1, down=10, window=('kaiser',5.0))` uses a 101-tap FIR in this case. Its audited mean response was −0.008 dB over 0.5–50 Hz, −4.06 dB over 90–100 Hz, and −56.17 dB averaged across 110–200 Hz. Relative difference between task windows obtained by resampling the full 8-second trial then cropping versus cropping first and resampling was 2.34% mean and 5.48% maximum across these trials. This supports resampling the full trial before the task crop.
- Output: `outputs/track_b/20261023T_b2_preprocessing_contract_audit/resampling_audit.json`; reproducible script: `scripts/research/audit_b2_resampling_preprocessing.py`.

## Decision and follow-up

- Outcome: **common-grid preprocessing candidate supported; exact paper-fidelity and acquisition-filter details unresolved; B2 remains IN_PROGRESS.** The fixed trial-wise polyphase resampler is an explicit adaptation shared across models, not an asserted exact paper reproduction. The DWT denoiser is not included in the primary candidate until its role can be specified without target-scale leakage or unmeasured transient claims.
- B2 updates: active spec now records the resampling candidate, measured response, crop-order result, source omissions, metadata conflict, and limited claim.
- Next action: finish the other B2 exit criteria (matched metric/baseline contract, data-exposure audit, accessible prior-art boundary, paper-pipeline fidelity for selected participants, and independent technical challenge). No model fitting is authorized until B2 passes.
