# Track B research session record

## Session identity

- Run ID (UTC): 20261022T181119Z_b1_sync_source_audit
- Date/operator: 2026-10-22 / Codex
- Gate and status before work: B1 / IN_PROGRESS
- Git commit / working-tree state: workspace has no Git metadata at the project root; source hashes and file records preserve the relevant revision
- Environment lock / CPU-GPU: metadata and source audit only; no compute/GPU
- Data and code versions/hashes: NEMAR on004752 v1.0.0 / OpenNeuro ds004752 v1.0.1; author repository commit `395ae136372be9772cdbeb09bccd677fda01b5d6`; fetched MATLAB script SHA-256 `70EFD92B686ABDEA20362FFAC3D1F7622D4F4481285C1542C7D8236859C43895`

## Decision this work can change

- One decision question: Does the pinned BIDS release contain the signal or event information needed to reproduce/validate the authors' per-trial scalp–intracranial synchronization procedure, so a paired EEG/iEEG prediction endpoint remains defensible?
- Why is this the earliest unresolved gate on the critical path? B1 is the earliest open prerequisite; B2–B8 must not proceed until the paired modalities can be aligned with primary-source support.
- Smallest decisive check: Compare the exact author synchronization script inputs and algorithm with the pinned BIDS files, channel metadata, event definitions, and primary acquisition documentation. Do not inspect reserved participant event rows or signal samples.
- Expected artifact: source synchronization audit, B1 endpoint decision, evidence/decision-ledger entries, and an explicit B1 gate status.
- Stop condition: if required timing signals are absent and event/sample metadata cannot independently establish a common clock from primary documentation, stop the paired sample-level endpoint and evaluate a narrower task or another real dataset.

## Inputs and leakage check

- Inputs opened/read: `docs/track_b/GATE_REGISTER.json`; `docs/track_b/MASTER_RESEARCH_PLAN.md`; `docs/track_b/B1_TASK_AND_DATA_DECISION.md`; `docs/track_b/RESEARCH_SESSION_TEMPLATE.md`; the author MATLAB script in this run folder; local BIDS channel metadata for the 68 paired sessions; event sidecars, event rows, and modality JSON sidecars only for sub-01 through sub-03. The metadata audit is saved at `bids_alignment_metadata_audit.json`.
- Metadata, signal, image, or outcome data: source code, acquisition documentation, and BIDS metadata only; no EDF signal samples and no reserved event-table values.
- Development or held-out role: metadata-only feasibility; no held-out outcomes accessed.
- Could any input reveal a confirmatory outcome? No. No confirmatory event rows, labels, or samples were opened.
- Allowed transformations / preprocessing: no signal preprocessing; compare documented fields and channel inventories only.

## Prespecified interpretation

- Pass condition: primary documentation and released files identify a reproducible alignment rule for paired modalities, including required signals/markers or a validated event-clock mapping, without reading confirmatory outcomes.
- Fail/falsification condition: author procedure uses synchronization inputs not present in the release, while BIDS metadata only align event-relative trial boundaries and do not establish sample-level inter-stream lag/drift.
- What result would change the next decision? Current evidence supports a possible event-relative endpoint but blocks a sample-accurate simultaneous time-series claim; narrow the endpoint or find a real dataset with verifiable common timing.
- Baselines / negative controls: not applicable to this source/metadata audit.

## Execution record

- Exact commands: (1) PowerShell `Invoke-RestMethod` GitHub API query pinned the repository commit and recursive tree; (2) `Invoke-WebRequest` fetched the raw MATLAB file and license at the pinned commit; (3) `.venv_tracka_clean\\Scripts\\python.exe -` ran a Python standard-library audit of channel metadata for all 68 paired sessions and event pairs for sub-01 through sub-03 only. The per-session output is in `bids_alignment_metadata_audit.json`.
- Seeds and configuration: not applicable.
- Warnings, exclusions, failures: no named sync/trigger/stimulation channel was found in 136 channel tables; development EEG/iEEG sidecars declare `TriggerChannelCount: 0`; author source synchronization uses raw continuous channels and NLX data whose conversion into the release is undocumented. Event onsets are sample-derived and are not independent physical-clock evidence. No reserved event rows or samples were read.
- Outputs and checksums: source MATLAB SHA-256 `70EFD92B686ABDEA20362FFAC3D1F7622D4F4481285C1542C7D8236859C43895`; `bids_alignment_metadata_audit.json`; `docs/track_b/B1_SYNC_SOURCE_AUDIT.md`.
- CPU reference and GPU parity evidence, if applicable: not applicable.
- Independent metric/oracle check: compare primary paper, author code, and dataset-release metadata independently.

## Decision and follow-up

- Outcome: inconclusive for sample-level synchronization; positive for event-relative trial matching.
- Interpretation limited to: the 14 development pairs have matched task/trial order and sample-grid-consistent event onsets, but the audit does not establish the continuous intermodal lag or drift. No inference about model performance.
- Ledger/matrix/protocol updates: B1 synchronization audit added; B1 remains IN_PROGRESS; no held-out data were accessed.
- Next earliest gate action: decide whether an event-relative, lag-tolerant endpoint is scientifically faithful to WBEN; otherwise screen a real dataset with verifiable common timing. Preserve sub-04 through sub-15 event rows and samples unopened until protocol lock.
- Reviewer and review result: independent review not yet performed.
