# B2 participant-access scope review

## Session identity

- Run ID: `20261023T_b2_access_exposure_review`
- Date/operator: 2026-10-23 local time, Codex
- Gate before work: B2, IN_PROGRESS
- Workspace: `<LOCAL_ACCOUNT>\OneDrive\Desktop\TKS\observable_geometry`
- Scope: review existing research-session records and audit manifests only; no new participant events or signal samples opened.

## Decision this review can change

- Question: Do the documented data-access records support keeping sub-04 through sub-15 as confirmatory participants for a future B5-locked evaluation?
- Smallest check: inspect every Track B `SESSION.md` that records local event, sample, or participant access, then cross-check the all-participant metadata/header-only audits.
- Stop condition: if any unambiguously confirmatory event values or signal samples were opened, identify and demote the affected participant(s) before defining B5.

## Findings

- The dataset acquisition record says event rows were inspected only for sub-01 through sub-03; no signal samples were analyzed in that acquisition check. Its all-participant audit parsed fixed EDF headers only.
- The synchronization, alignment, task-window, signal-quality, held-load-feasibility, 200-Hz compatibility, and current resampling records report event values and/or signal samples only for development participants sub-01 through sub-03.
- Several cohort-wide checks did read metadata for all participants: channel tables/sidecars, participant and session inventories, file manifests, and fixed EDF headers. Those checks did not read reserved event rows or EDF signal records, according to their session records.
- The current resampling audit read one real trial from each of 14 paired development sessions, saved only summary statistics and file hashes, and did not open sub-04 through sub-15 signal files.
- No reviewed session record reports access to sub-04 through sub-15 event rows or signal samples. On the documented record, these participants' outcomes remain unexposed.

## Evidence reviewed

- `outputs/track_b/20261022T174414Z_b1_on004752_real_data/SESSION.md`
- `outputs/track_b/20261022T181119Z_b1_sync_source_audit/SESSION.md`
- `outputs/track_b/20261022T182222Z_b1_alignment_feasibility/SESSION.md`
- `outputs/track_b/20261022T182700Z_b1_alignment_verification/SESSION.md`
- `outputs/track_b/20261022T202100Z_b2_joint_fold_feasibility/SESSION.md`
- `outputs/track_b/20261022T205915Z_b2_real_signal_quality_audit/SESSION.md`
- `outputs/track_b/20261023T_b2_task_window_source_audit/SESSION.md`
- `outputs/track_b/20261023T_b1_200hz_candidate_task_audit/SESSION.md`
- `outputs/track_b/20261022T174414Z_b1_on004752_real_data/all_participants_header_only_audit.json`
- `outputs/track_b/20261022T181119Z_b1_sync_source_audit/bids_alignment_metadata_audit.json`
- `outputs/track_b/20261023T_b2_all_participant_channel_schema_audit_v2/channel_schema.json`
- `outputs/track_b/20261023T_b2_preprocessing_contract_audit/resampling_audit.json`

## Interpretation and limitation

This is a documentary access audit, not an operating-system-level audit trail. Existing records consistently bound data-bearing reads to sub-01 through sub-03, while documenting metadata-only inspection for the wider cohort. No machine-level file-open history was retained, so the audit cannot prove the absence of an unlogged read. Do not describe participants as completely untouched: their cohort/channel metadata and fixed EDF headers have been inspected. Preserve them only as outcome-unexposed, pending independent B2/B5 review.

## Decision

- Outcome: **documented outcome-access boundary supported; not a proof of no unlogged reads.**
- No participant is demoted based on the reviewed records. Keep sub-04 through sub-15 closed to event-value and signal-sample access until protocol lock.
- B2 remains IN_PROGRESS; this review does not authorize fitting or held-out access.
