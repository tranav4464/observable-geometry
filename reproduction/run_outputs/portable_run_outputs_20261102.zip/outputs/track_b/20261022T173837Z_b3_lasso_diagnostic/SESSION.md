# Research session: B3 L1 optimizer diagnosis

- Run ID (UTC): 20261022T173837Z_b3_lasso_diagnostic
- Gate/status: B3 IN_PROGRESS
- Environment: CPU float64; independent SciPy optimizer used only as a diagnostic oracle if available. GPU not used for this small convergence test.
- Current code SHA256 (wben.py): 3D49E8E0F5423100ABD5B64F8CA10B7BB4E6F457E3C8DA25306104CC84B2997E
- Development input SHA256 (known_truth_inputs.npz): 427CC4834CC025A4FC600BBF918A2D30581E50371BF91AFB278ED7F1FB553284
- Input role: saved known-truth synthetic development simulation; no participant EEG or confirmatory outcomes.

## Decision this work can change

Determine whether the pseudoinverse-initialization failure is caused by the cyclic L1 row solver's numerical convergence criterion, or instead reflects a poorly conditioned/weakly identified transition update. This decides whether to repair the solver, change initialization, or treat the physical-operator case as a model-identifiability limitation.

- Smallest decisive check: reconstruct the first smoother M-step from the saved inputs, report normal-matrix condition and KKT residuals, and compare a representative L1 row against an independent convex optimizer.
- Expected artifact: diagnostic script/output plus a preserved conclusion in the run folder and B3 record.
- Pass condition: an independent optimizer agrees with a numerically stable custom solution and the KKT residual is below a scale-aware tolerance.
- Fail condition: materially different solutions or unresolved KKT conditions at the declared iteration budget.
- Stop condition: if the issue is solver tolerance/conditioning rather than scientific recovery, fix the algorithm and then run one new immutable development fit. Do not scale into a benchmark sweep until the one-seed fit completes reliably.
- Falsifier: if the row solver is correct yet WBEN still produces poor edge recovery, record that as a model/observation challenge, not an optimizer bug.

## Execution record

No confirmatory result is read. The saved arrays are development-only and contain simulated truth. Any modified run receives a new ID; the failed source runs remain unchanged.
