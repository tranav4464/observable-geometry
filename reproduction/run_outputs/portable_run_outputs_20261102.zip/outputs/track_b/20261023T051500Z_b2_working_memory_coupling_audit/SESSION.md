# Working-memory scalp/iEEG coupling prior-art audit

Date: 2026-10-23

## Decision this audit can change

Determine whether the proposed held-out-set-size scalp-to-iEEG prediction task is already answered by work that analyzes paired scalp and intracranial recordings during verbal working memory.

## Primary-source findings

Boran et al. (2019, *Science Advances*, DOI 10.1126/sciadv.aav3687) recorded single-neuron activity, medial-temporal iEEG, and scalp EEG while nine epilepsy patients performed verbal working memory across 36 sessions. Set sizes 4, 6, and 8 letters defined load. The authors report that hippocampal firing predicted workload during maintenance and that hippocampal–scalp theta/alpha synchronization varied with workload. The official NEMAR `on004752` repository cites this paper among the studies associated with its verbal-working-memory data.

Ye et al. (2022, *Journal of Neural Engineering*, DOI 10.1088/1741-2552/ac63e9) analyzed simultaneous scalp EEG and iEEG from nine epilepsy participants in a verbal-working-memory paradigm. It quantified phase-amplitude coupling between low-frequency scalp phase and intracranial high-gamma amplitude, then compared task periods and memory loads. The paper reports load-sensitive coupling and identifies frequency/location combinations. This is direct prior art for load-sensitive cross-modal association and for estimating selected intracranial features from scalp measurements.

Neither abstract describes a model trained on two set sizes to predict measured iEEG waveforms at a completely held-out set size. These papers therefore preempt broad novelty claims about working-memory load, paired scalp/iEEG coupling, or noninvasive estimation of intracranial features, but do not establish that the exact proposed waveform-transfer estimand has been tested. Their results are not a matched baseline for waveform prediction.

## Decision consequence

Keep the held-out-load waveform task as a candidate empirical challenge only. It is not a novel method or discovery on this evidence. B2 remains IN_PROGRESS until the exact target, matched comparator, protocol, and practical decision value are independently challenged. No local data, confirmation outcomes, or model fits were accessed for this literature audit.

## Sources

- Boran et al. 2019, PubMed/PMC: https://pubmed.ncbi.nlm.nih.gov/30944858/ and https://pmc.ncbi.nlm.nih.gov/articles/PMC6436923/
- Ye et al. 2022, PubMed: https://pubmed.ncbi.nlm.nih.gov/35441594/
- Official NEMAR dataset record: https://nemar.org/dataset/on004752
- Official dataset source repository and references: https://github.com/nemarDatasets/on004752

## Search boundary

A targeted search for held-out working-memory-load scalp-to-iEEG reconstruction returned these load/coupling studies and other adjacent reconstruction work, but no verified exact match. A follow-up query explicitly using “leave-one-load-out,” “Sternberg,” “set size,” and scalp-to-iEEG prediction again returned (a) cross-modal load/coupling studies, (b) scalp-only load-label classifiers, and (c) generic scalp-to-iEEG reconstruction. It did not produce a verified paper that trains on two working-memory loads and predicts paired iEEG waveforms at the third. This is a bounded search result, not proof that no such paper exists or that the candidate is novel.

The directly relevant comparisons from that follow-up include Subramanian et al.'s per-second spectral-power prediction from scalp EEG in a separate 20-patient epilepsy cohort and held-out-patient regional analysis, and Boran et al.'s paired recordings and load-sensitive neural/coupling analysis on the verbal working-memory paradigm. Neither is the same held-out-load waveform estimand. Source text: https://pmc.ncbi.nlm.nih.gov/articles/PMC12026988/ and https://pmc.ncbi.nlm.nih.gov/articles/PMC6436923/.
