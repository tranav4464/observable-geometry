# NeuroFlowNet source-dataset lineage check

## Session identity

- Run ID: `20261023T_b2_dataset_lineage_audit`
- Date/operator: 2026-10-23, Codex
- Gate and status before work: B2, IN_PROGRESS
- Working-tree state: workspace files inspected; no Git metadata is present at the workspace root.
- Environment: source review only; no model fit and no participant data accessed.
- Data/code versions: NeuroFlowNet arXiv v3; G-Node dataset descriptor DOI 10.12751/g-node.d76994; NEMAR on004752 repository.

## Decision this work can change

- Question: Does the available NEMAR release establish exact data identity with the dataset used in the NeuroFlowNet paper, so this project can claim a paper-level reproduction?
- Smallest decisive check: Compare the paper's dataset statement and subject count against the original cited G-Node descriptor and the NEMAR release description.
- Stop condition: If the primary records do not provide a participant/file crosswalk, do not infer identity from a shared task or citation; record exact-reproduction status as unresolved.

## Inputs and exposure

- Primary sources reviewed: [NeuroFlowNet v3](https://arxiv.org/html/2603.03354v3); [G-Node dataset descriptor](https://doi.gin.g-node.org/10.12751/g-node.d76994/); [NEMAR on004752 repository](https://github.com/nemarDatasets/on004752).
- Local records reviewed: `docs/track_b/B1_TASK_AND_DATA_DECISION.md`, `docs/track_b/B0_WBEN_NEURIPS_2025_AUDIT.md`, and `docs/track_b/B2_NEUROFLOWNET_SPEC.md`.
- Participant event rows, signal samples, and confirmation outcomes: none accessed.

## Findings

1. NeuroFlowNet v3 identifies its data as the Boran et al. verbal working-memory dataset and describes nine epilepsy patients; it reports results for selected subjects S1, S6, and S9. It states that the source dataset is publicly available at the G-Node repository.
2. The G-Node descriptor for DOI 10.12751/g-node.d76994 also describes nine subjects and CC BY-SA 4.0.
3. The NEMAR `on004752` release describes fifteen subjects and is associated with the Dimakopoulos et al. eLife task publication. The NEMAR companion record `nm000363` explicitly states that the nine-subject Boran dataset's subject, session, and trial labels align to OpenNeuro `ds004752` and that the values were repackaged without change.
4. The prior NeuroFlowNet repository audit records the selected paper subjects S1/S6/S9 as mapping to `sub-01`/`sub-06`/`sub-09`, based on the NEMAR cohort crosswalk. Therefore the source dataset lineage is established for the nine-subject cohort and the paper's selected subjects within the pinned 15-participant release.
5. This resolves the dataset-lineage question. It does **not** mean our implementation has reproduced the published result: preprocessing details, split construction, paper/code discrepancies, model implementation fidelity, and matching the paper's reported metrics still require verification.

## Correction to the initial interpretation

The first draft of this audit incorrectly concluded that no subject/file crosswalk was available because it reviewed the G-Node and on004752 descriptions but missed the NEMAR companion dataset `nm000363`. That conclusion is withdrawn. The primary NEMAR companion record explicitly provides the required cohort/trial alignment. This correction is retained so the decision history is transparent.

## Decision and follow-up

- Outcome: Source dataset lineage confirmed; paper-level experimental reproduction remains unverified.
- Interpretation limited to: NEMAR's published participant/session/trial crosswalk and unchanged-value repackaging statement. It does not verify our pipeline's equivalence to the paper.
- B2 impact: Remove dataset identity as an open blocker. Retain explicit checks of filtering, segmentation, normalization, split, architecture details, and reproduction metrics before B3 can claim a paper-matched reproduction.
- No fitting is authorized by this audit.
