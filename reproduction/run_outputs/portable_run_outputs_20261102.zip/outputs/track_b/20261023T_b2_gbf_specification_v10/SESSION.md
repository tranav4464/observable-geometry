# B2 v9 frozen specification record

Frozen review copy: `B2_GBF_SPEC_review_v9.md`  
Specification SHA-256: `f4da4b7bdd59f375eae21ece9f2dd8bb1b433cdff0c8bfdc5d2862e3711afe04`  
Independent verifier SHA-256: `6e2387c37051b38ebfb717f29b9c5a2d2ad831ac525da5c75688fa7d990000f6`.

Version 9 corrects v8's direct residual tolerance. A float64 residual is computed from the unrounded float64 cosine; the legacy Track A residual is checked by replaying the exact float32 score-to-residual expression. The verifier passed syntax/help checks and four analytical unit tests; it has not loaded real model arrays or recomputed the score. The prior development-array access is disclosed in `outputs/track_b/20261023T_b2_bundle_header_inspection/ACCESS_NOTE.md`.

Additional reviewer material: four analytical tests for the independent verifier passed. Test file SHA-256: 9a4d172d55c400cb3d07a34d4e882b1f2951de4b81246d41392d5984cc753909. These tests use small algebraic matrices only and do not validate the real-data score.

