# Atomic CLI publication and regression run

- Date: 2026-10-29 (Asia/Calcutta)
- Repository HEAD: `af0d86942fdbbd346231ac07bf43078e80713c83`
- Working tree: modified and uncommitted; this is not a clean-HEAD or release test.
- Python: 3.12.14
- Pytest: 9.1.1

## Change verified

The CLI now writes `distinguish`, `robust-audit`, and `family-frontier`
outputs to a temporary sibling directory and renames that directory to the
requested destination only after the output files are complete. Failed
`distinguish` input validation removes the staged directory; a simulated
rename failure also removes staging and emits no success message. An existing
destination is rejected without modifying its contents. This is local
filesystem publication safety, not a security boundary or scientific method.

## Commands and results

- Focused: `.venv/Scripts/python.exe -m pytest tests/test_cli_distinguish.py -q`
  — **5 passed**.
- Full suite: `.venv/Scripts/python.exe -m pytest -q` — **161 passed**.
- Gate register: `.venv/Scripts/python.exe scripts/research/validate_gate_register.py`
  — **PASS**, 230 evidence paths checked, read-only.
- `git diff --check` — passed; Git emitted only existing LF-to-CRLF notices.

The tests use algebraic software fixtures. No EEG/SEEG samples were read.
These results establish tested output-directory behavior and regression
status on the modified working tree; they do not establish a clean package
release, method novelty, calibration or source recovery.

## SHA-256 at verification

- `src/observable_geometry/cli.py`: `B2445F9637454491DF254E67B7B1CA14697A410EF1B4B84669DD22E8383FB39F`
- `tests/test_cli_distinguish.py`: `5D9A8358B1F33ACED94D4E4054E521B1107542BA9D41FB9CAE5F1A6A64F9CD96`
- `README.md`: `53429DB8431AF63DBF5C0D6A49AF4295062B142E4220195590A413ED88C95932`
- `docs/track_b/DECISION_ENDPOINT_ADVERSARIAL_AMENDMENT_20261029.md`: `0DDE1EB31C4B75DEE0F4F162C42CB6B6946F5E611FFE33ACBB97881F2AFBC03B`

