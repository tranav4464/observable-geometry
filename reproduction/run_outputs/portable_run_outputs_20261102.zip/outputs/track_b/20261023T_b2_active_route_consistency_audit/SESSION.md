# B2 active-route and comparator-consistency audit

**Date:** 2026-10-23  
**Gate:** B2, remains IN_PROGRESS  
**Decision reviewed:** whether the active implementation base, endpoint, preprocessing route, and comparison recipe are represented consistently across the authoritative project documents.

## Inputs and role

- `docs/track_b/GATE_REGISTER.json`: authoritative gate state and B2 exit criteria.
- `docs/track_b/B0_CLOSEOUT.md` and `docs/track_b/METHOD_MATRIX.md`: selected base and prior-art boundary.
- `docs/track_b/B2_NEUROFLOWNET_SPEC.md`: candidate protocol and model/comparator definitions.
- `docs/track_b/MASTER_RESEARCH_PLAN.md` and `docs/track_b/PROJECT_DEFINITION.md`: top-level descriptions that must match the active route.

Only project documentation and existing validation tooling were inspected. No participant data, event rows, signal samples, model outputs, synthetic data, or confirmation outcomes were accessed or generated.

## Findings and corrections

1. The master plan and project definition still described WBEN as the active model, retained the withdrawn WBEN/Kalman target as the current task, and described the active B2 task as undecided. Those statements conflicted with the B0 route decision, B2 specification, and gate register. Both top-level documents now identify the clean-room NeuroFlowNet implementation and candidate within-participant held-load contact-waveform evaluation, while keeping novelty and B2 passage unclaimed.
2. The master plan reported the superseded 50 Hz route as active feasibility evidence. It now describes the bounded 200 Hz route checked in B1 and labels the 50 Hz result historical.
3. The B2 training recipe conflated deterministic baselines with a stochastic CNN and left the CNN training loss implicit. It now specifies training-standardized elementwise MSE for CNN fitting, model-specific validation stopping objectives, three seeds for the flow and CNN only, single fits for deterministic mean/ridge baselines, and a held-load-blind selection rule for the strongest non-flow comparator.
4. The mean-waveform baseline is now defined as the training-window arithmetic mean at each contact/sample coordinate.

## Verification and interpretation

- `scripts/research/validate_gate_register.py`: PASS; 176 evidence paths checked on the final register version.
- `tests/test_track_b_gates.py`: 7 passed.
- The review-status updater refreshed the B0–B3 summaries after the documentation changes.
- The B2 gate remains IN_PROGRESS. These edits resolve documentation and protocol-definition inconsistencies only; they do not constitute independent review, model fitting, evidence of prediction performance, a novelty finding, or permission to access confirmation outcomes.

## Stop condition

Do not begin B3 fitting until B2 passes its full exit criteria, including an independent technical challenge of the task, prior-art boundary, data exposure, and protocol.

## Focused source recheck

The task-level prior-art wording was checked against primary records rather than treating a search gap as novelty evidence:

- The full CAST arXiv v1 text reports cross-subject scalp-to-iEEG waveform reconstruction on GIN and ds004752. It calibrates the held-out participant's decoder on paired iEEG before evaluating the remaining data; it does not report withholding an entire working-memory set size. The manuscript's ds004752 task label conflicts with the official dataset record, so its task interpretation remains uncertain. Source: <https://arxiv.org/abs/2605.18897>.
- Boring et al. (2020) train scalp-EEG classifiers on two cognitive tasks and evaluate on a third. This is direct prior art for cross-task EEG load classification, but its endpoint is load classification, not prediction of measured iEEG waveforms. Source: <https://pubmed.ncbi.nlm.nih.gov/32947265/>.
- NeuroFlowNet's primary paper describes within-subject held-trial and held-session waveform evaluation; the paper source does not establish whole-load holdout. Source: <https://arxiv.org/abs/2603.03354>.

These distinctions support keeping the candidate estimand separate from the cited tasks, but do not prove that no closer study exists. Exact task-level overlap remains unresolved; no novelty or priority claim is accepted. This recheck used literature only and did not access local participant records, signals, confirmation outcomes, model fits, or synthetic data.
