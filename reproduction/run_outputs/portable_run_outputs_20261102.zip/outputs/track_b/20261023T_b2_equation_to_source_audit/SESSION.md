# B2 paper-to-source fidelity audit

## Decision record before inspection

- Run ID: `20261023T_b2_equation_to_source_audit`
- Gate: B2, IN_PROGRESS
- Decision: Can NeuroFlowNet's published specification be translated into a clean-room implementation without silently guessing equations or relying on code that has no declared license?
- Why this is the next issue: B2 must establish that the selected baseline is reproducible enough to implement. The paper includes equation and algorithm text, while the author repository was previously pinned and inspected but its license is not declared.
- Smallest decisive check: compare the paper's equations/algorithms against the already pinned repository's relevant source, record internal contradictions and underspecified behavior, and decide which details are explicit, code-resolved only, or remain adaptations.
- Expected artifact: component-level paper/source matrix and a defensible B3 implementation boundary.
- Stop condition: if a necessary component cannot be specified from the paper and public source inspection does not resolve it, preserve as an adaptation or reject exact-reproduction language.
- Scope: paper/repository source only; no local participant data, event rows, signal samples, model execution, copying/adapting source code, or held-out access.

## Execution record

- Primary source opened: He et al., NeuroFlowNet v3, §§2.1–2.4 and 3.2–3.4, https://arxiv.org/html/2603.03354v3.
- Pinned read-only repository verified with `git -C tmp/neuroflownet-review rev-parse HEAD`: `ce1b5120b7a93127e20a83c006190802e72a2b4e`; `git status --short` was empty. SHA-256 values matched the earlier pinned audit for `flow_model.py` (`646cc2b9ccf5203aee2be8ff5f97162beffebad9a5cd7695346eb7e66a335a30`), `train_flow_model.py` (`d4828ff65fb70de7217851ca0f5dbA8c5940c875e80d0da689fa5ada8301c416`), and `preprocess.py` (`7276836d815ab2fa24aea8e90d759d53315c6bbb329848bad28870497402e5a0`).
- Inspection commands: `rg -n -C 2 'tanh|clamp|Coupling|Conv1d|MultiheadAttention|attention|split|num_scales|hidden|temperature|AdamW|scheduler|lr|weight_decay|batch_size|epochs|patience|normaliz|permute|head' tmp/neuroflownet-review/flow_model.py tmp/neuroflownet-review/train_flow_model.py tmp/neuroflownet-review/preprocess.py`; read-only line display of `flow_model.py` and `train_flow_model.py`; paper Methods sections opened in browser.
- No author code was run, copied, modified, or incorporated. No local recordings, event rows, signal samples, synthetic data, or model outputs were accessed or generated.

## Decision and follow-up

- Outcome: **method family is implementable, exact paper replication is not established.** The main coupling forward transform, Jacobians, channel mixing, multiscale split, Gaussian base, and likelihood are specified. The paper has an algebraic inconsistency: its Eq. 1 forward map `(x_b + τ) exp(σ)` is not inverted by Eq. 4/Algorithm 2 `exp(-σ)(z_b − τ)`. The pinned source uses `z_b exp(-σ) − τ`, the exact inverse of Eq. 1. B3 must use the algebraically correct inverse, document the paper correction, and verify it independently. This is a correction for invertibility, not a novel contribution.
- The paper prose bounds translation with `tanh`, while Algorithm 1 and the pinned source use `10 tanh`; the pinned training script also uses 8 attention heads, batch 64, up to 500 epochs, and a ReduceLROnPlateau scheduler, while the paper reports batch 128, up to 100 epochs, and no scheduler in its stated training description. Its scheduler is configured with `mode='max'` but is stepped with validation loss. Do not conflate code behavior with the paper's reported experiment.
- The paper does not fully pin down context concatenation, attention implementation/details, channel-order behavior, or odd-channel multiscale splitting. The pinned code clarifies some choices but cannot be reused because the repository snapshot has no declared license. B3 can be source-informed and clean-room, with each such choice marked as an adaptation.
- Decision effect: exact-reproduction claims are rejected. Keep the project framed as a clean-room method implementation and real-data challenge with explicit corrections/adaptations. B2 remains IN_PROGRESS; no fitting authorized.
