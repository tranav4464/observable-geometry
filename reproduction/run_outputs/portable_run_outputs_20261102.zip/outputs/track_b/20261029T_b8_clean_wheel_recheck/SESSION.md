# B8 clean-wheel and source-provenance recheck

- Date: 2026-10-29
- Base repository revision: `af0d86942fdbbd346231ac07bf43078e80713c83`
- Worktree: modified and uncommitted; the checked wheel was built from the current isolated package-source staging copy.
- Test environment: Python 3.12.14, pytest 9.1.1.
- Full suite: `.venv/Scripts/python.exe -m pytest -q` — **161 passed**.
- Gate validator: `scripts/research/validate_gate_register.py` — **PASS**, 244 registered evidence paths.
- `compileall` for `src` and `scripts/track_b`: **PASS**.
- `git diff --check`: **PASS**; Git emitted line-ending notices only.

## Clean wheel check

The current `0.1.2` wheel was installed into a new Python 3.12 virtual
environment with package dependencies installed from metadata. The installed
CLI imported from the isolated environment and reproduced the prior verified
clean-wheel result on the sealed sub-01 model-only bundle. The parity report
confirms exact ranked-pair CSV bytes (40,980 rows), exact score arrays and
summary values, manifest hash agreement, and the allowlisted model-only input
access. No recorded EEG sample array was accessed.

The separate source verifier confirms all 18 packaged Python modules match
the staged source and current checkout byte for byte. The staged README,
license and `pyproject.toml` also match the current checkout.

## Key artifacts

- Wheel: `outputs/track_b/20261029T_atomic_cli_real_model_reproduction/wheelhouse/observable_geometry-0.1.2-py3-none-any.whl`
- Wheel SHA-256: `e145c5d9f6e5a32408b0065bf838436dd97ed17757cdd4d6799ada110a63a582`
- Fresh-environment parity: `outputs/track_b/20261029T_atomic_cli_real_model_reproduction/fresh_clean_env_cli/clean_environment_parity.json`
- Fresh-environment metadata: `outputs/track_b/20261029T_atomic_cli_real_model_reproduction/fresh_clean_env_cli/clean_environment_installation.json`
- Source-to-wheel verification: `outputs/track_b/20261029T_atomic_cli_real_model_reproduction/wheel_source_verification.json`
- Source verifier: `scripts/research/verify_wheel_source.py`

The checked outputs match the prior reference CSV SHA-256
`847d248a5155818d234436a6e874ad8d5c2cf30aee1015b00053754e8359bab4`.

## Scope limit

This closes a current clean-environment package/parity gap for one model; it
does not close B8. The wheel keeps version `0.1.2`, derives from an
uncommitted worktree, and has not received an unaffiliated outside
reproduction. The result is software reproducibility, not source physiology,
source recovery, decision utility, or novelty.
