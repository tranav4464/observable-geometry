# B2 metric and comparator contract review

## Session identity

- Run ID: `20261023T_b2_metric_contract_review`
- Date/operator: 2026-10-23 local time, Codex
- Gate: B2, IN_PROGRESS
- Scope: specification-level review of the NeuroFlowNet paper, existing development-only split-feasibility records, and current active spec. No neural samples or held-out outcomes were opened; no model was fitted.

## Decision

Can we define a participant-level score and matched comparator set for late-maintenance held-load prediction without treating contacts, windows, or load folds as independent subjects or using held-load target scales?

## Prespecified contract entered into the active B2 specification

- Use the same outer leave-one-set-size-out folds for every model. In each outer fold, use two inner whole-load folds: fit on one of the two outer-training set sizes and validate on the other. The initial five-fold within-load split is rejected for tuning because both set sizes appear in every validation fold and it does not test load-shift selection. The new development-only audit found all 18 inner load-holdout folds nonempty; train and validation counts each range from 44–126 Artifact==0 trials. This supports split feasibility only, not power or performance.
- Fit every channel mean/scale using outer-training samples only; use those same statistics for training, validation, held-load transforms, and physical-unit inverse scaling. Never use held-load iEEG statistics for model inputs, amplitude restoration, tuning, or checkpoint selection.
- Primary point estimate: conditional-flow mean from 100 fixed-seed draws. Primary score: contact-normalized RMSE where denominator is the contact's standard deviation on the outer training loads. Macro-average contacts, then the three held-load folds, to obtain one observation per participant. The primary contrast is CNF minus the deterministic comparator selected on inner validation only.
- Distribution score: empirical CRPS from the same 100 conditional draws in training-standardized units, using the exact empirical-distribution CRPS formula in the active spec. Reliability: marginal 50%, 80%, and 90% interval coverage and interval width; do not claim simultaneous multichannel coverage from marginal intervals.
- Uncertainty: paired 95% participant bootstrap after fold averaging; participants are the sampling units. Folds, windows, channels, and samples are not independent replicates.
- Comparators: training-fold mean, ridge/pointwise linear, paper shallow 1D CNN, paper 1D U-Net, paper tiny Transformer, and clean-room conditional flow. All learned models use identical inner assignments and a matched hyperparameter-trial budget; report each baseline and choose the strongest deterministic comparator using inner validation only.

## Source and interpretation

He et al. specify a pointwise linear, shallow CNN, non-causal U-Net, and tiny Transformer comparator under the same subject/split/window conditions. They report tuning of flow scales, steps, and hidden width, AdamW settings, and early stopping, but several architecture details remain insufficiently specific for exact source-level reproduction; missing details must be listed rather than guessed. See https://arxiv.org/html/2603.03354v3, Methods §§3.2–3.4.

The current contract evaluates leakage-safe condition transfer and distributional reliability; it does not by itself establish an innovative new algorithm. Do not use novelty language. The project can still produce a rigorous, useful software build and a scientifically bounded stress test of the published approach.

## Remaining before B2 passes

The exact hyperparameter-trial count and optimizer-step/early-stopping budget must be frozen in B5 from development-only implementation feasibility, along with sample seeds, eligible-participant rule, handling of nonfinite/zero-scale channels, uncertainty interval implementation, and practical interpretation threshold. Also complete accessible prior-art comparison, paper-pipeline fidelity accounting, and an independent technical challenge. B2 remains open; no fitting authorized.
