# B2 pre-review safe regression check

**Run ID:** `20261023T155321Z_b2_safe_regression`  
**Date:** 2026-10-23  
**Purpose:** Recheck the independent B2 calculator's analytical fixtures and existing nominal-score unit tests without reading neural data or model arrays.

## Result

The first combined pytest invocation failed during collection because the source package was not on `PYTHONPATH`. This was a test-environment configuration error, not a test failure. After setting `PYTHONPATH=src`, the same command passed: **13 tests passed** (4 independent-calculator analytical matrix tests and 9 existing nominal implementation tests).

The gate-register validator also passed read-only validation: B-1/B0/B1 PASS, B2 IN_PROGRESS, and B3-B8 NOT_STARTED; 58 evidence paths checked.

## Scope and limits

The four B2-specific tests use small algebraic matrices and coordinates only. No neural data, recorded EEG samples, saved forward-model arrays, real score outputs, synthetic neural dataset, or fitted model were accessed or generated. This verifies implementation invariants only. It does not independently validate the real-data score, satisfy unaffiliated review, or pass B2.

## Commands and outcomes

- Initial: `.venv\\Scripts\\python.exe -m pytest tests\\test_b2_independent_calculator.py tests\\test_nominal.py -q` — collection error (`observable_geometry` not importable because `src` was absent from `PYTHONPATH`).
- Corrected: `$env:PYTHONPATH='src'; .venv\\Scripts\\python.exe -m pytest tests\\test_b2_independent_calculator.py tests\\test_nominal.py -q` — **13 passed**.
- `.venv\\Scripts\\python.exe scripts\\research\\validate_gate_register.py` — **PASS**, read-only.

## Inputs and code identity

- B2 independent calculator: `scripts/research/recompute_gbf_cpu64.py`, SHA-256 `6e2387c37051b38ebfb717f29b9c5a2d2ad831ac525da5c75688fa7d990000f6`.
- Analytical test file: `tests/test_b2_independent_calculator.py`, SHA-256 `9a4d172d55c400cb3d07a34d4e882b1f2951de4b81246d41392d5984cc753909`.
- Active frozen specification: `B2-GBF-2026-10-23-v9`, SHA-256 `f4da4b7bdd59f375eae21ece9f2dd8bb1b433cdff0c8bfdc5d2862e3711afe04`.

## Next action

Keep B2 IN_PROGRESS. Obtain unaffiliated review of the exact frozen v9 specification; resolve findings before running the registered CPU float64 real-artifact recomputation.
