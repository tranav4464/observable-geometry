# B2 new-prior-art recheck: 2026 scalp-to-iEEG work

## Session identity

- Date: 2026-10-23
- Gate: B2 formal specification, still IN_PROGRESS
- Decision affected: whether the held-load contact-waveform task remains a defensible challenge benchmark and how narrowly the project may describe the research gap.
- Inputs: IEEE Xplore abstract and institutional publication record for Phillips et al. (2025); full arXiv records for NeuroFlowNet (arXiv:2603.03354), CAST (arXiv:2605.18897), and the 2026 virtual-iEEG landscape review (arXiv:2608.26998); current local B2 audits.
- Data boundary: literature only. No local signals, event rows, held-out outcomes, model fits, or synthetic signals accessed or generated.

## Findings

### Phillips et al. (published conference paper; full methods not obtained)

The IEEE Xplore record and Houston Methodist institutional record identify Phillips et al., *Characterizing the relationship of non-invasive and invasive neural recordings: An information-theoretic analysis of the scalp and stereo electroencephalography*, ACSSC 2025, pp. 1602–1606, DOI `10.1109/IEEECONF67917.2025.11443669`. Its abstract describes synchronous scalp EEG and sEEG analyses using Spearman correlation, mutual information, and directed information, including spatial, temporal, spectral relationships, depth/frequency effects, and temporal-window selection. It studies cross-modal relationship and feasibility. The abstract does not establish that the paper predicts measured iEEG waveforms from scalp-only input at a held-out working-memory load, nor provide the cohort, split, score, or code details needed to compare it exactly. Full methods remain unavailable in the inspected official/institutional records; do not report the exact overlap as settled.

### 2026 scalp-to-iEEG reconstruction work

- NeuroFlowNet (arXiv:2603.03354) explicitly claims contact-level intracranial waveform reconstruction from scalp EEG using conditional normalizing flows and reports waveform, spectral, and connectivity metrics. Its abstract and linked arXiv record confirm it as direct prior art for generic scalp-to-iEEG waveform reconstruction. The currently inspected record does not settle whether it evaluates a fully withheld task condition on the same on004752 cohort. It is not a matched baseline without matching cohort, target, split, preprocessing, and calibration access.
- CAST (arXiv:2605.18897) reports cross-subject waveform reconstruction on GIN and ds004752, using target-participant paired calibration/decoder adaptation. The paper mislabels ds004752 as visual categorization although the official release is verbal working memory. Its evaluation is therefore prior art for generic same-dataset/cross-subject reconstruction, not a verified matched held-load comparator. This is consistent with the existing CAST audit; the new literature review independently catalogs CAST in the reconstruction landscape.
- The 2026 review/preprint *Virtual iEEG from Scalp EEG: Charting the Landscape of Source Imaging, Intracranial Inference and Reconstruction* (arXiv:2608.26998) explicitly distinguishes waveform reconstruction, hidden-event inference, source imaging, and representation transfer. It describes NeuroFlowNet as patient-specific cross-trial/session work, CAST as target-patient-adapted cross-patient work, and Dong et al. as scalp-only test inference after paired supervision. It warns that scalp-only inference at test time does not imply absence of target-patient iEEG from fitting or calibration, and that split units and calibration access define different generalization claims. This is a literature review/preprint, not an independent experiment or proof of priority.

## Consequence for Track B

The generic claims “predict iEEG from EEG,” “reconstruct intracranial waveforms,” “analyze scalp–sEEG dependence,” and “transfer across task/patient” are occupied. The proposed held-out set-size/contact-waveform task on on004752 remains only an exact evaluation question not verified in the inspected sources; search absence is not novelty evidence. The Phillips paper's abstract is relevant and the full methods gap remains material. No new mathematical method is accepted. Keep the project framed as a real-data replication/challenge benchmark, and retain the candidate held-load protocol only if an independent reviewer finds the task scientifically useful despite these prior studies. If not, reopen the base/task decision rather than relabeling standard prediction as an innovation.

## Decision and next action

- B2 remains IN_PROGRESS; this audit does not authorize fitting.
- Add Phillips et al. and the 2026 reconstruction landscape to the prior-art matrix and evidence ledger.
- Before B2 can pass, complete a task-by-task comparison for NeuroFlowNet, CAST, Dong et al., Phillips et al., and WBEN, including cohort, paired calibration access, input, target, split unit, condition holdout, metrics, and code/data availability. Keep unknown fields explicitly unknown.
- The B2 contract needs independent technical challenge after this comparison; no confirmation data may be opened before B5 lock.

## Primary records inspected

- IEEE Xplore, Phillips et al. (2025): https://ieeexplore.ieee.org/abstract/document/11443669
- Houston Methodist Scholars record, Phillips et al. (2025): https://scholars.houstonmethodist.org/en/publications/characterizing-the-relationship-of-non-invasive-and-invasive-neur/
- NeuroFlowNet arXiv record: https://arxiv.org/abs/2603.03354
- CAST arXiv record: https://arxiv.org/abs/2605.18897
- Virtual-iEEG landscape review/preprint: https://arxiv.org/abs/2608.26998
