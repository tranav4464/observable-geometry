# B8 post-registration software quality rerun

**Run date:** 29 October 2026 (Asia/Kolkata)
**Git HEAD during run:** `3cfa693c2be6ab5866df9ae68613236fda937d0e`
**State during run:** uncommitted documentation and evidence-register updates; source and package code unchanged.
**Dataset access:** no EEG/SEEG sample arrays were opened by the test run.

## Commands and results

- Source manifest generation: `python scripts/research/build_source_manifest.py` wrote a 317-file source inventory for the then-current working tree.
- Full suite: `python -m pytest -q --junitxml=outputs/track_b/20261029T_b8_current_review_audit/junit.xml` — **211 passed, 0 failed**, 4.24 seconds.
  - JUnit SHA-256: `323f8117d4357b3684113cc4ae49f228f48e67d60d903ea1dca423131e23aa76`.
  - Pytest output SHA-256: `29078102e150a690c6abd22af250bda0df44b663f4b29f5bdbfd12284942b49b`.
- `python scripts/research/validate_gate_register.py` — **PASS**, 354 evidence paths checked, read-only.
  - Gate states: B-1/B0/B1/B2/B3 PASS; B4/B5/B6/B7 PIVOT; B8 IN_PROGRESS.
  - Gate report SHA-256: `c5da2172a6024e4b7e1a41a13dc35b02d14e4b607ade97dbd3f3a41ee2972145`.
- `git diff --check` passed, with Windows line-ending notices only.

## Limits

This is working-tree software and evidence-index validation. It does not establish physiological source recovery, novelty, analyst decision benefit, WSGZP registration, or outside reproduction. The exact-commit wheel and archive results in `B8_RELEASE_CANDIDATE_3CFA693_20261029.md` remain bound to commit `3cfa693`.
