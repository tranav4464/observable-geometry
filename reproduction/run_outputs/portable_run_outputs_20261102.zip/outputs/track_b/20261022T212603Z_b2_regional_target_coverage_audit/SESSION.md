# Development-only regional target coverage audit

This audit deduplicates contacts across sessions in the previously generated EasyReg/Harvard–Oxford metadata map. It reads only that mapping CSV, not event rows, neural signal arrays, or confirmation participants.

## Results

- **sub-01:** 24/48 distinct contacts assigned; 9 distinct atlas regions.
- **sub-02:** 30/64 distinct contacts assigned; 8 distinct atlas regions.
- **sub-03:** 20/40 distinct contacts assigned; 7 distinct atlas regions.
- Regions shared across all three participants: 3 (cortical:Temporal Pole, subcortical:Left Amygdala, subcortical:Right Hippocampus).

## Consequence for B2

A regional WBEN evaluation can only target recorded regions, not all 69 latent regions. The map leaves substantial contacts unassigned and provides only three common regions across these development participants. This makes an atlas-free contact-level task attractive, but such a model is a WBEN-inspired adaptation, not a faithful WBEN regional reproduction. The mapping itself remains a sensitivity variant, not anatomical ground truth. B2 remains open.

The complete labels, source hash, and conflict check are in `region_coverage.json`.
