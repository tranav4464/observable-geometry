# Development paired-channel inventory

Across the 14 sessions from sub-01 through sub-03, scalp montage sizes are stable within each participant but differ between participants:

| Participant | Sessions | Scalp EEG channels | iEEG contacts | Shared scalp channels across subjects |
|---|---:|---:|---:|---:|
| sub-01 | 4 | 19 | 48 | 8 |
| sub-02 | 7 | 8 | 64 | 8 |
| sub-03 | 3 | 8 | 40 | 8 |

The common scalp channels are A1, A2, C3, C4, F3, F4, O1, and O2. EEG channels are listed at 200 Hz and iEEG at 2,000 Hz, both in microvolts. EEG sidecars describe the reference as “electrode near the vertex.” The development channels.tsv files do not provide a `status` column, so there are no explicit good/bad channel flags.

There is a filter-metadata conflict. EEG channels.tsv lists `low_cutoff=1000` and `high_cutoff=0.5`, while the BIDS 1.4 field definitions say low_cutoff is the high-pass cutoff and high_cutoff is the low-pass cutoff. The EEG sidecar instead lists a 0.5-Hz high-pass and 1,000-Hz low-pass. The values may have been transposed in channels.tsv, but this cannot be assumed for preprocessing. Resolve with source provenance or report the uncertainty and define a justified common filter separately.

This is metadata-only evidence. It supports stable within-participant input dimensions but does not validate channel quality, exact reference circuitry, actual filters, or predictive performance. It reads EEG `channels.tsv` and `eeg.json` plus iEEG `channels.tsv` for sub-01 through sub-03 only; it reads no events, signal samples, or confirmation participants. Machine-readable details are in `inventory.json`.
