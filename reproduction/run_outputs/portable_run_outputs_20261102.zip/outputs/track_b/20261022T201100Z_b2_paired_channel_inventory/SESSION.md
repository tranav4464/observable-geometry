# B2 feasibility audit: paired channel inventory (encoding-safe rerun)

## Session identity

- Run ID (UTC): `20261022T201100Z_b2_paired_channel_inventory`
- Date/operator: 2026-10-22 UTC / Codex
- Gate and status before work: B2 IN_PROGRESS; B-1, B0, B1 PASS; B3-B8 NOT_STARTED.
- Workspace state: no `.git` directory is present at the project root.
- Environment: Python standard-library metadata audit on CPU.
- Data version: NEMAR `on004752` v1.0.0, development participants sub-01 through sub-03.

## Decision this work can change

- Decision question: Are scalp channel identities stable across sessions, and do the channel files provide explicit bad-channel status?
- Smallest check: Compare EEG/iEEG channel schemas, names, units, sampling metadata, and EEG sidecar reference across the 14 development sessions.
- Expected artifact: ASCII-safe JSON inventory and this record.
- Stop condition: If input schema varies materially or quality flags are unavailable, keep channel quality handling unresolved in B2.

## Inputs and leakage check

- Inputs: EEG `channels.tsv`, EEG `eeg.json`, and iEEG `channels.tsv` for sub-01 through sub-03 only.
- Data: Metadata only. No event rows, signal samples, or confirmation participants were read.
- An exploratory sub-01 header read initiated this audit; no signal/outcome values were inspected.

## Prespecified interpretation

- Pass: Stable scalp channel identities and units support a fixed per-participant input schema.
- Limitation: Metadata do not prove signal quality or identical physical reference circuitry. Missing status fields do not mean all channels are good.

## Execution

- Command: `python scripts/research/audit_dev_paired_channel_inventory.py --dataset-root data/track_b/on004752_v1.0.0 --output outputs/track_b/20261022T201100Z_b2_paired_channel_inventory/inventory.json`
- Output: `inventory.json`; no random seed, model, preprocessing, or GPU use.
- Prior failed attempt: `outputs/track_b/20261022T201000Z_b2_paired_channel_inventory/SESSION.md`; console encoding failed after its JSON was written.

## Decision

- Outcome: PASS for montage-feasibility inventory; B2 remains IN_PROGRESS.
- Findings: sub-01 has 19 scalp EEG channels in 4 sessions; sub-02 and sub-03 each have 8 in all 7 and 3 sessions. The eight channels common across participants are A1, A2, C3, C4, F3, F4, O1, and O2. EEG is listed at 200 Hz, iEEG at 2,000 Hz, and both use microvolts. EEG sidecars consistently say “electrode near the vertex.” No EEG or iEEG channels.tsv in these development sessions has a `status` column, so bad-channel labels are unavailable.
- Preprocessing blocker: the development EEG channels.tsv files report `low_cutoff=1000` and `high_cutoff=0.5`, while BIDS 1.4 defines these fields as high-pass and low-pass respectively and the EEG sidecars report hardware high-pass 0.5 Hz and low-pass 1000 Hz. This is an internal metadata conflict, likely swapped field values, but it must not be silently corrected. See the official [BIDS EEG v1.4 specification](https://bids-specification.readthedocs.io/en/v1.4.0/04-modality-specific-files/03-electroencephalography.html).
- Next step: Define whether the within-participant model uses each participant's stable native montage or the common 8-channel subset; separately resolve channel-quality and filter provenance before protocol lock.
