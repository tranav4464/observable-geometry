# B2 metric and seed consistency audit

- Run ID: `20261023T_b2_metric_seed_consistency_audit`
- Gate: B2 IN_PROGRESS
- Decision affected: whether the specification maps stochastic training and predictive-draw seeds to reproducible primary and distributional metrics without changing the independent unit.
- Inputs: `B2_NEUROFLOWNET_SPEC.md` §§2, 5, 6, and 7.
- Data boundary: specification/math audit only. No recordings, outcomes, models, or synthetic data accessed or generated.

## Findings and corrections

1. **Draw-seed formula mismatch.** Section 5 defined flow-draw seeds with the `TrackB-v1|` namespace prefix, while section 6 restated the same seed with the prefix omitted. Section 6 now points directly to §5 and names the prefix and byte interpretation. This prevents two plausible implementations from producing different draws.
2. **Window aggregation notation mismatch.** Section 2 averaged residuals over held-load windows and within-window samples (`j,t`), while §6 wrote only `t`. Section 6 now explicitly uses `j,t`, matching the actual two-window-per-trial representation and §2 estimand.
3. **Distribution metric seed aggregation was implicit.** The protocol generated 100 draws for each of three flow training replicates but did not explicitly state how replicate-level CRPS, coverage, and width enter the reported participant summaries. It now computes these metrics per seed, averages seeds equally within participant/load/contact, retains seed-level results, and prohibits pooling seeds or treating them as independent participants.

## Verification and limits

- Algebraic inspection confirms the primary NRMSE retains training-only scale in its denominator and averages window/sample residuals before contact/load aggregation.
- The point score, CRPS, coverage, and width use the same three training-seed hierarchy; participant remains the population uncertainty unit.
- These are specification corrections only. No numerical model or data calculation was performed. Independent review must still challenge whether the estimands and seed-averaging rule are scientifically appropriate.
- B2 remains IN_PROGRESS; this audit does not pass the gate or authorize fitting.

