# Phillips et al. bibliographic and access recheck

- Run ID: `20261023T_b2_phillips_bibliographic_recheck`
- Gate: B2 IN_PROGRESS
- Decision affected: whether the cited Phillips et al. record provides enough accessible methods evidence to resolve exact overlap with the held-load waveform task.
- Scope: public bibliographic and publisher records only. No project recordings, confirmation outcomes, model fits, or synthetic signals accessed or generated.

## Findings

- IEEE's public abstract record and DBLP metadata confirm the full published title: “Characterizing the relationship of non-invasive and invasive neural recordings: An information-theoretic analysis of the scalp and stereo electroencephalography,” Asilomar 2025, pp. 1602–1606, DOI `10.1109/IEEECONF67917.2025.11443669`.
- The IEEE page confirms the abstract's analyses of synchronous scalp EEG/sEEG with Spearman correlation, mutual information, and directed information across spatial, temporal, and spectral relationships.
- The targeted search did not locate a lawful public full-text manuscript. DBLP marks the record closed access; its metadata cannot substitute for methods review.
- The evidence still does not reveal cohort, task, target, split unit, condition holdout, metrics, or code. Exact overlap with the candidate endpoint remains unknown. This is not evidence that the task is novel or unoccupied.

## Effect on B2

Corrected the title in `METHOD_MATRIX.md` and the independent-review packet. No task or novelty decision changed. Keep Phillips et al. as broad prior art, retain the explicit access caveat, and ask the independent reviewer to challenge whether the remaining evidence is sufficient. B2 remains IN_PROGRESS; this search does not authorize fitting.

## Sources

- [IEEE publisher abstract](https://ieeexplore.ieee.org/abstract/document/11443669)
- [DBLP bibliographic record](https://dblp.org/rec/conf/acssc/PhillipsEVBMFA25.html)
- [Houston Methodist institutional record](https://scholars.houstonmethodist.org/en/publications/characterizing-the-relationship-of-non-invasive-and-invasive-neur/)

