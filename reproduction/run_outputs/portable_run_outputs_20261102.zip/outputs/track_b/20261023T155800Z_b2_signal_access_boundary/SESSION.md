# B2 verifier signal-access boundary audit

**Run ID:** `20261023T155800Z_b2_signal_access_boundary`  
**Date:** 2026-10-23  
**Decision informed:** Whether the B2 standalone calculator's stated restriction against reading recorded EEG values is reflected in its current source code and the prepared archive contract.

## Method and result

`scripts/research/audit_signal_access_boundary.py` reads only NPZ ZIP central-directory names and parses the verifier source with Python's AST. It rejects nonliteral archive keys and requires the prepared-bundle references to be exactly `leadfield` and `noise_cov`. It does not decompress an NPZ member or load an array.

The audit result is saved in `access_boundary_audit.json`. The recorded `data` member exists in the prepared bundle, but the verifier source references only the two declared model arrays. The audit is a static access-boundary check; it does not validate numerical correctness or replace the unaffiliated review.

## Stop condition and interpretation

If the check fails, stop before executing the B2 verifier and revise the access path, then obtain review of the revised verifier hash. If it passes, it supports only the claim about the currently inspected source and archive member names. The registered real-artifact recomputation remains gated on unaffiliated review.
