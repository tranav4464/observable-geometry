# B2 orientation provenance audit

## Decision

Does the B2 source-family description match the participant-specific forward model that Track A actually used?

## Scope and evidence

Read the pinned real forward FIF metadata and ran the exact MNE orientation conversion on a copy after selecting the 236 good EEG channels in the sealed channel order. No EEG/iEEG signal arrays, new outcomes, or model-fitting routines were accessed. The conversion used MNE 1.13.2 and `convert_forward_solution(surf_ori=True, force_fixed=True, use_cps=True)`.

The raw forward is free-orientation, shape 256 × 24,588 (three components at each of 8,196 vertices), in head coordinates. After channel selection it is 236 × 24,588. The converted result is fixed-orientation/surface-based with cortical patch statistics, shape 236 × 8,196, and its row names match the sealed sensor contract. Raw forward SHA-256 matches the B1 and Track A provenance: `6f7217f35ee7a37c351cf839c79c16e1ebeb1fa858d93b8c5ec3f3d06fc4bce5`.

## Finding and decision

The previous B2 wording incorrectly implied the raw supplied forward was already fixed-orientation. Track A derives its analysis leadfield by converting the free-orientation FIF to a fixed cortical surface-normal orientation. The active specification and reviewer packet were corrected, and a new immutable review copy `B2-GBF-2026-10-23-v3` was frozen. Its exact checksum is in `review_spec_manifest.json`. Versions v1 and v2 are preserved.

The official MNE API documents `force_fixed=True` and `use_cps`; see https://mne.tools/stable/generated/mne.convert_forward_solution.html. This metadata verification is not a new source-score calculation or scientific validation. B2 remains IN_PROGRESS pending unaffiliated review and the subsequent independent CPU calculation.
