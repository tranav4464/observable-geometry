# B2 split-alternative feasibility audit

## Decision this work can change

Should the primary real-data challenge test a held-out working-memory load, a held-out session, or both jointly? Compare counts using only metadata from the designated development participants.

## Smallest useful check and expected artifact

Count artifact-unflagged trials for (a) within-participant held-load folds using all sessions, and (b) within-participant held-session folds using all loads. Compare to the preceding joint held-load/held-session audit. Save fold-level counts and exact estimand meanings. This can reject a split with empty folds or expose a severe sample-size bottleneck; it cannot establish statistical power.

## Inputs and access boundary

- Pinned dataset: NEMAR on004752 v1.0.0.
- Only `events.tsv` for sub-01 through sub-03.
- `Artifact==1` excluded only for descriptive count; not yet a protocol decision.
- No signals, confirmation participants, or synthetic data.

## Execution

- Run ID: `20261022T202200Z_b2_split_alternatives`
- Command: `python scripts/research/audit_dev_split_alternatives.py --dataset-root data/track_b/on004752_v1.0.0 --output outputs/track_b/20261022T202200Z_b2_split_alternatives/split_counts.json`

## Interpretation

The primary candidate should test a single axis of generalization. A joint load-and-session holdout mixes two sources of shift and gives sparse per-fold tests; it can remain a stress test, not the primary estimand. A held-load primary must explicitly limit its claim to new set size within sessions represented in training. A held-session secondary must not be described as held-load transfer.
