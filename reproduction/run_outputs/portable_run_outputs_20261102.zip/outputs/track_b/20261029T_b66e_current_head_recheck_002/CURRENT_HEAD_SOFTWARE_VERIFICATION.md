# Current HEAD software verification

**Date:** 29 October 2026  
**Software source commit:** `b66e595f9d1ae061f341b524d8a364cea3c4727a`  
**Git tree:** `38a951733d447efc4b43548064b545ad9bb8a436`  
**Scope:** packaging, tests, source provenance, and one sealed model-only CLI parity replay. Not physiological validation or method novelty.

## Results

- Tracked source snapshot: **PASS**; 323 files; clean worktree at verification.
- Workspace suite: **211 passed**, no failures or skips.
- Extracted Git source archive suite: **209 passed, 2 documented skips**, no failures. Imports were confirmed to come from the extracted archive.
- Wheel built from the extracted Git archive: **PASS**, all 7 source/version/license provenance checks. Wheel SHA-256: `c062bc410123bf38e4f7f2593a5b7b2134f061f20817f71325f0566a3ffb2e89`.
- Fresh Python 3.12 environment with NumPy 2.5.4 and SciPy 1.18.1: install and package provenance **PASS**, all 10 checks.
- Sealed sub-01 model-only CLI replay: **PASS**; all 40,980 ranked pairs, score arrays and summary metrics exactly match the established reference. Only `leadfield`, `noise_covariance`, `coordinates_m`, and `source_ids` were accessed. No EEG/iEEG sample arrays were accessed.

## Reproduction records

This folder contains workspace and source-archive JUnit/logs, source archive and SHA-256, source snapshot record, wheel and source-provenance record, fresh environment, model-only parity record, and installation verification record.

## Limits

These results establish reproducible software behavior for one participant-specific forward model. They do **not** establish endogenous neural-source recovery, valid WSGZP registration, calibrated localization uncertainty, researcher decision benefit, population generalization, or a novel-method advantage. B8 still awaits unaffiliated external review and a release-version decision.
