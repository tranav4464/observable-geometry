# B2 task-window semantics: primary-source audit

Run ID: `20261023T_b2_task_window_source_audit`  
Decision: Does the candidate event-relative interval `[4.0, 6.0)` seconds correspond to a scientifically defined task period?  
Scope: Published task methods and dataset event documentation only. No local participant event rows, signal samples, confirmation outcomes, model fits, or synthetic data were accessed.

## Source findings

Dimakopoulos et al. describe the modified Sternberg task as fixation from 6 to 5 seconds before the probe, encoding from 5 to 3 seconds before the probe, a maintenance interval from 3 seconds before the probe to the probe, then probe and response. They explicitly focus physiological analysis on the **last two seconds of maintenance**, `[−2, 0)` relative to probe onset. Set sizes are 4, 6, or 8 memory letters.

The NEMAR nm000363 dataset documentation crosswalks its trial/spike timing to ds004752 and states that a probe-relative spike time maps to ds004752 trial onset plus 6 seconds. The ds004752 event sidecar describes event onset as trial onset. Therefore the candidate trial-relative interval `[4, 6)` maps to probe-relative `[−2, 0)`, the task's final two seconds of maintenance. The NEMAR dataset sidecar defines `SetSize` as the number of letters shown during encoding.

## Decision effect

The candidate `[4.0, 6.0)` interval has a defensible task interpretation as late maintenance. A pinned event-index audit then checked every paired event row for sub-01 through sub-03: 686 trials across 14 sessions. The 200 Hz EEG crop is `[800, 1200)` samples from each 8-second epoch and the native 2,000 Hz iEEG crop is `[8000, 12000)`. All rows passed, and modality trial/load fields matched. No signal samples or reserved-participant events were read. The executable audit and machine-readable result are `scripts/research/audit_late_maintenance_window.py` and `pinned_event_index_audit.json`. This does not establish iEEG predictability, signal quality, model performance, causal interpretation, or novelty.

## Primary sources

- Dimakopoulos et al. 2022, [eLife paper and task methods](https://elifesciences.org/articles/78677); [PDF](https://elifesciences.org/articles/78677.pdf).
- NEMAR, [Boran et al. dataset crosswalk and task description](https://nemar.org/dataset/nm000363).
- OpenNeuroDatasets, [ds004752 event sidecar](https://github.com/OpenNeuroDatasets/ds004752/blob/main/sub-06/ses-06/eeg/sub-06_ses-06_task-verbalWM_run-01_events.json).
- Local pinned data and prior alignment evidence: `outputs/track_b/20261022T174414Z_b1_on004752_real_data/development_metadata_audit_sub01_03.json` and `outputs/track_b/20261022T182700Z_b1_alignment_verification/alignment_feasibility.json`.
