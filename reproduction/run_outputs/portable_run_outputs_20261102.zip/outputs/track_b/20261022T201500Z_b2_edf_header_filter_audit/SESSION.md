# B2 source check: EDF acquisition header metadata

## Session identity

- Run ID (UTC): `20261022T201500Z_b2_edf_header_filter_audit`
- Date/operator: 2026-10-22 UTC / Codex
- Gate: B2 IN_PROGRESS; B-1, B0, B1 PASS; B3-B8 NOT_STARTED.
- Data: NEMAR `on004752` v1.0.0, development participants sub-01 through sub-03.
- Environment: Python standard library; no GPU.

## Decision this work can change

- Question: Do the EDF per-channel acquisition header fields resolve the apparent conflict between `channels.tsv` cutoff columns and EEG sidecar hardware-filter descriptions?
- Smallest check: Parse only each development EEG/iEEG EDF's fixed header, verify header byte count, and collect channel labels plus original `prefiltering` strings.
- Expected artifact: Reproducible inventory of EDF-header bytes and parsed metadata; do not read samples.
- Stop condition: If header text is empty or ambiguous, preserve the conflict and do not infer actual cutoffs from it.

## Inputs and access boundary

- Input files: EEG and iEEG `.edf` for sub-01 through sub-03, sessions already included in the B1/B2 development inventory.
- Only the fixed EDF header is read; no data-record bytes, events, or confirmation participant files are read.
- No synthetic signal or dataset is created.

## Prespecified interpretation

- Pass: EDF prefilter strings agree with one of the metadata sources and are interpretable by modality/channel.
- Inconclusive: Header strings are blank, generic, or conflict across modalities/sessions.
- Limitation: EDF prefilter text is acquisition metadata, not an independent measurement that a particular digital filter was applied correctly.

## Execution

- Command: `python scripts/research/audit_dev_edf_headers.py --dataset-root data/track_b/on004752_v1.0.0 --output outputs/track_b/20261022T201500Z_b2_edf_header_filter_audit/header_audit.json`
- Output paths: `header_audit.json` and `SUMMARY.md`.

## Decision

- Outcome: Failed parser attempt before artifact creation. The per-signal offset was incorrectly indexed from 256 within the post-fixed-header byte buffer. No sample payload was read.
- Next step: Preserve the failure; use the corrected parser under a new run ID and inspect the corrected header only.
