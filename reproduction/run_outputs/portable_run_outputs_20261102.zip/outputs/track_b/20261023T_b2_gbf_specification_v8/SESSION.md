# B2 specification review freeze v7

- Active route: GBFs reproduction/reverse-engineering and nominal source distinguishability under one verified participant-specific forward model.
- Frozen specification: `B2_GBF_SPEC_review_v7.md`.
- SHA-256: `3b13c41c59d332c70a81d8903661329e55abe5bc43aefc3116ee8f6698e14908`.
- Change from v6: added Scherg et al. 2022 Relative Source Power as direct normalized leadfield cross-correlation prior art and sharpened the distinction between its inverse localization output and the project pairwise forward diagnostic.
- Review status: awaiting unaffiliated technical review; no approval implied.
- No signal samples, new outcomes, model fitting, or synthetic neural data were accessed or generated.
