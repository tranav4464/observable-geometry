# Does Track A already satisfy the clarified GBFs build goal?

## Verdict

The clarified goal—reproduce and reverse-engineer GBFs, then build a tool for nominal source distinguishability under one verified head model—is **substantially implemented in Track A already**. Track B should not recreate it or claim it as a new method. The remaining question is whether a useful, defensible software extension exists beyond the sealed foundation.

| Requirement | Current evidence | Finding and limit |
|---|---|---|
| Reproduce GBFs behavior | `outputs/tracka_release_20261022_v2/gbfs_parity.json`; `docs/FOUNDATION_PROTOCOL.md` | Independent implementation matches the pinned upstream recorded-data path on the same saved real inputs (relative Frobenius difference `2.23e-13`). This is numerical parity for the selected case, not a full reproduction of every paper benchmark. |
| Reverse-engineer GBFs | `docs/REVERSE_ENGINEERING.md`; pinned source snapshot in the run manifest | The code path, normalization differences, penalty behavior, matrix inverse, basis restrictions, and epoch scaling are traced. This requirement is met at the source-audit level. |
| Build nominal source-distinguishability tool | `nominal_signature_library.npz`, `nominal_ambiguity_pairs.csv`, `sensitivity_report.json`, offline foundation report, and Track A scripts | The tool computes whitened amplitude/polarity-invariant leadfield similarities, ranks distant pairs, and reports sensitivity to reference/covariance choices. It is a nominal diagnostic, not calibrated uncertainty. |
| Use one verified participant head model | `case_validation.json`, `prepared_bundle.json`, `run_manifest.json`, and `docs/FOUNDATION_PROTOCOL.md` | Track A uses the sub-01 participant-specific forward solution and documented channel/reference/coordinate pipeline. The result is one-participant development evidence only. |
| Bound empirical interpretation | `docs/FOUNDATION_DECISIONS.md` and `docs/FOUNDATION_PROTOCOL.md` | Known stimulation sites validate pulse-artifact localization only; they do not validate distributed physiological source recovery or population generalization. |

## Consequence for the next build step

The exact stated GBFs goal is not a greenfield Track B project. Track B must either (a) package and extend the existing tool in a way that changes a prespecified researcher decision, after prior-art review, or (b) stop at the already completed bounded GBFs build and not claim a new discovery. The broad novelty of nominal ambiguity/source separability is contradicted by the prior-art audit in `docs/track_b/B0_EQUATION_AUDIT.md`.

No new signal analysis, model fit, synthetic data, or confirmation outcome access was used for this scope check. The 23 sealed Track A output-artifact hashes were recomputed and matched the run manifest; all 34 local links in the updated `REVIEW.html` resolve.
