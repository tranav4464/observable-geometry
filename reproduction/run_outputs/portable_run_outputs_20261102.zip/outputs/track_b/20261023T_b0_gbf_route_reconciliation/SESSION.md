# B0 route reconciliation: GBFs and nominal source distinguishability

## Decision being made

Reconcile the current NeuroFlowNet route with the user's clarified build target: reproduce and reverse-engineer GBFs, then deliver a tool that measures nominal source distinguishability under one verified participant-specific head model.

## Current-state evidence

- `docs/FOUNDATION_DECISIONS.md` records the sealed Track A GBFs foundation and its bounded Localize-MI pulse-artifact task.
- `docs/FOUNDATION_PROTOCOL.md` specifies the nominal source-signature comparison: whitened, amplitude- and polarity-invariant leadfield similarity over 8,196 cortical vertices under one participant-specific model.
- `outputs/tracka_release_20261022_v2/run_manifest.json` seals the release inputs, code snapshot, and outputs. It includes GBFs parity, nominal signature library, nominal ambiguity pairs, and the MNE resolution comparison.
- The same release records upstream parity at relative Frobenius difference `2.23e-13`; this verifies implementation parity on the selected Localize-MI inputs, not reproduction of every result in the GBFs paper.
- `docs/track_b/BUILD_BASE_DECISION.md`, `PROJECT_DEFINITION.md`, `MASTER_RESEARCH_PLAN.md`, and the gate register currently make NeuroFlowNet/on004752 the active route. Those records conflict with the clarified target and must be treated as superseded for route selection, not silently merged.
- `docs/track_b/B0_EQUATION_AUDIT.md` records substantial prior art for source resolution, ambiguity, robust testing, and leadfield uncertainty. A nominal pairwise distinguishability tool is a bounded software deliverable; it is not a novel mathematical method by default.

## Data and claim boundary

The active route is being realigned to the already acquired real Localize-MI data and the verified sub-01 forward model. This session did not inspect new signal samples, run a new analysis, fit a model, or use synthetic data. The existing Track A sub-01 results remain development evidence. The proposed tool reports nominal model-based sensor-pattern distinguishability under the selected forward model and declared covariance/reference assumptions; it cannot report a calibrated probability of source recovery, unique anatomy, or performance on unmeasured tissue.

## Gate action

Reopen B0 because its selected base and target changed. Reset downstream B1 and B2 to `NOT_STARTED` until their dataset-specific criteria are rewritten for GBFs/Localize-MI. Preserve the previous NeuroFlowNet decision, audits, and B2 specification as historical artifacts. Do not begin any new model fitting or access new outcome data during this route reconciliation.

## Next required evidence

1. Reconfirm the GBFs source version, license, code path, equations, and exact parity scope.
2. Review whether the existing nominal-signature tool already satisfies the requested output or whether a distinct, useful extension remains.
3. Compare the exact tool output and decision with spatial-resolution, leadfield-similarity, ambiguity, and robust-uncertainty methods in primary literature.
4. Rewrite the real-data protocol around the single verified head model and Localize-MI, retaining the pulse-artifact versus physiological-response distinction.
5. Obtain an independent technical challenge before marking the reopened B0/B2 gates passed.

## Outcome

Route reconciliation recorded. B0 is reopened; B1 and B2 are reset pending route-specific specifications. The GBFs base is selected as the user's intended target, while scientific novelty of the distinguishability tool remains unestablished. A scope check found that Track A already substantially implements the three stated requirements: GBFs parity on the selected case, source-code reverse engineering, and a nominal source-distinguishability tool under one participant-specific model. See `FOUNDATION_SCOPE_CHECK.md`.

The project definition, base decision, master plan, README, and live review page now use the GBFs route. NeuroFlowNet materials are preserved as historical records. The gate register validator passes with B0 `IN_PROGRESS`, B1/B2 `NOT_STARTED`, and B3–B8 `NOT_STARTED`. The review-page updater and Python syntax check pass; all 34 local review links resolve; all 23 sealed Track A output-artifact hashes still match the manifest. No new data analysis, fitting, or synthetic data were used.


## Correction: active-record consistency audit (23 October 2026)

A follow-up inspection found that the prior outcome paragraph overstated synchronization: several active `GATE_REGISTER.json` known-issue fields still described NeuroFlowNet/WBEN. The project definition, README, live review page, and GBF build plan correctly identify GBFs, but those stale gate fields made the status record unreliable. They have now been rewritten to reflect the GBFs route and the actual NOT_STARTED states for B1-B3. The old route remains in explicitly historical files. The active B0 stays IN_PROGRESS because its independent technical challenge and distinct decision-value assessment are not complete; B1-B3 remain NOT_STARTED. No data or model outcomes were opened in this correction.


## B0 closeout decision (23 October 2026)

The base comparison and equation-level prior-art screen support closing B0 as a bounded route decision: GBFs is selected for a reproduction plus inspectable nominal source-distinguishability software build. The candidate score and general separability question overlap established methods, so no new-method claim is retained. Independent review remains required before any future novelty claim and as the final B8 outside check; it does not block this no-novelty route choice. The B0 gate is PASS. B1/B2 remain NOT_STARTED pending route-specific feasibility verification and formal specification. The build objective itself remains active.
