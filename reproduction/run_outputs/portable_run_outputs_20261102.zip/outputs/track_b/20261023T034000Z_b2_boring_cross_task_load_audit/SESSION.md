# Boring et al. cross-task cognitive-load audit

Date: 2026-10-23

## Source and method

The publisher and PubMed records identify Boring et al. (2020), *Journal of Neural Engineering* 17(5), 056016, DOI 10.1088/1741-2552/abb9bc. The paper analyzes 33 participants with 64-channel scalp EEG across n-back, mental arithmetic, and multi-object tracking. It uses per-participant sliding-window RBF SVMs to classify high versus low load from spectral EEG features. Its cross-task validation trains on two tasks and tests on the third, with that design rotated across the three tasks. Within-task validation groups full high/low blocks across folds to avoid placing overlapping windows from one block in both train and test. The paper reports ROC AUC and describes both task-general and task-specific patterns.

## Relevance

This is direct prior art for cross-task generalization of scalp-EEG load decoding. It preempts a generic novelty claim for transfer of EEG load signatures across conditions. It is not the same target as the candidate Track B question: it predicts binary cognitive-load labels from scalp EEG within each participant, not paired intracranial recordings or iEEG-contact waveforms for a held-out working-memory set size. Thus the held-load iEEG evaluation remains a distinct candidate estimand, but neither that estimand nor a load-conditioned model is a novel contribution by itself.

## Gate consequence and handling

Keep B2 in progress. In any final framing, state the target difference precisely and do not call generic task/load transfer novel. No project signals, confirmation participants or model outcomes were accessed.

## Sources

- Publisher full article: https://doi.org/10.1088/1741-2552/abb9bc
- PubMed record: https://pubmed.ncbi.nlm.nih.gov/32947265/
