# B0 single-route reassessment

Run ID: `20261023T_b0_single_route_reassessment`  
Decision: Which one existing scientific model and measurable output should anchor Track B?  
Data boundary: literature, existing audit records, and the already completed development-only B1 audit. No new participant event rows, signal samples, model fits, or synthetic data were accessed in this session.

## Decision

Select a **clean-room implementation of NeuroFlowNet's conditional normalizing-flow method** as the single candidate baseline for a scalp-EEG-to-recorded-iEEG waveform build. Define its output as a predictive distribution for the measured iEEG contacts, not a brain map, source estimate, or recovered thought. The model selection is a B0 route decision, not an accepted novelty claim or permission to fit data.

The research question to formalize in B2 is whether the predictive distribution remains useful and appropriately calibrated when one verbal-working-memory set size is absent from that participant's training data. Any proposed contribution should make test-time information available to the model explicit, distinguish waveform shape from absolute-amplitude prediction, and compare uncertainty reliability under this load shift. Conformal calibration and uncertainty estimation are established method families; do not claim either as new. The exact held-load task overlap remains unverified, so this is a candidate empirical challenge, not a priority claim.

## Why this is the single coherent route

| Candidate | Native output and real-data evidence | Main limitation for this build | Decision |
|---|---|---|---|
| NeuroFlowNet | Conditional distribution of depth-iEEG waveforms from simultaneous scalp EEG; the 2026 paper reports within-person held-trial and held-session tests on a source cohort overlapping on004752. The development-only 200 Hz audit confirms paired event-grid compatibility for 14 sub-01–03 sessions. | It does not test an unseen working-memory set size. The inspected repository has no declared license and code-level test-time target normalization/filtering concerns; do not copy its code or treat the repository snapshot as proof that the paper results were generated correctly. Paper-level reproduction details and signal scaling require careful reconstruction. | **Selected clean-room baseline candidate.** |
| WBEN | Joint scalp EEG/iEEG state-space model whose main real-data output is regional network state/connectivity. | The project dataset has no ground truth for unobserved network edges. The previous plan paired its network reproduction with an unrelated contact-waveform predictor, combining different estimands. | Keep as prior art; not the primary build. |
| GBFs / Track A | Licensed source-imaging implementation and sealed engineering foundation. | The current real dataset/task is not a matched source-localization ground-truth experiment; the existing Localize-MI result is stimulation-artifact specific. | Preserve as infrastructure/comparator; not the primary build. |
| REA | General software reverse-engineering toolkit. | It is not an EEG model, dataset, or neural inference method. Its code does not supply the scientific baseline. | Exclude as the scientific build base. |

The B0 choice follows endpoint alignment: recorded iEEG provides a measurable target for waveform prediction. It avoids presenting regional network estimates as if they could be verified against complete anatomical truth in this dataset. NeuroFlowNet's author code is inspected only as research evidence; because the repository lacks a declared license, the implementation must be independently written from the paper and must not copy or adapt source code.

## Boundaries and unresolved questions

- The source paper reports 90% prediction intervals with empirical coverage of 0.381–0.432 for its selected subjects. This is a concrete uncertainty-reliability weakness to examine, not proof that a calibration method is novel or that the paper is invalid.
- The author paper reports per-segment z-scoring and scores native-unit MAE; the inspected public code path uses each held-out target segment's own mean and standard deviation when unnormalizing predictions. The project must not use those target statistics at test time. B2 must distinguish scale-invariant shape scores from any real-unit amplitude score and specify how test-time normalization is obtained from allowed information.
- The 200 Hz audit verifies event alignment and tensor shapes only. It does not establish artifact-free data, final filters, reproduction fidelity, or model performance.
- The exact overlap of Phillips et al.'s inaccessible full methods with the held-load waveform task remains unknown. Treat unknown overlap as unknown; retain no algorithmic novelty claim.
- It remains to determine whether enough eligible trials per set size exist for the prespecified participant-level development and confirmation design. Confirmation participants must stay sealed until the B5 protocol lock.

## Falsifiers and stop conditions

Reopen B0 if the paper does not specify enough to implement a defensible clean-room comparator, if the available recordings cannot support the exact target/load split, or if target-side statistics are necessary for the claimed output. If the conditional flow cannot be fairly reproduced, retain a transparent real-data benchmark only if it answers a defined question and report the reproduction failure. Do not substitute a different endpoint while keeping the old claim.

## Primary sources and local evidence

- He et al., [NeuroFlowNet arXiv v3 full text](https://arxiv.org/html/2603.03354v3) and [version record](https://arxiv.org/abs/2603.03354).
- Author repository snapshot audited at [commit `ce1b5120b7a93127e20a83c006190802e72a2b4e`](https://github.com/hdy6438/NeuroFlowNet/tree/ce1b5120b7a93127e20a83c006190802e72a2b4e); no code reuse.
- Yang and Liu, [official WBEN NeurIPS paper](https://papers.nips.cc/paper_files/paper/2025/hash/82a6afb1f666daaeec8da4d775452bc7-Abstract-Conference.html).
- Local NeuroFlowNet audit: `outputs/track_b/20261023T023300Z_b2_neuroflownet_audit/SESSION.md` and `audit.json`.
- Real-data compatibility audit: `outputs/track_b/20261023T_b1_200hz_candidate_task_audit/SESSION.md`, `audit.json`, and `independent_report_check.txt`.
- Closest-prior-art summary: `docs/track_b/METHOD_MATRIX.md`, `docs/track_b/B2_FORMAL_SPEC.md`, and `outputs/track_b/20261023T_b2_new_prior_art_recheck/SESSION.md`.

## Gate effect

B0 can close as a reproduction/challenge route with no algorithm-novelty claim. B2 remains `IN_PROGRESS`: the exact estimand, target scaling, held-load split, matched alternatives, prior-art boundary, and independent protocol challenge still need to be fixed before any model fitting. No confirmation outcomes are authorized or accessed.
