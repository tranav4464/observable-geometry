# B2 peer review: held-load scalp-to-iEEG prediction

**Recommendation: HOLD FOR CHANGES.**

Reviewed 23 October 2026. The task is feasible enough to retain, and several important safeguards are well designed. It is not yet ready for model fitting: the controls do not establish the incremental value of the scalp input, preprocessing crosses the stated task-phase boundary, and some comparison and execution rules remain ambiguous. These are repairable protocol issues, not evidence that the project must be abandoned.

**Reviewer disclosure:** this is an AI peer-review-style assessment in the same chat that helped prepare the packet. It includes fresh primary-source checks and independent analytical checks, but is not an unaffiliated external review. No model performance has been reviewed because no fitted results are presented. No raw recordings or confirmation event rows were opened for this review.

## Judgment against the requested criteria

| Criterion | Judgment | Reason |
|---|---|---|
| Useful, clearly defined task | Useful, with a narrower practical interpretation | It tests prediction of measured contacts at an unseen set size after paired training in the same person. It can challenge deployment to an unrepresented condition, but cannot demonstrate use in a person who never had iEEG. |
| Close prior art and Phillips overlap | Broadly adequate for a non-novel benchmark; amendments needed | The key waveform, feature, calibrated-transfer, and dependence studies are covered. Phillips is honestly marked unknown. Another direct diffusion study needs a screening entry, and contradictory instructions about whether Phillips blocks all work should be reconciled. |
| Splits and leakage controls | Sound design in principle; implementation unverified | Whole-load/trial grouping and fold-local target statistics are appropriate. Same sessions appear on both sides intentionally. Documentary access logs support a boundary but cannot prove absence of unlogged access. |
| Preprocessing and metrics | Partially satisfactory | Explicit resampling and participant-level scoring are strengths. Filter support crosses probe onset. Marginal distribution scores need a no-input distribution comparator. Several numerical conventions and failure paths remain open. |
| Conclusions within the measurements | Mostly well bounded | The packet rejects whole-brain/source/causal claims. It must also separate input-dependent prediction from learned signal priors and separate held-load performance from degradation caused by load shift. |
| Ready to fit | No | Resolve R1-R6 below, with numerical implementation verification in B3 before its first training run. Keep confirmation outcomes closed until B5. |

## What is already strong

The question specifies the target, participant, task loads, time grid, and inference inputs. It uses recorded, reference-dependent iEEG rather than labeling those measurements as latent neural truth. The outer split withholds an entire set size, and inner validation stays inside the other two loads. Keeping both windows of a trial together avoids a common segment-leakage failure. Restoring units from training-only target statistics is a particularly important correction.

The participant is the uncertainty unit. Contact count and overlapping biological observations are not inflated into a sample size. Per-load/contact reporting, three separately scored training seeds, and explicit disclosure of small-sample uncertainty are appropriate. The affine inverse correction is mathematically right: if `z_b=(x_b+tau)exp(sigma)`, then `x_b=z_b exp(-sigma)-tau`. A discrepancy in printed equations does not establish that the published experiments used the wrong implementation.

I found no basis in the inspected records to allege confirmation leakage. That is a documentary judgment, not a machine-level access certification. The project correctly labels preprocessing and implementation departures instead of promising an exact replication.

## Required revisions before fitting

### R1. Demonstrate the contribution of the actual scalp input

**Priority: high.** Evidence: B2 specification lines 76-79 and 89-93; falsification rules at 119-122.

The mean baseline checks point prediction against a constant/template-like predictor. It does not provide a no-input probabilistic comparator. A model that ignores scalp EEG can learn a plausible marginal iEEG distribution and outperform point predictions on CRPS or obtain reasonable interval coverage. Those results would not establish useful scalp conditioning. No input-pairing control is specified in the active protocol.

**Minimum remedy:** add a training-only empirical marginal distribution baseline, scored at the same coordinates, with the same normalization and aggregation. Define whether it conditions on window position; it must never use the held load's iEEG. Separately prespecify a wrong-trial scalp-input control: exchange intact real scalp windows between different trials within participant, session, held load, and window position, using fixed derangements and unchanged targets. Record strata that cannot be deranged and keep them out of that diagnostic only. Never shuffle individual samples or search for a favorable permutation.

These controls reuse real recordings; they require no generated neural dataset. Their exact permutation count, seeds, aggregation, and exclusion rule must be frozen. A fixed-model input permutation is a diagnostic of dependence, not a causal intervention and not a definitive estimate of neural information. Shared reference signals, artifacts, or other nuisance structure can also produce input dependence.

**Acceptance condition:** the protocol distinguishes three outcomes: useful point prediction, useful marginal distribution prediction relative to a no-input distribution, and evidence that correctly paired scalp input matters. It permits these outcomes to disagree. The implementation must preserve real trial blocks and the outer information boundary.

This is not a hypothetical concern invented for this review. Matsubara et al.'s preprint, already listed in the project's method matrix, explicitly compares waveform prediction with a patient template and scalp-input controls. Its IED task differs from this maintenance task; it nevertheless makes the control design directly relevant. [Primary preprint](https://www.medrxiv.org/content/10.64898/2026.09.25.26364055v1.full).

### R2. Resolve the filter's crossing of probe onset

**Priority: high for the maintenance-phase interpretation.** Evidence: specification lines 53 and 63; corrected resampling audit; `audit_b2_resampling_preprocessing.py`.

The stated maintenance crop is `[4,6)` seconds, with the probe at 6 seconds. The specified 201-tap zero-phase FIR at 2,000 Hz has a 100-sample, 50 ms half support. The final output sample is at `1199/200 = 5.995 s`; its support envelope extends to `6.045 s`. Nonzero taps therefore allow post-probe recording content into the end of the target window. I independently checked the installed SciPy source and coefficients without opening recordings. SciPy documents the zero-phase behavior. [Official documentation](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.resample_poly.html).

This is **task-phase mixing, not demonstrated training/test leakage**. The filter remains within the same trial and load. Nor have I measured how much post-probe content changes the scored waveform. Nevertheless, the current target cannot be described as strictly pre-probe on the strength of its output timestamps alone.

**Minimum remedy:** either select a common scalp/iEEG crop whose known digital filter support stays before probe onset, or explicitly redefine the endpoint as a zero-phase-filtered interval that can include post-probe contributions. A two-second interval such as `[3.95,5.95)` illustrates a possible guarded alternative, but the final boundaries must be checked against the event grid and filter coefficients. Do not switch to crop-first zero padding; that creates a different boundary distortion. Preserve full-trial filtering and audit the chosen guard on development data only.

Also report the effective bandwidth precisely. The existing audit gives approximately -22.6 dB worst-case attenuation within 110-200 Hz despite a -68.2 dB mean. Mean stopband attenuation alone cannot certify negligible aliasing. A stricter transition-band target or a bounded development-data spectral check is needed if strong high-frequency fidelity claims are intended. Unknown acquisition filtering remains a stated limitation even after the digital guard is fixed.

**Acceptance condition:** target timestamps, raw-sample dependency boundaries, effective bandwidth, and phase wording agree. B3 verifies those index/support invariants before any fit. No claim that all acquisition-related temporal spread is eliminated is justified.

### R3. Make the comparator challenge credible and reproducible

**Priority: medium, blocking a claim of advantage over fair alternatives.** Evidence: specification lines 77-83.

The ridge comparator only sees simultaneous samples and has a fixed `alpha=1`. The shallow CNN sees 13 input samples per output coordinate, about 65 ms at 200 Hz, while the flow's attention can use the full 200-sample window. Beating those fixed alternatives would not identify a benefit specific to a conditional flow. The term “strongest non-flow comparator” is accurate only as “best of this restricted candidate set.”

The ridge objective is also incomplete: `sum(error^2)+alpha||W||^2` and `mean(error^2)+alpha||W||^2` differ by sample-count scaling. With inner and outer folds of different sizes, `alpha=1` does not mean the same effective regularization under both conventions.

**Minimum remedy:** state the exact ridge objective and add one transparent temporal alternative with access to the same one-second input, such as a regularized lagged linear predictor. Fix its boundary handling and select its small regularization grid using only the two inner load folds. Alternatively, retain the existing comparators but explicitly limit all conclusions to them and drop language implying a strong architecture-level comparison. No large baseline zoo or reproduction of every recent paper is necessary.

**Acceptance condition:** either a credible temporal alternative is included and validated, or the restricted comparison claim is adopted consistently. Do not silently omit a required comparator after an implementation problem; reopen that comparison decision, retain the failure, and state the reduced claim before confirmation.

### R4. Close execution, missingness, and numerical ambiguities

**Priority: medium.** Evidence: specification lines 67, 83, 89-105 and the fidelity matrix's conditional-network row.

The protocol has many useful details, but two implementations could still produce different datasets and results. Resolve the following in one executable configuration/contract before fitting:

- Specify the sample axis and `ddof` for training means/scales and the voltage-to-microvolt conversion. The current data audit uses MNE's unit override; that is not itself a definition of model-output units.
- State whether nonfinite windows are removed before or after training-channel screening. One bad window can otherwise remove many contacts, whereas reversing that order retains them. Freeze one rule inside each fold.
- Define integer rounding for the median of six best epochs, best-epoch ties, and the result of an inner fit with no finite validation score. A six-value median can be half-integer.
- Define whether one failed seed fails the model-fold, rather than implicitly averaging only successful seeds; bound any technical retries and retain them. Never drop a failed run because its result is inconvenient.
- Fix the empirical quantile convention, units for interval width, and weighting of inner-fold validation scores. Keep participant/load/contact/seed identity in stored predictions and metrics.
- Resolve the conditional-network choices left open in the fidelity matrix: tensor dimensions, padding, bias, initialization, attention dropout/masking, normalization, and any residual connection. Treat these as explicit adaptations. Stochastic coupling behavior must not make evaluation of the inverse or density inconsistent.
- State the actual model-training precision and prohibit silent numerical fallbacks. Verify forward/inverse consistency, density Jacobians, unit restoration, and CPU/GPU parity before training.

The complete-case paired contrast also needs an explicit limitation. If a difficult participant causes a flow failure, that participant has no paired contrast. Displaying the failure count is necessary, but a bootstrap over the remaining participants still estimates performance conditional on successful fits. Report both the completion denominator and the paired-score denominator. With fewer than two complete participants, suppress a group bootstrap interval; do not display a degenerate interval as certainty.

**Acceptance condition:** a reviewer can determine every fold's eligible data, fit budget, output units, score, and failure state from the contract. B3 performs numerical/interface checks; B2 need not pretend those future checks have already passed.

### R5. Match the research decision to what this comparison can establish

**Priority: medium; primarily a scope correction.** Evidence: specification lines 11, 41 and 115-123.

Held-load prediction is a legitimate endpoint by itself. However, without a matched represented-load evaluation, poor held-load scores cannot tell us whether changing load broke an otherwise useful model or the model could not predict these signals under either condition. Likewise, this test cannot support the alternative conclusion that use should be restricted to represented conditions unless usefulness there has been demonstrated.

**Minimum remedy:** choose one of two defensible scopes before fitting. Either add a development-only, training-size-aware represented-load reference with trial grouping and inner-only selection, or keep the lean held-load project and state that it estimates absolute performance on an unrepresented condition, without attributing failure specifically to load shift. A causal effect of changing load is not established by either predictive comparison.

Separate model failure from project failure. A fair baseline matching the flow, or poor calibration, can be a successful benchmark result. The term “severely undercovered” and the reference to a “useful calibrated operating point” are not defined, while post-hoc calibration is explicitly excluded. Remove the latter implication. Keep coverage/width as descriptive evidence unless a justified decision threshold and operating context are prespecified before B5. No threshold may be invented after confirmation results.

**Acceptance condition:** every intended output has a corresponding allowed conclusion, including negative results. Marginal CRPS/coverage cannot certify joint waveform dynamics, connectivity, or recovery of a brain state. A negative result cannot establish that scalp-to-iEEG prediction is impossible for other methods or recordings.

### R6. Reconcile the literature and review packet

**Priority: medium for a coherent review record, not a demand for unlimited searching.** Evidence: `METHOD_MATRIX.md` lines 41 and 124; packet primary references; author readiness audit.

Phillips is handled honestly as unresolved in the active specification, but the matrix's final row and access-session note effectively keep B2 blocked until its full text is obtained. That conflicts with the declared non-novel reproduction/challenge scope and with asking the reviewer whether a bounded search is sufficient.

**Minimum remedy:** retain explicit unknowns for Phillips' cohort, task, prediction target, and split. Seek a lawful full text when available. Do not treat inaccessible methods as evidence that this task is new. For this bounded TKS benchmark, I would **not** make access to that paper alone an indefinite blocker. Novelty claims would require further evidence, but are already withdrawn.

Screen the additional directly relevant [TF-DiffEEG conference study](https://doi.org/10.1109/ISPCE-ASIA69076.2025.11312313), referenced by CAST but absent from the active matrix search in this review. The publisher's indexed abstract describes diffusion-based scalp-to-iEEG reconstruction. Detailed held-load overlap is unverified; do not invent a difference from its abstract. Matsubara is already included in the matrix; carry its input/template-control lesson into the active design rather than presenting it as a newly missing citation.

The packet's WBEN OpenReview URL could not be verified and embeds a proceedings hash as a forum ID. Replace it with the working [official NeurIPS entry](https://papers.nips.cc/paper_files/paper/2025/hash/82a6afb1f666daaeec8da4d775452bc7-Abstract-Conference.html). All ten local packet links resolved correctly in this review.

**Acceptance condition:** one active prior-art table distinguishes what is verified, unknown, and irrelevant to this estimand; historical WBEN instructions cannot be mistaken for current requirements. Record this recommendation as an AI review with an authorship conflict, not external sign-off.

## Primary-literature assessment

The inspected NeuroFlowNet text supports the main fidelity concern and the rationale for examining uncertainty: its printed forward/inverse maps disagree, and its reported nominal-90% coverage is far below nominal for selected subjects. That motivates a careful reimplementation and challenge, not a claim that all published results are invalid. [NeuroFlowNet v3](https://arxiv.org/html/2603.03354v3).

Subramanian's author-hosted manuscript predicts intracranial spectral-band power using scalp power and regularized regression; its time-blocked split includes a temporal gap. This is direct prediction precedent, but a different target from one-second contact waveforms. Its design supports taking temporal dependence and simple baselines seriously. [Author manuscript](https://precisionneuro.stanford.edu/s/20250407647612v1full.pdf).

CAST's methods explicitly allocate target-patient data to calibration. It is not evidence of prediction for a new patient with no paired iEEG. Its different split and task-description inconsistencies prevent importing its scores as a matched baseline here. [CAST methods](https://arxiv.org/html/2605.18897v1). Dong's preprint likewise occupies generic scalp-to-iEEG enhancement; its reported 8:2 split does not settle whole-load separation. [Dong et al.](https://arxiv.org/html/2604.14202v1).

Phillips' institutional abstract verifies synchronous scalp/sEEG dependence analyses using correlation and information measures. It does not supply enough methods to decide exact held-load waveform overlap. I could not verify a public full manuscript in this review. [Institutional publication record](https://scholars.houstonmethodist.org/en/publications/characterizing-the-relationship-of-non-invasive-and-invasive-neur/).

The evidence is sufficient to reject broad novelty claims and to justify a limited benchmark. It is not sufficient to call this a new mathematical framework, a recovery certificate, or an indispensable neuroscience method. That mismatch with the earlier invention ambition should stay visible rather than be concealed by a project name.

## Split, claims, and remaining limitations

Holding out load 6 is interpolation in the set-size label; holding out 4 or 8 is extrapolation in that label. Neither guarantees a corresponding ordering in neural distribution shift. Keep all three separate, as the protocol already requires. The same sessions on both sides do not violate this within-session/participant estimand, but session-specific nuisance structure may still help prediction. Do not generalize these results to new sessions or people.

Artifact-flagged-clean and paired-valid trials define a restricted offline evaluation population. Eligibility rules that require target iEEG are permissible for offline scoring, but cannot be presented as an available scalp-only deployment screen. Reference-dependent common signals and clinical contact placement further limit anatomical interpretation. A reference-sensitivity analysis would strengthen a later local-neural-information claim; it is not necessary to begin a measured-contact benchmark with honest limits.

One hundred conditional samples define a finite-sample evaluation. Assess numerical sampling sensitivity on development data before B5 if Monte Carlo variation affects conclusions; do not repeatedly change sample count based on confirmation scores. Coordinatewise CRPS is valid for marginal predictions, but does not test cross-contact or temporal dependence. Those are optional new endpoints only if the project intends claims about them.

The retained access logs justify proceeding with an outcome-unexposed confirmation plan, subject to a frozen manifest and access check. They cannot establish that this public dataset is externally independent or that the original publication never used those participants. Explicitly distinguish a locked internal challenge from a new-cohort validation.

## Re-review checklist and decision

- [ ] R1: no-input probabilistic baseline and real-window pairing control specified.
- [ ] R2: filter support and task-phase wording reconciled; bandwidth limits explicit.
- [ ] R3: exact ridge objective and adequate temporal comparison, or narrower comparison claim.
- [ ] R4: execution, units, quality-mask order, seed failures, and missingness contract complete.
- [ ] R5: bounded decision rules, represented-load claim, and negative-result interpretation consistent.
- [ ] R6: prior-art/access policy, TF-DiffEEG screening, citation correction, and review provenance reconciled.

After these revisions, B3 implementation and its pre-fit numerical checks would be reasonable. Confirmation fitting remains subject to its separate B5 lock. I do not recommend a pivot on the present evidence. The appropriate next step is to strengthen this measured-contact benchmark and test it, while withholding any claim that a novel algorithm or physiological discovery has already been achieved.
