# B2 peer-review session

- Date: 2026-10-23.
- Request: challenge the B2 review packet and recommend PASS, HOLD FOR CHANGES, or FAIL/PIVOT.
- Reviewer: Codex, adopting a critical peer-review role. This chat previously contributed to the packet; this is not an unaffiliated external review or independent human sign-off.
- Gate at entry: B2 IN_PROGRESS; B3-B8 NOT_STARTED.
- Decision: whether the proposed task, evidence, protocol, and claim boundaries justify beginning B3 model fitting.
- Smallest useful checks: read the active specification and supporting audits; check the closest primary publications; derive the filter's temporal support; check comparator/metric logic; resolve local evidence links; preserve a review with actionable acceptance criteria.
- Inputs: the review packet, linked specifications and audit records, relevant source scripts read without executing data-loading paths, installed SciPy filter implementation, and public publications.
- Boundary: no raw EEG/iEEG, participant event tables, confirmation outcomes, fitted predictions, or synthetic neural data opened or generated. No training, source copying, publication, or researcher contact.
- Stop condition: once the substantive issues and bounded remedies are identified, issue the recommendation. Do not turn the review into implementation or alter the submitted scientific specification.

## Checks performed

The review inspected the active specification, fidelity matrix, B1 closeout, author readiness audit, method matrix, gate register, resampling audit and source, inner-load feasibility record, metric/estimand records, and documentary access review. Public-source checks covered NeuroFlowNet, Subramanian, CAST, Dong, Phillips, WBEN, Matsubara, TF-DiffEEG, the acquisition article, and SciPy documentation. Access limitations are reported in REVIEW.md.

An independent document-relative link check found all ten local packet links present. An analytical check of installed SciPy 1.18.1 confirmed the 201-tap filter design and its 50 ms half support. This is coefficient/source analysis, not an experiment on neural signals. The final scored sample at 5.995 s has a filter-support envelope ending at 6.045 s, after the documented 6 s probe onset. The magnitude of any effect on actual results was not measured.

Recommendation: **HOLD FOR CHANGES**. See REVIEW.md for six required revision groups and their acceptance conditions. Keep B2 open. This review does not certify an error-free implementation, pass B3 numerical checks, or satisfy an unaffiliated external-review requirement.

The submitted packet/specification are preserved. The review artifacts and a clearly labeled status record may be added to the project index without treating the findings as fixed.

## Handoff verification

- `check_review_evidence.py`: ten local packet links resolved; fifteen reviewed inputs hashed; SciPy 1.18.1 filter-support calculation confirmed. Outputs: `checks.json` and `reviewed_inputs.json`.
- SHA-256 comparison confirms the active scientific specification, fidelity matrix, method matrix, and B1 closeout were not changed by this review. The packet's status/index line was updated after its reviewed hash was captured.
- Gate register validation passed with 186 evidence paths; B2 remains IN_PROGRESS and B3-B8 remain NOT_STARTED. This is a structural validation, not scientific approval.
- The decision/evidence ledgers and live review page now link the HOLD recommendation. No finding is marked fixed and no model was fitted.
