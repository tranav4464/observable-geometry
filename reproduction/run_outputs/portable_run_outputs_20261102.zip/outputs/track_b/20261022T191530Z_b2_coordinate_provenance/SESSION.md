# B2 electrode-coordinate provenance audit

## Decision this audit informs

Can the released on004752 electrode positions define a reproducible contact-to-Harvard–Oxford mapping for the WBEN iEEG observation matrix?

## Inputs and scope

- Local pinned release: `data/track_b/on004752_v1.0.0`
- Development subjects only: `sub-01`, `sub-02`, `sub-03`
- Inspected only electrode filenames, `*_electrodes.json` column descriptions, and TSV headers.
- No event rows, signal samples, or confirmation-subject files were read.

## Procedure

```powershell
.\.venv_tracka_clean\Scripts\python.exe scripts\track_b\audit_dev_coordinate_provenance.py `
  --dataset-root data\track_b\on004752_v1.0.0 `
  --output outputs\track_b\20261022T191530Z_b2_coordinate_provenance\coordinate_provenance.json
```

The audit checked 14 development-session iEEG `*_electrodes.tsv` files for a `space-<label>` filename entity and for any inherited `*_coordsystem.json` in their BIDS directory hierarchy. It also read the associated `*_electrodes.json` descriptions.

## Metadata-only audit result

- None of the 14 electrode tables used a `space-<label>` entity.
- None had an inherited `*_coordsystem.json` sidecar.
- The electrode JSON describes `x`, `y`, and `z` as MNI coordinates and describes `AnatomicalLocation` as an assignment from MNI coordinates to the Brainnetome atlas.

## Superseding primary-source trace

A follow-up source-code audit located the original dataset authors’ electrode-localization script at pinned revision `395ae136372be9772cdbeb09bccd677fda01b5d6`. It applies FieldTrip `ft_volumenormalise` with nonlinear normalization and SPM12 to an ACPC MRI, warps electrode/channel positions using `individual2sn`, labels the coordinates MNI, and assigns Brainnetome labels using `BNA_MPM_thr25_1.25mm.nii` and the maximum voxel-count label. FieldTrip 20200315 defaults this call to SPM12 old normalization with `toolbox/OldNorm/T1.nii`; SPM documents this template as derived from the linear ICBM152 T1 average, 2 mm, smoothed 8 mm.

This recovers the source method and normalization template used by the original localization script. It does not prove every released BIDS coordinate is a row-for-row export of that script output, and it does not recover WBEN’s exact Harvard–Oxford contact assignment, coordinate conversion, or `C` construction. The later coordinate-space review withdraws the 49.2% point lookup because it applied no transform between MNI152Lin and MNI152NLin6Asym. See `docs/track_b/B2_SOURCE_COORDINATE_PIPELINE.md` for the source trace and limits.

## Source checks

- Boran et al. 2020 describe post-implant CT/T1 localization, normalization to MNI, Brainnetome labeling, and manual anatomical labels for some contacts: [Scientific Data paper](https://pmc.ncbi.nlm.nih.gov/articles/PMC6972902/).
- Current BIDS iEEG documentation requires a `*_coordsystem.json` for each `*_electrodes.tsv` and uses explicit coordinate-system metadata: [BIDS specification](https://bids-specification.readthedocs.io/en/stable/modality-specific-files/intracranial-electroencephalography.html).
- WBEN says electrodes were co-registered to `fsaverage` and describes source aggregation and iEEG contact-to-HO assignment without fully stating how the dataset coordinates are transformed or how boundary cases are handled: [WBEN paper](https://openreview.net/pdf/799e82c424dc3dcfa7cfcf45da2f0882ca3ef973.pdf).

## Interpretation and next step

Keep the Harvard–Oxford contact map provisional. Reproduce the authors' coordinate transformation and contact assignment from primary methods or an official implementation if that information can be found. Otherwise, keep mappings as explicitly named alternatives and do not describe any one as faithful WBEN reproduction. B2 remains open; this audit does not authorize model fitting on reserved data.
