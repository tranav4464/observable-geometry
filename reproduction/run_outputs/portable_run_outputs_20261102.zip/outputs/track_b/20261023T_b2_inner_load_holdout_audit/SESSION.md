# B2 inner held-load validation feasibility

## Decision record before execution

- Run ID: `20261023T_b2_inner_load_holdout_audit`
- Gate: B2, IN_PROGRESS
- Decision: Should inner validation mimic the outer unseen-set-size shift by holding out one of the two outer-training loads, or retain random trial folds that mix both loads into each validation partition?
- Why this is the earliest issue: the current active B2 spec proposes inner load holdout, while an older audit only checked random within-load trial folds; the metric contract repeats the older design. This is a substantive inconsistency in the tuning protocol.
- Smallest decisive check: use only `events.tsv` for sub-01..03 to count Artifact==0 complete trials per session/load; for every outer-held load, hold each remaining load out in turn and verify each inner train/validation set is nonempty.
- Expected artifact: machine-readable fold counts, exact reproducible script, and a decision that preserves the old audit as a rejected candidate if load holdout is feasible.
- Stop condition: if any development participant has an empty inner load-holdout fold, do not assert feasibility; design and audit a fallback on development metadata only.
- Access boundary: no event rows from sub-04..15, no EDF samples, no synthetic data, and no model fitting.

## Execution record

- Exact command: `.venv\Scripts\python.exe scripts/research/audit_inner_load_holdout_feasibility.py`.
- Input: paired scalp EEG event TSVs for development sub-01 through sub-03 only; Artifact==0 trial rows; no event rows from sub-04..15 and no EEG/iEEG sample arrays were read.
- Result: 18 inner folds (3 development participants × 3 outer-held loads × 2 inner-held loads) were nonempty. Each fold trains on one complete set size and validates on the other across all sessions. Train and validation counts each range from 44 to 126 Artifact==0 trials. No model was fitted and no synthetic data were generated.
- Machine-readable results: `fold_counts.json`; source: `scripts/research/audit_inner_load_holdout_feasibility.py`.

## Decision and follow-up

- Outcome: **pass for metadata feasibility.** Use two whole-load inner folds per outer fold, so hyperparameter selection is evaluated under the same type of unseen-load shift as the outer endpoint. Keep all trials of each set size on one side of each inner fold.
- The older five-fold within-load trial split at `outputs/track_b/20261023T234000Z_b2_inner_validation_feasibility/` remains valid as a nonempty random-trial split feasibility check, but it is **not** the active inner-tuning design because it places both outer-training loads in every validation fold and does not test load-shift selection.
- Limitation: inner tuning has only one load for training and one for validation, with fewer trials than the final outer fit. This informs model selection under condition shift but is not a performance estimate and needs independent review before protocol lock.
- B2 remains IN_PROGRESS. Next: update the active B2 spec and metric session to remove the five-fold contradiction; then continue finite tuning-budget and prior-art/pipeline-fidelity review. No model fitting authorized.
