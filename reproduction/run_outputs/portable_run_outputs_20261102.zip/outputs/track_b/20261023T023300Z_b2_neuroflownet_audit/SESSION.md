# B2 NeuroFlowNet primary-source and repository audit

Run ID: `20261023T023300Z_b2_neuroflownet_audit`  
Decision: Does NeuroFlowNet directly preempt the TKS scalp-to-iEEG task, and can its author repository support licensed, reproducible comparison?  
Scope: Paper and repository review only. No project dataset, local participant recordings/events, confirmation outcomes, synthetic data, or model fitting were accessed.

## Findings

The arXiv v3 paper describes a multi-scale conditional normalizing flow with affine coupling, invertible 1×1 channel mixing and self-attention. It models scalp EEG-conditioned medial temporal depth-iEEG waveforms and samples conditional outputs. It uses synchronized verbal working-memory recordings from nine epilepsy patients, selects S1, S6 and S9, and reports within-subject 90/10 held-out-trial and whole-session-held-out evaluations. It uses one-second segments; its paper says training segments overlap by 90% while evaluation segments do not. Reported endpoints include waveform error/correlation, PSD and alpha-band similarity, inter-channel correlation and an association between predictive variance and reconstruction error.

This is a direct prior-art collision for generic within-person scalp-to-iEEG waveform generation and same-person session transfer. The NEMAR cohort-provenance companion identifies its nine patients and trial/session labels as the same source cohort represented by OpenNeuro ds004752 sub-01 through sub-09. The paper's S1/S6/S9 correspond to sub-01/sub-06/sub-09. The project has not opened any local recordings or event outcomes for confirmation participants. NeuroFlowNet does not report a leave-one-load-out evaluation; its described trial split is random within sessions, not a test of prediction at an unseen working-memory load. That leaves a candidate evaluation question, not a novel algorithm or framework claim.

The arXiv v3 HTML page is dated 25 May 2026 and names *Biomedical Signal Processing and Control* in its header. A publisher record, DOI and final publication metadata were not independently verified. The full text says the cohort has nine patients and reports a task-specific, within-subject result; the authors explicitly state cross-subject generalization is not established because implant coverage differs.

The author repository was cloned read-only for inspection and pinned at commit `ce1b5120b7a93127e20a83c006190802e72a2b4e` (2025-08-16). Its root contains only `flow_model.py`, `preprocess.py`, `torch_dataset.py`, and `train_flow_model.py`; there is no README, license, test suite, or dependency manifest. No code has been run, incorporated, or adapted. Without an explicit license, do not reuse or redistribute it. The audited source hashes and detailed evidence are in `audit.json`.

Three repository-level reproducibility concerns were verified directly:

1. `preprocess.py` randomly assigns trials to train/validation within each session file. It contains no whole-session holdout implementation, although the paper describes that evaluation.
2. Each validation sample stores its own target iEEG mean and standard deviation. The validation trainer uses those held-out iEEG statistics to unnormalize generated predictions before computing MSE/MAE. This is an oracle target-scale/offset path unavailable when predicting a new iEEG signal from scalp EEG alone, so those code-path physical-unit errors are not deployment-available predictions.
3. The validation trainer applies `filter_intracranial_signal` to generated output after it is at 200 Hz, but does not override the function's default `fs=2000`. The function's normalized 0.5–60 Hz filter therefore corresponds to approximately 0.05–6 Hz on the 200-Hz output, while the target path applies the filter at 2 kHz before decimation. This is a sampling-rate mismatch in the repository code.

These observations establish that the inspected repository snapshot does not independently reproduce the paper's cross-session procedure or provide a leakage-free physical-amplitude metric. They do not establish that this exact code snapshot generated the published tables or prove that the paper's reported results are invalid. Any independent comparator must make normalization, output scaling, filtering and session splitting explicit and must not copy repository code.

## Primary sources

- He et al., [arXiv v3 full text](https://arxiv.org/html/2603.03354v3) and [abstract/version history](https://arxiv.org/abs/2603.03354).
- Author-linked repository at [pinned commit](https://github.com/hdy6438/NeuroFlowNet/tree/ce1b5120b7a93127e20a83c006190802e72a2b4e); exact inspected files: [`preprocess.py`](https://github.com/hdy6438/NeuroFlowNet/blob/ce1b5120b7a93127e20a83c006190802e72a2b4e/preprocess.py), [`torch_dataset.py`](https://github.com/hdy6438/NeuroFlowNet/blob/ce1b5120b7a93127e20a83c006190802e72a2b4e/torch_dataset.py), and [`train_flow_model.py`](https://github.com/hdy6438/NeuroFlowNet/blob/ce1b5120b7a93127e20a83c006190802e72a2b4e/train_flow_model.py).
- [NEMAR nm000363 cohort/provenance record](https://nemar.org/dataset/nm000363), which documents its relation to [NEMAR on004752 / OpenNeuro ds004752](https://doi.org/10.18112/openneuro.ds004752.v1.0.1).

## Decision effect

Keep B2 IN_PROGRESS. Reject generic within-person waveform reconstruction, session transfer, and conditional uncertainty generation as novelty claims. Do not reuse the unlicensed code. Retain held-load transfer only as a possible empirical challenge if remaining primary-source screening and the exact leakage-safe protocol support it. Continue to distinguish an evaluated signal prediction from anatomical source recovery, network truth, causal explanation, or thought decoding.
