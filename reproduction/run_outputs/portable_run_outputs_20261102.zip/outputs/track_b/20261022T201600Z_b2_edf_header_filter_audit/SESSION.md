# B2 source check: EDF acquisition header metadata (corrected parser)

## Session identity

- Run ID (UTC): `20261022T201600Z_b2_edf_header_filter_audit`
- Date/operator: 2026-10-22 UTC / Codex
- Gate: B2 IN_PROGRESS; B-1, B0, B1 PASS; B3-B8 NOT_STARTED.
- Data: NEMAR `on004752` v1.0.0; only development participants sub-01 through sub-03.
- Environment: Python standard library; CPU only.

## Decision this work can change

- Question: Do the EDF headers resolve the cutoff conflict between EEG `channels.tsv` and the EEG sidecars?
- Smallest check: Parse fixed EDF headers for the EEG and iEEG recordings in the 14 development sessions, verify header lengths, and summarize original per-channel prefilter text.
- Expected artifact: JSON containing header hashes and parsed channel metadata; no sample values.
- Stop condition: Blank/ambiguous prefilter text leaves the conflict unresolved; do not infer filters from it.

## Inputs and leakage boundary

- Inputs: Development-subject EEG and iEEG EDF files, first the 256-byte fixed header, then only the declared remaining header bytes.
- No event files, EDF data records, or confirmation participants are read. No synthetic data are created.
- Prior failed parser attempt is preserved at `outputs/track_b/20261022T201500Z_b2_edf_header_filter_audit/SESSION.md`; it failed before reading any data record.

## Prespecified interpretation

- Pass: Header prefilter strings are explicit and agree with a metadata source.
- Inconclusive: Strings are empty/generic or disagree.
- Limit: Header text is documentation of acquisition setup, not independent proof of actual filter application.

## Execution

- Command: `python scripts/research/audit_dev_edf_headers.py --dataset-root data/track_b/on004752_v1.0.0 --output outputs/track_b/20261022T201600Z_b2_edf_header_filter_audit/header_audit.json`
- Output: `header_audit.json` and `SUMMARY.md`.

## Decision

- Outcome: INCONCLUSIVE for resolving filter cutoffs; PASS for header-only audit integrity.
- Findings: All 28 development EDF headers (14 EEG, 14 iEEG) parsed with expected header lengths. EEG files encode 200 samples per record and iEEG files 2,000. All 916 per-channel `prefiltering` fields and physical-dimension fields are blank. Hashes cover only fixed EDF header bytes; no sample payload was read.
- Conclusion: EDF headers do not resolve the channel-table/sidecar cutoff conflict. Treat effective acquisition filters as undocumented by these fields; do not assume the EEG channels.tsv values were swapped or that sidecar acquisition filters fully describe the recording.
- Next: Keep acquisition-filter provenance open. After task selection, specify a justified common digital preprocessing filter separately from undocumented acquisition filtering.
