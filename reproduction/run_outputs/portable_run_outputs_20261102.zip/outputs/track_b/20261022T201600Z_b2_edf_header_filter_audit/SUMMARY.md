# Development EDF-header filter audit

The fixed-header audit parsed all 28 development EDF files: 14 scalp EEG recordings and 14 paired iEEG recordings across sub-01 through sub-03. Header sizes matched the EDF signal-count formula. Scalp files report 200 samples per record; iEEG files report 2,000. The `prefiltering` and physical-dimension fields are blank for all 916 listed signals.

The acquisition headers therefore do not resolve the cutoff conflict. The EEG `channels.tsv` values (`low_cutoff=1000`, `high_cutoff=0.5`) conflict with the EEG sidecar's 0.5-Hz high-pass and 1,000-Hz low-pass, but EDF prefilter strings do not document either interpretation. Do not silently transpose the channel fields or present sidecar values as verified effective filtering. The B2 protocol must state its own common digital preprocessing and retain the acquisition-filter uncertainty as a limitation.

The script read only each EDF's fixed header and the remaining declared header bytes. It read no signal data records, event files, or confirmation participants. See `header_audit.json` for per-file header hashes and parsed channel metadata.
