# Subramanian et al. primary-source audit

Date: 2026-10-23

## Scope

Audited the author-hosted bioRxiv PDF and Stanford Office of Technology Licensing record for the direct scalp-to-intracranial prediction study. No project signal data or confirmation outcomes were opened, and no model was fitted.

## Verified method

The PDF identifies itself as a bioRxiv preprint posted 7 April 2025 (DOI 10.1101/2025.04.07.647612) and states it was not certified by peer review. It reports simultaneous scalp EEG and SEEG from 20 people with drug-resistant focal epilepsy and 1,918 bipolar SEEG contacts. A 256-channel high-density EEG net was recorded; the model methods describe 19 scalp electrodes.

The main prediction endpoint is per-second spectral power in canonical frequency bands at each SEEG contact, predicted from scalp spectral power. The within-participant ridge analysis uses contiguous 80/20 temporal splits separated by a 6-second gap, inner ten-fold CV for regularization, and outer ten-fold CV for uncertainty. A separate regional leave-one-patient-out analysis trains on n-1 participants and evaluates all epochs from the held-out participant in predefined PFC, MTL, and OFC regions. Reported variance explained is modest on average and varies with frequency, depth, region, and analysis.

The authors also compared spontaneous-prediction scalp weights with scalp cortico-cortical evoked responses after direct stimulation (83 sites in 11 participants). This is a convergent association check; it does not show that the model predicts intervention-conditioned iEEG, identifies a unique neural source, or reconstructs arbitrary brain activity.

## Prior-art consequence

Generic claims that scalp EEG predicts intracranial activity, that predictability varies by depth/frequency, or that prediction maps relate to stimulation responses are already occupied. This study's target is spectral power, not raw iEEG waveform or a unique source map, and it does not evaluate held-out working-memory load on on004752. That narrower task difference remains a candidate evaluation distinction only; it does not establish novelty.

The PDF has no explicit code/data availability section, and the Stanford OTL record does not expose a public repository or dataset link. Public release was not verified. The Stanford OTL page describes potential applications; these are technology-transfer claims, not independent validation.

## Gate consequence

B2 remains IN_PROGRESS. Any surviving project framing must distinguish the actual held-load endpoint from spectral-power prediction and avoid claims of source recovery or general brain reconstruction. Continue remaining task- and method-level prior-art review before locking the estimand.

## Sources

- Author-hosted PDF: https://precisionneuro.stanford.edu/s/20250407647612v1full.pdf
- Stanford OTL record: https://techfinder.stanford.edu/technology/eeg-intramap-tool-predicting-intracranial-neural-activity-noninvasive-eeg-applications

## Data handling

No project dataset files, signal values, confirmation participants, or model outcomes were accessed.
