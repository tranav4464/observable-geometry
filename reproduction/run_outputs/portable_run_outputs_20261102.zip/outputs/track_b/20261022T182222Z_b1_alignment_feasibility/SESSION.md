# B1 alignment feasibility session

## Session identity

- Run ID (UTC): 20261022T182222Z_b1_alignment_feasibility
- Date/operator: 2026-10-22 / Codex
- Gate and status before work: B1 / IN_PROGRESS
- Git commit / working-tree state: Workspace is not a Git checkout; source files are pinned by the existing audit manifests.
- Environment lock / CPU-GPU: CPU reference; isolated Track B environment if signal processing is needed.
- Data and code versions/hashes: NEMAR on004752 v1.0.0; WBEN NeurIPS 2025 paper; eLife 2022 acquisition paper; existing BIDS and synchronization audit artifacts.

## Decision this work can change

- One decision question: Does the published WBEN real-data protocol and the released event-locked BIDS representation support a defensible event-relative 50 Hz paired analysis, so B1 can pass with a strict endpoint boundary?
- Why is this the earliest unresolved gate on the critical path? B1 is the first open prerequisite and blocks the formal specification and real-data model implementation.
- Smallest decisive check: Compare primary-source acquisition and WBEN preprocessing specifications with the pinned BIDS sample grids and development-only event pairs; verify an actual development pair can be transformed to the published shared 50 Hz grid without changing trial identity or using reserved outcomes.
- Expected artifact: This session record, a real-data alignment feasibility report, and a decision-log / gate update only if evidence meets the exit criteria.
- Stop condition: Stop or pivot if common task-relative epoch alignment cannot be justified from primary acquisition documentation and released trial metadata, or if the published endpoint requires tighter timing than the release supports.

## Inputs and leakage check

- Inputs opened/read (exact paths and hashes): See `INPUTS.json` for all source file paths and SHA-256 values; primary sources are linked in the report.
- Metadata, signal, image, or outcome data: Primary-source methods plus event metadata and, only if needed, real EEG/iEEG signal samples from development participants sub-01 through sub-03.
- Development or held-out role: Development only. No sub-04 through sub-15 event values or signal samples may be accessed.
- Could any input reveal a confirmatory outcome? Development data only; no confirmatory outcome is read.
- Allowed transformations / preprocessing: Reproduce the paper's trial-relative epoch framing and anti-aliased downsampling to 50 Hz only for feasibility checks; no training, hyperparameter tuning, or performance claims.

## Prespecified interpretation

- Pass condition: The published task defines paired 8-second event epochs and common 50 Hz analysis; the pinned BIDS release preserves paired trial labels and event-relative sample grids; the resulting timing limitation is explicitly bounded to event-relative 50 Hz analysis, not sample-perfect continuous synchronization.
- Fail/falsification condition: Primary sources or actual development metadata contradict pairing, the streams cannot be placed on the common event-relative grid, or the unresolved offset invalidates the 50 Hz endpoint.
- What result would change the next decision? Pass permits B1 to close for the bounded WBEN real-data endpoint and permits B2 formalization. Fail requires a real paired dataset with better timing evidence or a different endpoint.
- Baselines / negative controls: No model comparison is run in this session. Verify event order, sample-grid-derived onsets, epoch duration, and resulting 50 Hz tensor dimensions.

## Execution record

- Exact commands: To be filled after the audit.
- Seeds and configuration: None; deterministic audit.
- Warnings, exclusions, failures: To be filled after the audit.
- Outputs and checksums: To be filled after the audit.
- CPU reference and GPU parity evidence, if applicable: Not applicable.
- Independent metric/oracle check: Not applicable; no model metric is computed.

## Decision and follow-up

- Outcome: IN PROGRESS.
- Interpretation limited to: Event-relative preprocessing feasibility on the selected real dataset; not proof of exact continuous-stream clock synchronization or network truth.
- Ledger/matrix/protocol updates: Pending evidence.
- Next earliest gate action: Complete B1 alignment decision; if passed, begin B2 with real-data-only endpoint, splits, and leakage controls.
- Reviewer and review result: Pending.
