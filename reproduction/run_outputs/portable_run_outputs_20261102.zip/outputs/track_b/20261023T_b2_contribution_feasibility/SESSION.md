# B2 contribution feasibility session

## Session identity

- Run ID: `20261023T_b2_contribution_feasibility`
- Gate: B2, `IN_PROGRESS`
- Working state: no Git checkout detected at repository root.
- Work type: prior-art and mathematical design review; no fitting.

## Decision this work can change

- Question: Can a distinct, useful mathematical or computational contribution be added to the active real-data EEG-to-iEEG build without changing its measured endpoint, overstating evidence, or using confirmation outcomes?
- Why this is earliest: the project objective requires a contribution to be defined in B2 before implementation; the current specification explicitly calls itself a benchmark, not a new method.
- Smallest decisive check: compare the current proposed controls/estimands against primary work on paired scalp/iEEG prediction, conditional information, proper probabilistic scoring, and robustness under condition shift; reject any candidate that is only a renamed baseline or has no real-data endpoint.
- Expected artifact: a short decision memo listing viable candidate contribution(s), their equations, closest prior art, evidence needs, and go/no-go recommendation.
- Stop condition: stop if no candidate is distinguishable from established proper-score/permutation/uncertainty methods or if it requires unobserved neural ground truth.

## Inputs and leakage check

- Read active project records: `B0_CLOSEOUT.md`, `B2_NEUROFLOWNET_SPEC.md`, `B2_INDEPENDENT_REVIEW_PACKET.md`, `METHOD_MATRIX.md`, `PROJECT_DEFINITION.md`, and `MASTER_RESEARCH_PLAN.md`.
- Data: no project data; no event rows, signal samples, or confirmation outcomes accessed.
- Literature: primary papers and official proceedings only; search results are leads until verified.
- No synthetic neural data or model fitting will be used.

## Prespecified interpretation

- Retain a candidate only if it has a precise estimand/output, differs from closest methods, changes a meaningful researcher decision, can be evaluated on permitted real data and fair baselines, and has falsifying outcomes.
- If no such candidate survives, keep the build honestly classified as a clean-room implementation/challenge benchmark and surface that it does not meet the requested method-development ambition; do not invent novelty.

## Execution record

- Commands: current-state reads of B0/B2/specification/method matrix and active implementation files; primary-source search pending.
- No data access or model fit.

## Decision and follow-up

- Outcome: pending primary-source comparison.
- Next action: retrieve and compare primary literature on conditional predictive information and proper-score controls.
