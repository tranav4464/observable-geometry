# Exact-HEAD software release check: 9a88bad

**Commit:** `9a88bad1b0f9ff48fced1d352d5e36d1c0de4c89`  
**Source archive SHA-256:** `8aad5783b9bf6041b330c51fd14d121be3bc5451fcfcaa91397e4c55246bd8ab`  
**Wheel:** `observable_geometry-0.1.3.dev0-py3-none-any.whl`  
**Wheel SHA-256:** `acbb91388bc20cb91727a0ea2a2c8b8be4b1bfb79fb0cc66885c95647c33427f`

## Evidence

- Commit-bound workspace suite: 211 passed, 0 skipped, 0 failed.
- Extracted source archive: 209 passed, 2 documented skips, 0 failed. The skips are the repository evidence-path check (run against the complete workspace) and a dataset-dependent WSGZP check (dataset excluded from the source archive).
- Wheel provenance verification: all 7 checks passed; 18 Python modules match the exact committed source, and README, LICENSE, and `pyproject.toml` match the source stage. BSD-3-Clause metadata and license file agree.
- Fresh isolated install: passed under Python 3.12.14, NumPy 2.5.4, SciPy 1.18.1. Installed package modules match the wheel.
- Model-only CLI replay: exact parity against the established reference for all 40,980 ranked source pairs, score arrays, and summary metrics. The allowlisted input keys were `leadfield`, `noise_covariance`, `coordinates_m`, and `source_ids`; no EEG/iEEG sample arrays were accessed.

Machine-readable records are the commit-bound workspace and archive reports in `outputs/track_b/20261024_b8_release_checks/` and `outputs/track_b/20261024_b8_source_archive_tests/`, plus `wheel_source_verification.json`, `candidate_installation_verification.json`, and `candidate_cli_parity_numpy254.json` in this directory.

## Interpretation and limits

This closes the exact-HEAD package/source-install parity check for the current 9a88bad commit. It is software reproducibility evidence for one sealed participant model. It does not validate WSGZP MRI-to-electrode registration, neural source recovery, researcher decision benefit, population generalization, or a novel method. B8 still requires attributable external review and a release-version decision; the broader scientific validation gates remain unresolved or pivoted.

A first parity run under NumPy 2.3.5 reproduced the summary approximately but not byte-for-byte. That run is preserved separately as `candidate_cli_parity.json` and is not the release parity result. Repeating under the reference environment's NumPy 2.5.4 produced the exact pass recorded above.
