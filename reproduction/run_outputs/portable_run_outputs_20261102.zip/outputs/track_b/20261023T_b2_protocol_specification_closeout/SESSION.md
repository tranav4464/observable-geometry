# B2 protocol-specification closeout

## Decision record before work

- Run ID: `20261023T_b2_protocol_specification_closeout`
- Gate: B2, IN_PROGRESS
- Decision: Which remaining B2 protocol details can be frozen from the primary paper and existing development-only audits without exposing confirmation outcomes or fitting a model?
- Why now: The paper-to-source audit is complete, but the active specification still describes several items as open and repeats requirements already supported by existing audits. B2 is the earliest unresolved gate.
- Smallest decisive work: reconcile the active spec with the paper fidelity matrix and existing metric/access/split audits; freeze only choices directly supported by the source or explicitly label them as project adaptations; make the remaining external-review dependency explicit.
- Expected artifacts: updated B2 specification, decision/evidence records, and an auditable list of remaining B2 blockers.
- Inputs: primary NeuroFlowNet v3 methods; pinned read-only source audit; existing B2 development-only metadata and preprocessing artifacts. No confirmation event rows or signal samples.
- Pass interpretation: active documentation is internally consistent and complete enough for independent review; this does not by itself pass B2 or authorize fitting.
- Stop condition: any choice requiring held-out outcomes, unverified acquisition information, or external technical judgment remains explicitly open; do not guess or mark B2 passed.
- Restrictions: no dataset signals/events opened, no synthetic neural data created, no model fitted, no author code copied or run.

## Execution record

- Primary source rechecked: He et al., NeuroFlowNet v3, methods §§2.1–3.4, https://arxiv.org/html/2603.03354v3. The paper-selected model values, optimizer, batch, epochs, early stopping, preprocessing, and regression-baseline families were read directly. The inverse discrepancy remains exactly as recorded in the fidelity matrix.
- Adjacent primary literature checked: Subramanian et al., https://pmc.ncbi.nlm.nih.gov/articles/PMC12026988/ (scalp-to-intracranial spectral prediction and stimulation-response associations); the virtual-iEEG review at https://arxiv.org/abs/2608.26998 was checked for output semantics and generalization-regime framing. These sources reinforce that generic scalp-to-intracranial prediction is established and that no broad novelty claim is supportable.
- Metadata-only dimension check: `outputs/track_b/20261023T_b2_all_participant_channel_schema_audit_v2/channel_schema.json` records 16–64 stable iEEG contacts and the common scalp-input schema across 15 participants; no event values or signal samples were opened in this check.
- Active spec tightened: fixed paper-selected flow architecture/training recipe, source-informed attention/translation choices, explicit odd-channel split rule, paired training/draw seed derivation, fixed deterministic comparators, participant inclusion rule, channel/fold failure handling, and raw (uncalibrated) interval reporting. The full details are in `docs/track_b/B2_NEUROFLOWNET_SPEC.md`.
- Replaced stale active prose in `docs/track_b/B2_FORMAL_SPEC.md` with the current NeuroFlowNet route. The previous WBEN proposal is preserved verbatim in `docs/track_b/B2_FORMAL_SPEC_HISTORICAL_WBEN.md`.
- Updated `docs/track_b/B3_NEUROFLOWNET_IMPLEMENTATION.md` and `docs/track_b/B2_PAPER_FIDELITY_MATRIX.md` so the inverse correction and adaptation boundary are explicit before implementation.
- Restrictions honored: no confirmation events/samples accessed, no synthetic neural data generated/scored, no model fitted, and no upstream repository code copied or executed.

## Current decision

- The active B2 specification is ready for independent challenge and no longer contains the withdrawn WBEN route as active guidance.
- B2 remains `IN_PROGRESS` because the required independent technical review has not occurred. The reviewer packet is prepared but not reviewed; this authoring pass is not independent evidence.
- No B3 implementation/training or confirmation-data access is authorized by this record. Once B2 passes, B3 must run CPU mathematical invariants before real-data model fitting; B5 must be locked before confirmation outcomes are opened.


