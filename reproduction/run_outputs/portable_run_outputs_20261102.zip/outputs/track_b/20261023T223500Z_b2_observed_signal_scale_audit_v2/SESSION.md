# B2 real development-recording scale and unit crosswalk

**Run ID:** `20261023T223500Z_b2_observed_signal_scale_audit_v2`  
**Decision this audit can change:** whether WBEN's fixed observation-noise scales can be interpreted in the units of the released recordings, and whether the candidate preprocessing can safely use MNE's EDF reader.  
**Inputs:** actual paired EDF recordings and BIDS `channels.tsv` / `events.tsv` for the 14 development-only sessions of sub-01 through sub-03. Confirmation participants were not opened.  
**Output:** `signal_scale_audit.json`; no signal values saved.

## Procedure

Only artifact-unflagged real trials were read. The task event interval was verified as 8 seconds, then resampled to 50 Hz with the declared SciPy polyphase filter. Per-channel, per-trial sample SD was summarized for fixation `[0,1)` and final maintenance `[4,6)`. The script checked that EDF channel order matches `channels.tsv`, that channel units are `μV`, and that MNE parsed the blank EDF physical-dimension fields as `n/a`. It interpreted the unchanged EDF numeric arrays using the BIDS unit declaration. No model was fitted and no synthetic data were generated.

## Result

The corrected, artifact-unflagged counts were 176 trials for sub-01, 319 for sub-02, and 134 for sub-03. Median channel-trial temporal SDs in microvolts were:

| Participant | EEG fixation | EEG maintenance | iEEG fixation | iEEG maintenance |
|---|---:|---:|---:|---:|
| sub-01 | 24.17 | 11.79 | 60.40 | 57.68 |
| sub-02 | 13.13 | 15.40 | 32.67 | 40.54 |
| sub-03 | 21.14 | 21.11 | 38.07 | 40.68 |

These are **observed signal variability**, combining biological activity and instrument effects. Fixation is an active brain-recording interval, not an empty-room sensor-noise measurement. These SDs do not estimate WBEN's `P` or `S` and do not justify treating its appendix's values 1 and 0.1 as microvolts. They show participant and modality scale variation, supporting train-only channel standardization for prediction.

## Decision and limits

Keep WBEN's observation-noise values untransferred. The project adaptation must define its own effective covariance on the standardized scale, label it as model uncertainty rather than measured instrument noise, and tune or estimate it with training data only. The EDF/BIDS unit crosswalk must be part of the data loader; otherwise a library may label raw values as volts despite the release declaring microvolts. This audit does not determine the correct covariance or prove prediction performance.

The preceding v1 audit is invalid because it applied an erroneous `1e6` conversion; it is explicitly documented at `outputs/track_b/20261023T221500Z_b2_observed_signal_scale_audit/SESSION.md`.
