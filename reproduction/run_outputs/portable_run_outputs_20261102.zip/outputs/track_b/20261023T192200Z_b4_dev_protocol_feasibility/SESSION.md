# B4 Development Feasibility and Protocol Session

## Session identity

- Run ID (UTC): `20261023T192200Z_b4_dev_protocol_feasibility`
- Date/operator: 2026-10-23 UTC / Codex
- Gate/status before work: B4 / NOT_STARTED; prerequisites B0–B3 recorded PASS.
- Git commit / working-tree state: project directory has no `.git` repository; no commit identity is available. Source and input hashes are recorded below.
- Environment: Windows, CPU reference; no GPU computations planned.
- Data role: Localize-MI sub-01 is development-only and already exposed in sealed Track A. No held-out analysis is authorized in this session.

## Decision this work can change

- Decision question: Does the existing one-participant real-data case support a fair, bounded B4 development comparison of the GBF forward-signature ranking against standard inverse-resolution diagnostics, or is that empirical comparison too mismatched to support even exploratory interpretation?
- Why this is the earliest unresolved gate: B4 is the next NOT_STARTED gate after the recorded B0–B3 passes; B5/B6 are blocked until development assumptions, comparator matching, and leakage boundaries are resolved.
- Smallest decisive check: Audit the sealed Track A six-site artifact-localization endpoint, saved pairwise scalp-map similarities, MNE resolution outputs, source code, and protocol assumptions for a common estimand and compatible inputs. Do not infer from dependent pairs as if independent.
- Expected artifact: This protocol/access record, a documented feasibility decision, and, only if inputs support it, a new immutable exploratory run with matched descriptive summaries and a list of failed checks.
- Stop condition: Stop the empirical comparison if model and measured artifacts do not share channel/reference/covariance contracts, if actual outcomes cannot be tied to the named stimulation sites, or if the comparison would require calling a pulse artifact endogenous neural activity. A failed feasibility result closes no scientific claim and triggers a narrowed B4 report.

## Inputs and leakage check

Inputs already read for this feasibility framing:

- `docs/track_b/GATE_REGISTER.json` SHA-256 `4476EED1D1835C85AB53DA8525ED9474F3EF477738958B135525F01EA5EAE73D`
- `docs/track_b/GBF_BUILD_PLAN.md` SHA-256 `52EF0CFAB85FC4948B0ED711CB35E2508F9E972DC93D4DA799FFA3B385BF5497`
- `docs/track_b/B2_GBF_SPEC.md` SHA-256 `1024C4C80CA31D1375CC13A078BC52AB5B5C58136F8C0ECE7DEBB96F0C3E1062`
- `outputs/tracka_release_20261022_v2/empirical_evaluation_report.json` SHA-256 `F4A8E9DD2FF3E162EC68FF46ADAE19D33247F70AB53D53207273B119588A0F3C`
- `outputs/tracka_release_20261022_v2/run_manifest.json` SHA-256 `DC34E97C55AA7B0F3349191743293F1850E9F286B7302FB3A6B17BFFE7A6902B`
- `src/observable_geometry/analysis/distinguishability.py` SHA-256 `0D3517CA269CF1B63CB46D17D719F23A5451994C71EAEF4EA0B6970182D13C63`
- `scripts/research/run_b3_distinguishability.py` SHA-256 `A4F30B1B9C304BCC917A7C100C54C3BA32F082054E01A94CF9E321E776BA9FA0`

The existing report is an outcome-bearing development artifact. Its six real 1 mA sites and 15 dependent site-pairs were already used in Track A; these data are expressly not held out and cannot support confirmatory claims. No new signal samples, held-out outcomes, or model fits have been opened in this B4 session so far. Any future B4 calculations on this case remain exploratory and must be reported with the dependence structure and endpoint caveat.

## Prespecified interpretation

- Candidate measure: B2's nominal whitened, normalized, absolute forward-signature cosine between fixed-orientation focal source hypotheses. Do not claim calibrated error or source recovery.
- Comparator: the same-case fixed-orientation MNE minimum-norm resolution/PSF/CTF outputs under the same channel set, reference, source grid, and covariance contract. Do not compare numerically unlike metrics as if they estimate the same quantity; define any common-ranking transformation before looking at comparative outcomes.
- Real endpoint: known-contact scalp pulse-artifact maps only. This is an instrumented electrical artifact endpoint, not endogenous physiological source activity.
- Primary descriptive question: whether forward-signature ranks and a prespecified, common-estimand transformation of MNE resolution produce materially different alternative-site reporting for the six sites. Any correlation over the 15 pairs is descriptive only; sites are reused and n=1 participant.
- Sensitivity checks allowed: inspect only already-recorded real baseline covariance alternatives and channel subsets if their provenance is documented; keep the nominal fixed contract primary and report all tested assumptions. No synthetic signals, synthetic datasets, or outcome-tuned thresholds.
- Negative controls: same-site repeat maps across real stimulation intensities/runs, only where repeated site identity and event alignment are verified; report as repeatability controls, not proof of biological correctness.
- Pass condition for a useful B4 development result: the comparator matching and source-to-contact mapping are verified, all deviations and failures are retained, and the comparison yields a clearly bounded result without crossing from artifact to physiological claims. This does not establish novelty or decision utility.
- Fail/falsification: comparator is not matched, controls contradict the interpretation, measured maps are unreliable, or the distinction disappears under defensible analysis assumptions. Preserve and report the failure.
- Decision-changing result: whether to proceed to protocol lock for a separate, outcome-unexposed participant cohort, revise the tool to a no-claim reproducibility utility, or pivot because no distinct empirical question survives prior art.

## Prior-art constraint

Searches conducted before this protocol record surfaced direct established work on Localize-MI's stimulation-based source-localization benchmark (Mikulan et al., 2020), empirical intracranial-stimulation validation (e.g., 2023 Brain Communications), source-resolution matrices/PSF/CTF, and two-source EEG separability. Therefore B4 is an evaluation/benchmark gate; its analysis is not to be described as a new separability metric. Any later distinct contribution must be supported by a separate novelty screen and independent challenge.

## Execution record

- Commands: none for signal processing or model fitting in this session yet.
- Seeds/configuration: not applicable.
- Warnings/failures: working directory is not a Git checkout, so hash-based provenance must substitute unless repository provenance is restored without changing sealed artifacts.
- Outputs/checksums: this session record.
- Independent recomputation: pending.

## Decision and follow-up

- Outcome: feasibility review in progress; no B4 pass claimed.
- Interpretation limited to: one participant, six stimulation sites, pulse-artifact maps, existing development outputs.
- Next action: inspect exact MNE resolution artifacts, source-to-contact mapping, real repeat-run structure, and the primary Localize-MI paper's analysis scope; then decide if a fair exploratory comparator calculation is scientifically coherent. Do not access any held-out participant outcomes until a valid protocol is separately locked under B5.

## Follow-up record (24 October 2026)

The planned sub-01-only rerun was performed under the separate run ID `20261023T192900Z_b4_matched_224_reproduction`. It reproduced the sealed 15-row pairwise CSV byte-for-byte under the common 224-channel contract. The rerun remains descriptive and uses the stimulation pulse artifact. The previous output `b4_site_associations.csv` is not valid for matched-method inference because its manifest identifies 236-channel GBF/MNE-resolution arrays joined to 224-channel empirical errors. The initial KeyError attempt remains a preserved failure and opened no signal samples. B4 is pivoted to the bounded software/reproduction scope; see `docs/track_b/B4_DEVELOPMENT_AUDIT_20261024.md` and `B4_CHANNEL_MATCH_RECONCILIATION_20261024.md`. No held-out participant outcomes were opened.
