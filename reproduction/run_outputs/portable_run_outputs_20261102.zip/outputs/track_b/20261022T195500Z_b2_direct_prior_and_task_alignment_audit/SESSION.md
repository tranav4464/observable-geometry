# B2 direct-prior and task-alignment audit

**Decision this audit can change:** whether cross-set-size prediction of measured iEEG is a defensible primary task for the selected WBEN reproduction/challenge, and whether a distinct contribution remains.

**Scope:** primary-source literature review only. No dataset files, neural signals, event rows, reserved participants, synthetic data, or model outputs were accessed or generated.

## Findings

1. **Direct scalp-to-iEEG reconstruction is now a crowded and fast-moving area.** NeuroFlowNet reports conditional-normalizing-flow waveform reconstruction on paired recordings, including within-participant cross-trial/session settings. Its arXiv page links a public author repository. The repository root presently exposes four Python files and no visible README or license file; code reuse is therefore not established as permissible. The paper is a direct collision for a generic within-participant waveform-reconstruction claim.

2. **Cross-participant waveform reconstruction is also directly occupied.** CAST (arXiv:2605.18897) reports a multiscale Transformer trained leave-one-subject-out, followed by 20% target-subject calibration and an 80% test partition. It includes ds004752 and reports channel-wise waveform reconstruction. The paper labels ds004752 as visual categorization, while the official dataset record describes a verbal working-memory Sternberg task with set sizes 4, 6, and 8. Until the authors' analyzed release, event subset, and task labels are reconciled, its reported results are not a reliable matched baseline. The claimed task distinction cannot be treated as settled by the paper's table.

3. **A second recent paper separates temporal localization from waveform reconstruction.** Matsubara et al. (2026 medRxiv preprint) use six participants from a simultaneous high-density scalp EEG/iEEG cohort and distinguish locating an interictal discharge in time from reconstructing contact-level event morphology beyond a patient-specific template. This preempts a broad “what can EEG recover?” framework but is a different clinical event target from working-memory load.

4. **Scalp-to-iEEG spectral prediction already has a direct empirical precedent.** Subramanian et al. analyze 1,918 contacts in 20 patients using within-subject regularized regression and leave-one-patient-out Bayesian models; the targets are intracranial band-power time series rather than raw waveforms or working-memory condition transfer.

5. **Working-memory load itself is not a new signal or modeling question.** Existing scalp EEG work decodes load across tasks, and a 2025 study reports load-related iEEG power and interregional synchronization in the same verbal-working-memory dataset. A load effect or cross-task load classifier alone is not a contribution. A held-out-set-size prediction of measured iEEG would differ in target and split, but that only makes it a candidate empirical challenge, not a new method.

6. **There is a mismatch between the selected base and the candidate task.** WBEN is a joint scalp+iEEG state-space method whose reported real-data output is estimated network flow during encoding and maintenance. It is not simply a supervised scalp-only map from EEG to a measured iEEG waveform. The proposed cross-load task therefore requires an explicit derivation of how the fitted WBEN model predicts a withheld iEEG target from permitted scalp observations, including whether the test iEEG is excluded from inference. A separate direct regression benchmark cannot be presented as a WBEN reproduction.

7. **The anatomical mapping blocker remains material.** The EasyReg point-transform audit gives a reproducible coordinate-map variant, but its round-trip error checks numerical consistency, not anatomical validity. It assigns 366/760 development contacts (48.2%) to the selected Harvard–Oxford labels and yields only three labels shared by all three development participants. This is not sufficient evidence for a stable, cross-participant regional comparison, and the mapping is not WBEN's verified contact-assignment operator. A contact-level task could avoid atlas correspondence, but would be a different task/model interface and must be named honestly.

## B2 decision

Do not lock cross-load transport as the primary task yet. It remains plausible as a real-data challenge, but the evidence does not support novelty, a cross-participant regional target, or a faithful WBEN reproduction under the current coordinate map. Before B2 can pass, choose explicitly between:

- reproducing WBEN's published real-data network-flow analysis with a documented regional mapping variant, while limiting the claim to that variant; or
- defining a contact-level held-out prediction task and treating WBEN only as a conceptual/related-work base unless a valid WBEN prediction operator can be derived from the paper.

Then specify one target, one split, allowed test-time inputs, training-only preprocessing, baselines, primary metric, uncertainty, and a falsifier. The method contribution remains unproven. If no distinct method survives the comparison, preserve the project as a useful, rigorous reproduction/challenge build rather than adding a novelty label.

## Primary sources checked

- Yang & Liu, WBEN, NeurIPS 2025: https://proceedings.neurips.cc/paper_files/paper/2025/hash/82a6afb1f666daaeec8da4d775452bc7-Abstract-Conference.html
- He et al., NeuroFlowNet, arXiv:2603.03354: https://arxiv.org/abs/2603.03354
- NeuroFlowNet author repository: https://github.com/hdy6438/NeuroFlowNet
- Pham & Tran, CAST, arXiv:2605.18897: https://arxiv.org/abs/2605.18897
- Matsubara et al., medRxiv: https://doi.org/10.64898/2026.09.25.26364055
- Subramanian et al., scalp EEG predicts intracranial activity: https://pubmed.ncbi.nlm.nih.gov/40291696/
- Boring et al., cross-task cognitive-load EEG decoding: https://doi.org/10.1088/1741-2552/abb9bc
- Boran et al., paired verbal working-memory dataset description: https://www.nature.com/articles/s41597-020-0364-3
- Official on004752 record: https://www.nemar.org/dataset/on004752
- Yang et al., working-memory load and entorhinal cortex: https://pubmed.ncbi.nlm.nih.gov/40593531/

## Reproducibility note

This is a bounded primary-source audit, not an exhaustive systematic review and not an independent reproduction of any cited result. In particular, CAST's event-label mismatch, NeuroFlowNet's reuse terms, and the relationship between the released contact coordinates and a valid shared atlas remain unresolved.
