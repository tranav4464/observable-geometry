# B1 alignment feasibility verification

## Session identity

- Run ID (UTC): 20261022T182700Z_b1_alignment_verification
- Date/operator: 2026-10-22 / Codex
- Gate and status before work: B1 / IN_PROGRESS
- Git commit / working-tree state: Workspace is not a Git checkout; source data and upstream code are pinned by the existing manifests and audit records.
- Environment lock / CPU-GPU: CPU; `.venv` with MNE 1.13.2, NumPy 2.5.4, SciPy 1.18.1. GPU not needed for this small deterministic check.
- Data and code versions/hashes: NEMAR on004752 v1.0.0 / OpenNeuro ds004752 v1.0.1. The audit JSON records SHA-256 for each development EDF and event TSV; script SHA-256 is `F72D174B1EB32E004CCA7FB3E922494892F4AD8119C034C601827220EB61E347`.

## Decision this work can change

- One decision question: Does the published WBEN real-data protocol and the released event-locked BIDS representation support a defensible event-relative 50 Hz paired analysis, so B1 can pass with a strict endpoint boundary?
- Why is this the earliest unresolved gate on the critical path? B1 is the first open prerequisite and blocks the formal specification and real-data model implementation.
- Smallest decisive check: Compare primary-source acquisition and WBEN preprocessing specifications with the pinned BIDS sample grids and development-only event pairs; verify that a real development trial reaches the shared 50 Hz shape without changing trial identity or reading reserved outcomes.
- Expected artifact: This session record and an alignment feasibility report supporting a B1 decision.
- Stop condition: Stop or pivot if paired event-relative epoch alignment contradicts primary acquisition documentation, fails on released development trials, or WBEN requires timing finer than the released event-locked representation supports.

## Inputs and leakage check

- Inputs opened/read: Event TSVs and channel headers for sub-01 through sub-03 (14 sessions); one trial of each real signal modality from sub-01/ses-01; associated EDFs and BIDS sidecars. Exact signal/event hashes are recorded in `alignment_feasibility.json`.
- Metadata, signal, image, or outcome data: Development event metadata and a single real EEG/iEEG trial for shape/finite-value verification. No signal values were saved.
- Development or held-out role: Development only. No sub-04 through sub-15 event values or signal samples were accessed.
- Could any input reveal a confirmatory outcome? No; only development participants were accessed.
- Allowed transformations / preprocessing: Decode one-based inclusive sample bounds; resample one real trial from 200/2,000 Hz to 50 Hz using `scipy.signal.resample_poly` for shape feasibility only. No model fitting, tuning, or performance metric.

## Prespecified interpretation

- Pass condition: The published task defines paired 8-second event epochs and common 50 Hz analysis; the pinned BIDS release preserves paired labels and event-relative sample boundaries; any limitation is explicitly bounded to event-relative 50 Hz analysis.
- Fail/falsification condition: Primary sources or development data contradict pairing, corrected boundaries differ, signal arrays do not yield matched 400-sample epochs, or the timing representation does not support WBEN's published endpoint.
- What result would change the next decision? Pass permits B1 to close for bounded event-relative real-data work and permits B2 formalization. Fail requires another real dataset or narrower task.
- Baselines / negative controls: No model comparison. Verify trial identity, sample-index arithmetic, duration, sample counts, finite values, and target-rate shapes.

## Execution record

- Exact command: `$env:PYTHONPATH='src'; .\\.venv\\Scripts\\python.exe outputs\\track_b\\20261022T182700Z_b1_alignment_verification\\audit_alignment.py`
- Result: 14 paired development sessions passed trial-order, label, and corrected event-boundary checks. One real trial was decoded as EEG 19×1600 and iEEG 48×16000, then resampled to 19×400 and 48×400 at 50 Hz; all values were finite.
- Warnings, exclusions, failures: None in the tested development sample. This does not resolve two malformed absolute EDF timestamp fields in sub-06/ses-04 iEEG and sub-14/ses-06 EEG; the endpoint is event-relative and the primary pipeline must normalize those headers safely or exclude the paired sessions before outcome access.
- Outputs and checksums: `alignment_feasibility.json`; no signal values saved. The JSON contains event/EDF SHA-256 hashes for all 14 development pairs.
- CPU reference and GPU parity evidence: Not applicable.
- Independent metric/oracle check: No model metric computed. Event boundary arithmetic was asserted independently in the audit script against inclusive one-based sample bounds.

## Decision and follow-up

- Outcome: PASS for the bounded event-relative 50 Hz endpoint.
- Interpretation limited to: Event-relative preprocessing feasibility on the selected real dataset; not proof of arbitrary continuous-stream synchronization, sub-sample precision, network truth, or causal connectivity.
- Ledger/matrix/protocol updates: B1 closeout report and gate status; no synthetic data used.
- Next earliest gate action: Begin B2 with a real-data-only endpoint, exact participant/session/trial split, preprocessing contract, metrics, matched baselines, and prior-art comparison. Do not expose reserved outcomes before B5.
- Reviewer and review result: No external reviewer has reviewed this audit. The existing B1 gate contract requires review before confirmatory outcomes are opened; sub-04 through sub-15 remain sealed.
