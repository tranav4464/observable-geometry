# B2 NLGC regularization-selection audit

## Session identity

- Run ID (UTC): `20261022T205417Z_b2_nlgc_regularization_audit`
- Date/operator: 2026-10-23 local; Codex
- Gate and status before work: B2, IN_PROGRESS
- Git commit / working-tree state: no `.git` directory is present at the workspace root, so no commit hash can be recorded.
- Environment lock / CPU-GPU: literature-only; no compute workload
- Data and code versions/hashes: no project data or model code opened for this source check

## Decision this work can change

- Decision: whether NLGC's estimation-stability cross-validation should be used as the tuning objective for the proposed held-load scalp-to-iEEG prediction task, or presented as the project's method contribution.
- Why this is on the critical path: B2 must justify the hyperparameter-selection rule and distinguish any retained contribution from close prior work before any real model fit.
- Smallest decisive check: inspect the published NLGC method's regularization-selection description and compare its target and score with the current candidate endpoint.
- Expected artifact: this source audit plus a B2 specification update.
- Stop condition: stop treating the NLGC criterion as a candidate contribution if its estimand/decision differs from the prediction task and no distinct, testable extension is defined.

## Inputs and leakage check

- Sources consulted: Soleimani et al., *NLGC: Network localized Granger causality with application to MEG directional functional connectivity analysis*, NeuroImage 260 (2022), [published article](https://pmc.ncbi.nlm.nih.gov/articles/PMC9435442/), and its [NSF public-access manuscript record](https://par.nsf.gov/servlets/purl/10341493).
- Literature only. No project data, signal values, event rows, model outputs, or confirmation participants were accessed. No synthetic data were generated.
- The public-access article page was intermittently blocked by a browser challenge; indexed full-text excerpts from the paper and the NSF manuscript record were used to identify the stated procedure. This audit therefore supports the narrow method description below, not a complete equation/code replication of NLGC.

## Prespecified interpretation

- Pass condition: determine what NLGC selects and whether that selection rule is directly aligned with the candidate held-load iEEG prediction endpoint.
- Fail/falsification condition: treating stability selection as equivalent to predictive validation, or claiming the stability criterion itself as a new contribution.
- NLGC uses standard K-fold cross-validation for the regularization parameter, ties the source-wise penalty to one shared scalar, and selects using an estimation-stability criterion: reconstructed MEG estimates are compared across folds and the candidate with lowest cross-fold variance is chosen. It then reuses that value for reduced models.
- The candidate Track B task instead scores prediction of actually recorded, held-out iEEG under a held-out working-memory load. The observation target, model, split estimand, and decision differ from NLGC's MEG network/Granger-estimation stability objective. The criterion is a useful prior-art comparator, but it does not justify replacing task-aligned held-out prediction error as the tuning objective, nor is it itself a contribution here.
- This conclusion is provisional because B2's target/model interface, noise parameterization, and final baseline suite remain unresolved.

## Execution record

- Research queries searched the exact NLGC title and its regularization/cross-validation description; the primary article and public-access manuscript were identified.
- No parameter search or model fitting was run.
- No GPU work was applicable.

## Decision and follow-up

- Outcome: supported with limits
- Interpretation limited to the published tuning rationale for NLGC; not evidence that the same score is useful or calibrated for the Track B endpoint.
- Update the B2 spec, evidence ledger, method matrix, and decision log. Keep B2 IN_PROGRESS.
- Next earliest gate action: finish the task-level prior-art and exact tuning/noise rule audit; do not inspect confirmation outcomes or fit the Track B model until B2 passes.

