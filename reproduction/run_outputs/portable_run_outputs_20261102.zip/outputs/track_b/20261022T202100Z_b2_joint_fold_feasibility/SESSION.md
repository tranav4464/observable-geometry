# B2 joint held-load/held-session metadata feasibility

## Decision this work can change

Does the provisional within-participant split have nonempty artifact-unflagged training and test trials in each development fold, or should the proposed cross-load task be rejected before signal/model work?

## Smallest useful check and expected artifact

Enumerate all event rows for development participants sub-01 through sub-03. For each set size and held-out session, count test trials at the held set size in that session and training trials at the other set sizes in all other sessions. Report the existing Artifact and Correct fields without reading signal samples. Save fold counts and a summary; a fold with zero eligible test or training trials falsifies the split as written.

## Inputs and access boundary

- Dataset: pinned NEMAR on004752 v1.0.0 release.
- Files: `events.tsv` only, for sub-01 through sub-03.
- No neural samples, confirmation participants, or synthetic data.
- `Artifact==1` is excluded only for feasibility counting. Incorrect trials remain eligible because this candidate predicts recorded signals by task load, not behavioral correctness. This is not yet a locked protocol.

## Execution

- Run ID: `20261022T202100Z_b2_joint_fold_feasibility`
- Command: `python scripts/research/audit_dev_joint_load_session_folds.py --dataset-root data/track_b/on004752_v1.0.0 --output outputs/track_b/20261022T202100Z_b2_joint_fold_feasibility/fold_feasibility.json`
- Expected output: per-participant folds and minimum/median eligible trial counts.

## Interpretation

Nonempty folds establish only metadata feasibility. They do not establish enough independent participants, adequate statistical power, model fit, target quality, or scientific utility. A pass here does not lock the split or authorize confirmatory data access.
