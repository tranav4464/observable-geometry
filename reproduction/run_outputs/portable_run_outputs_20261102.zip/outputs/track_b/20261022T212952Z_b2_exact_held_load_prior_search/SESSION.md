# B2 exact held-load target prior-art search

## Session identity

- Run ID (UTC): `20261022T212952Z_b2_exact_held_load_prior_search`
- Gate before work: B−1, B0, B1 PASS; B2 IN_PROGRESS
- Decision this audit can change: whether cross-load prediction of measured iEEG contacts has already been demonstrated closely enough to abandon it as a useful reproduction/challenge endpoint.
- Inputs: primary-source search for simultaneous scalp/intracranial EEG prediction, working-memory load decoding, and the on004752 dataset; existing B2 task and data audits.
- Data boundary: no local recordings, event rows, confirmation participants, model fits, synthetic datasets, or synthetic signal fixtures were accessed or generated.

## Search procedure

Searches run 23 October 2026 local time:

1. `scalp EEG intracranial EEG held-out working memory load set size prediction iEEG waveform`
2. `EEG predict iEEG set size working memory held out load EEG iEEG prediction`
3. `non-invasive scalp EEG estimate intracranial activity working memory load 4 6 8 SEEG`

The search results were followed to the available primary sources. This is a bounded targeted search, not a systematic review and not evidence that no such work exists.

## Findings that affect the task

- Subramanian et al. directly predict intracranial band power from scalp EEG, with within-participant and regional leave-one-patient-out analyses. This preempts generic scalp-to-iEEG prediction. Its paper does not report the proposed fully withheld set-size contact-waveform evaluation. [Primary article](https://pmc.ncbi.nlm.nih.gov/articles/PMC12026988/)
- Boring et al. show cross-task cognitive-load decoding from scalp EEG. This preempts generic task/load generalization claims, but predicts load labels rather than measured paired iEEG contact waveforms. [Primary article](https://doi.org/10.1088/1741-2552/abb9bc)
- The on004752 record and its original dataset paper establish simultaneous scalp EEG/iEEG recordings and working-memory set sizes 4, 6, and 8. That makes the candidate data split feasible in principle, not scientifically predictive. [Dataset record](https://nemar.org/dataset/on004752), [dataset paper](https://doi.org/10.1038/s41597-020-0364-3)
- WBEN is a joint scalp/iEEG state-space network-estimation method. The B2 derivation shows that a scalp-only filter can be formulated, but that inference adaptation is not the paper's reported analysis. [WBEN paper](https://papers.nips.cc/paper_files/paper/2025/file/82a6afb1f666daaeec8da4d775452bc7-Paper-Conference.pdf)
- Phillips et al. report synchronous scalp/sEEG association using rank correlation, mutual information, and directed information. The available institutional record exposes an abstract, not the full five-page methods, so exact task overlap remains unresolved. [Publication record](https://scholars.houstonmethodist.org/en/publications/characterizing-the-relationship-of-non-invasive-and-invasive-neur/)

No inspected primary source in this bounded search explicitly reports the exact combination of (a) a whole working-memory set size withheld from paired training, (b) scalp-only test-time input, and (c) prediction of simultaneously measured iEEG contact waveforms in on004752. This is a bounded search outcome only. It does not establish priority, novelty, or superiority.

## Decision

Keep the within-participant leave-one-set-size-out evaluation as a **provisional reproduction/challenge benchmark**. Do not retain an algorithm-novelty claim. The candidate question is whether a WBEN-informed state-space predictor adds held-load predictive value over direct regularized regression and a training-mean baseline when predicting the recorded common-reference iEEG contact signal. Any success would establish only this task-specific prediction result after calibration on other loads; it would not establish latent-source recovery, an anatomical map, causal connectivity, thought decoding, or transfer to a new participant.

This audit does not close B2. The exact contact-state model and effective noise treatment remain underdefined, the Phillips full methods and other close task-level literature remain unresolved, and the task needs independent technical challenge before it is frozen. Do not fit a new model until those B2 requirements are resolved. If a direct target-aligned prior-art collision or a non-identifiable model interface is found, pivot or narrow the benchmark rather than describing it as novel.

## Pass/fail interpretation and stop condition

- Pass for this bounded search: no exact task collision was found in the sources returned and inspected; retain only as a challenge candidate.
- Fail for an algorithm-novelty claim: neighboring work already covers generic scalp-to-iEEG prediction, cross-task load decoding, and paired scalp/iEEG association; no new method has survived review.
- Stop condition: do not expand this search into broad literature collection unless a newly identified source could change the exact held-load/contact-waveform task decision. The remaining B2 work is model identifiability, protocol specification, targeted primary-source resolution, and independent review.
