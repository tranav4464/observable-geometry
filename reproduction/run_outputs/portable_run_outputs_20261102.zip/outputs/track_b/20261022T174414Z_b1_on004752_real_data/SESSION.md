# B1 real-data acquisition session

- Run ID (UTC): 20261022T174414Z_b1_on004752_real_data
- Gate/status before: B1 PASS for the old synthetic-only scope; reopening it as IN_PROGRESS because the active user objective requires real recordings and forbids synthetic datasets.
- Decision: Can pinned NEMAR on004752 provide a licensed, actual paired scalp-EEG/iEEG dataset suitable for a development and later participant-held-out evaluation of the WBEN software?
- Smallest decisive check: verify official version, CC0 license, participant/session coverage, exact raw-file manifest, checksums, and available disk before fetching the raw signal files.
- Dataset/version: NEMAR on004752 v1.0.0, DOI 10.82901/nemar.on004752; the dataset record identifies 15 epilepsy patients performing verbal working memory and simultaneous scalp EEG/iEEG.
- Input role: real public EEG/iEEG files were acquired and checksum-verified. Event rows were inspected only for development participants sub-01 through sub-03; no signal samples have been analyzed.
- Selected files: 816 BIDS EEG/iEEG files; 10.23 GB raw data.
- Manifest SHA256: 86FC1DAD1588109937A8F1C3F7F7EB37A68F5CA20EED76761D6E41667CCA2080
- Selected file-list SHA256: 74610D5D17FAA6EB9C97747DB859CA171CDE22E5C1C738DCD7D57A7763FA1649
- Storage root planned: data/track_b/on004752_v1.0.0 (ignored data directory; source version pinned).
- License check: official NEMAR dataset record states CC0; retain attribution/citation and data-use note.
- Pass condition: all selected files are downloaded to the pinned folder, file sizes and manifest SHA-256 checksums verify, EDF files parse, and BIDS metadata are reconciled sufficiently to define an endpoint.
- Failure condition: manifest inconsistency, integrity failure, missing paired modalities, data synchronization/protocol defects that invalidate the chosen endpoint, or no defensible participant split.
- Stop condition: do not process model outcomes until endpoint and split are specified; stop the WBEN route if recordings cannot support the documented task.
- Outputs: pinned full manifest, selected raw-file manifest, root BIDS metadata, and download/integrity log.


## Acquisition and safe metadata audit closeout

- Transfer completed: 816/816 manifest entries; 10,984,433,222 bytes.
- Independent SHA256/Git-blob integrity audit: PASS for all 816 files; zero size or checksum failures. Evidence: `independent_integrity_audit.json`.
- All-participant header-only audit: 68/68 sessions structurally passed; no event rows or signal samples were read. Evidence: `all_participants_header_only_audit.json`.
- Two EDF timestamps need source-level interpretation: `sub-06/ses-04` iEEG start time `10.28.60`, and `sub-14/ses-06` EEG start time `14.23.60`. MNE refuses these timestamps. A byte-level EDF parser validated the header structure, channel/sample-rate metadata, and declared file length without modifying the original recordings.
- The pinned release contains 68 paired sessions; the eLife source paper reports 71. This discrepancy remains unresolved.
- The session and timestamp discrepancies leave B1 IN_PROGRESS. No B2 model fitting or reserved-participant outcome inspection was performed.
