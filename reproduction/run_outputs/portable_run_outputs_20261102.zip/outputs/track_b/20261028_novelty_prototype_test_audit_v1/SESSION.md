# Novelty prototype numerical test rerun

Date: 2026-10-28  
Purpose: verify existing algebraic/numerical regression coverage for the exploratory source-family span screen, two-sided capped-branch fit, robust attribution, forward-error envelope and stability helpers.  
Command: `.venv/Scripts/python.exe -m pytest tests/test_two_sided_audit.py tests/test_robust_attribution.py tests/test_track_b_forward_error_budget.py tests/test_track_b_stability.py tests/test_observability_certificate.py -q`  
Exit code: 0  
Environment: Python 3.12.14  
Repository HEAD: `af0d86942fdbbd346231ac07bf43078e80713c83`  

Output:

```text
.......................                                                  [100%]
23 passed in 2.35s
```

## Scope limit

These tests use algebraic/regression fixtures and verify software invariants only. They are not measured EEG/SEEG analyses, source-recovery validation, calibration evidence, prior-art comparisons or proof of novelty. The current protocol remains unlocked and no neural sample values were accessed in this run.

## SHA-256 inputs

- `<LOCAL_ACCOUNT>\OneDrive\Desktop\TKS\observable_geometry\src\observable_geometry\track_b\two_sided_audit.py`: `7E0B6795411D4FD52B14AE93098FDDCA62A1FF3FA73BEBA65AD49A692B048D0F`
- `<LOCAL_ACCOUNT>\OneDrive\Desktop\TKS\observable_geometry\src\observable_geometry\track_b\robust_attribution.py`: `A61BE994973B0D06BA2C65C7A4129DB9856413DAA89F170FE069E99CDACFD611`
- `<LOCAL_ACCOUNT>\OneDrive\Desktop\TKS\observable_geometry\src\observable_geometry\track_b\forward_error_budget.py`: `2257ACFFD8A86A88E36DF763B54BA2773B2C29ACAC199CED483F4B7F90CB9513`
- `<LOCAL_ACCOUNT>\OneDrive\Desktop\TKS\observable_geometry\src\observable_geometry\track_b\stability.py`: `D3E95928D28140D1B516A9013B9997FAD00C76F9D850D27C5DEA33FD75A0988D`
- `<LOCAL_ACCOUNT>\OneDrive\Desktop\TKS\observable_geometry\src\observable_geometry\track_b\observability_certificate.py`: `A11FCCF1C5D4A695C347F4D7437D9E63610152A188272A7CA769943F484A216E`
- `<LOCAL_ACCOUNT>\OneDrive\Desktop\TKS\observable_geometry\tests\test_two_sided_audit.py`: `B68E8C3CF1935DBC2A8D5C619D27C399EF6997524792F985E298914EEA879404`
- `<LOCAL_ACCOUNT>\OneDrive\Desktop\TKS\observable_geometry\tests\test_robust_attribution.py`: `A4235EF986E80D0614AE1F8DC4432C1ECA0675D12BA8F34283A517B21D33E5D2`
- `<LOCAL_ACCOUNT>\OneDrive\Desktop\TKS\observable_geometry\tests\test_track_b_forward_error_budget.py`: `DC8EA6068E5F1AC19BE05B40B6A1183F25315C1DC4E5EF1C8F24362D15F81298`
- `<LOCAL_ACCOUNT>\OneDrive\Desktop\TKS\observable_geometry\tests\test_track_b_stability.py`: `5042D1A1A730355DE999E50365453D5B30BB8BD96A484AACD84609AF346D02C5`
- `<LOCAL_ACCOUNT>\OneDrive\Desktop\TKS\observable_geometry\tests\test_observability_certificate.py`: `62094B8EDCFF125EADD170CA5E22CB50B04ADD3C7D3C78A4FAB2082C66C44031`

