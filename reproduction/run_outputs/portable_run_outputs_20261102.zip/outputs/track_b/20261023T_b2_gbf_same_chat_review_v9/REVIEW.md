# Same-chat technical review: GBFs B2 v9

**Review date:** 2026-10-23  
**Recommendation:** HOLD  
**Reviewer status:** Same-chat Codex review. This is not unaffiliated external sign-off and does not pass B2.

## Exact materials

- Frozen specification: `B2-GBF-2026-10-23-v9`
- Specification SHA-256: `f4da4b7bdd59f375eae21ece9f2dd8bb1b433cdff0c8bfdc5d2862e3711afe04`
- Independent verifier: `scripts/research/recompute_gbf_cpu64.py`
- Verifier SHA-256: `6e2387c37051b38ebfb717f29b9c5a2d2ad831ac525da5c75688fa7d990000f6`
- Precision check: `outputs/track_b/20261023T_b2_residual_precision_check/result.json`

## Assessment

The v9 residual rule is mathematically sound. Since `r = sqrt(max(0, 1-rho^2))` has an unbounded derivative as `rho` approaches 1, the cosine tolerance cannot also serve as a useful absolute residual tolerance. The scalar check demonstrates this: `rho64=0.99999996` becomes `rho32=0.99999994`, producing a residual difference of approximately `6.24e-5`. V9 appropriately computes the new residual from the unrounded float64 score and separately replays the original float32 expression to compare with Track A's stored residual.

The verifier's legacy expression matches the production expression in `nominal.py`; it also leaves the production scoring function unimported, checks exact candidate indices/masks/counts, compares cosine/norm values with the frozen tolerances, and keeps outputs outside the sealed Track A directory. Its current checks are syntax/help and scalar arithmetic only. It has not loaded model arrays, recomputed a real score, or been proven to match the sealed result on the full source space.

## Blocking items

1. An unaffiliated reviewer must review this exact v9 specification and the exact verifier hash above. The earlier same-chat review covered v7, and v8 is superseded.
2. After that review and resolution of findings, run the registered independent CPU float64 recomputation on the permitted saved real forward-model artifacts. Inspect and report any ranking mismatch; do not waive it because the score difference is small.
3. Keep B2 in progress and B3 gated until those checks pass. Do not infer physiological source recovery or novelty from this calculation.

**Decision: HOLD.** I found no new mathematical flaw in v9's tolerance correction, but the independent review and full real-artifact check remain outstanding.
