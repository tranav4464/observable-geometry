# B2 WBEN observation-noise specification audit

**Run ID:** `20261023T220000Z_b2_wben_observation_noise_audit`  
**Decision this audit can change:** whether the proposed contact-state adaptation can inherit WBEN's observation-noise settings, and whether the current B2 model interface is sufficiently specified to pass.  
**Inputs:** official WBEN NeurIPS 2025 paper, local copy SHA-256 `2C55F55C187EBC55C4E560F9859D0C11BC809AF22055564F6842218A78AD6EFC`; Section 2.1 (PDF pp. 3–4) and Appendix A.4 (PDF p. 23).  
**Data access:** no project recordings, event rows, synthetic data, or held-out outcomes were accessed in this audit.

## Findings

1. In Section 2.1, WBEN defines EEG observation noise with covariance `P` and iEEG observation noise with covariance `S`; both are treated as known. The unknown parameters optimized by EM are `Phi` and diagonal process covariance `Q`. The paper describes `P` and `S` as measurable from realistic measurement setups; it does not estimate them in the stated M-step.
2. Appendix A.4 gives the real-data fallback used without empty-room recordings: zero-mean multivariate Gaussian EEG noise with standard deviation 1 and iEEG noise with standard deviation 0.1. Both modalities are then downsampled to 50 Hz.
3. The appendix does not state the signal units or a normalization step that maps the recorded EEG/iEEG amplitudes to those two noise scales, nor does it explain whether the values are channelwise, common across channels, or a sensitivity choice. Thus those values do not provide a reproducible, physically calibrated covariance for this repository's microvolt-valued contact-level adaptation.
4. Our proposed model changes WBEN's regional physical leadfield to a learned contact-level map `G` and a contact observation operator. Inheriting `P/S` unchanged would therefore be an unsupported fidelity claim. The current B2 sentence that says to “fit ... noise parameters” also differs from WBEN's fixed-known `P/S` formulation and needs an explicit adaptation rationale and train-only estimation rule before model fitting.

## Decision

Treat the WBEN noise treatment as **partially specified and not directly transferable**. Keep the contact-state model provisional. Before B2 can pass, specify an observation-noise strategy for the adaptation, its units and covariance structure, which quantities are learned from training data or selected in inner validation, safeguards against latent-state/noise non-identifiability, and a fair matched baseline. The strategy must never use held-load target samples or confirmation outcomes. Keep any implementation explicitly labeled WBEN-inspired rather than faithful WBEN reproduction.

## Verification boundary

This source audit resolves what the paper says about its observation covariances. It does not establish the correct noise covariance for the released recordings, identify an optimal adaptation, validate model convergence, or show prediction performance. No signal fitting is authorized by this artifact.

## Primary source

Yang and Liu, “Whole-brain electrophysiological network estimation with scalp EEG and intracranial EEG,” NeurIPS 2025, Section 2.1 and Appendix A.4: <https://papers.nips.cc/paper_files/paper/2025/file/82a6afb1f666daaeec8da4d775452bc7-Paper-Conference.pdf>
