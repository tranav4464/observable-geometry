# B2 candidate preprocessing and score contract

## Session identity

- Run ID (UTC): `20261022T210500Z_b2_preprocessing_score_contract`
- Date/operator: 23 October 2026, Codex
- Gate before work: B2 IN_PROGRESS
- Data/signal access: none; primary documentation and environment metadata only
- Software: foundation environment reports SciPy 1.18.1; GPU environment has no SciPy installed

## Decision this work can change

Select a reproducible anti-alias/resampling candidate for the 50 Hz, final-two-second maintenance window and make the primary metric/uncertainty calculation concrete enough for independent review.

## Evidence

- WBEN Appendix A.4 specifies a 50 Hz target rate but does not provide a digital filter or resampling implementation; source inspection is recorded in `outputs/track_b/20261022T204000Z_b2_maintenance_window_mapping/SESSION.md`.
- The official [SciPy `resample_poly` documentation](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.resample_poly.html) specifies polyphase resampling with a zero-phase low-pass FIR, default Kaiser window `(5.0)`, and constant-zero boundary extension.
- The installed foundation environment reports SciPy `1.18.1`, matching `requirements-foundation.txt`.
- No real signal data, synthetic signal, held-out participant, or model result was read or generated.

## Candidate contract

For each complete 8-second real epoch, use `scipy.signal.resample_poly` with `up=1`, `down=4` for 200 Hz EEG and `down=40` for 2,000 Hz iEEG, leaving the default Kaiser window and constant-zero padding explicit. This yields 400 samples at 50 Hz; crop the final-two-second maintenance interval `[200:300]` only after resampling. Apply no separate high-pass or notch filter. This is a fully stated project preprocessing choice, not a claim that WBEN used this filter. Maintain the acquisition-filter provenance limitation.

Exclude only dataset-flagged artifact trials plus channels with nonfinite or exactly zero-variance training values, with one train-derived channel mask shared by every method. Compute per-channel normalization from training trials only. Define contact-level NRMSE as test RMSE divided by training SD, macro-average equally across contacts and held-load folds within each participant, and use the participant as the uncertainty unit. Primary paired contrast: direct-ridge NRMSE minus state-space NRMSE; also compare with the training-mean baseline. Report all participant-level values and a 95% participant bootstrap interval.

## Limits and unresolved fields

This contract does not resolve the release's contradictory acquisition/filter metadata or prove the chosen resampling reproduces the authors' pipeline. The grouped inner-validation split, matched hyperparameter grid/budget, state-space noise parameterization, missing-target policy, practical effect threshold, and independent review remain open. The candidate is not yet protocol-locked and no model should be fit to confirmation participants.
