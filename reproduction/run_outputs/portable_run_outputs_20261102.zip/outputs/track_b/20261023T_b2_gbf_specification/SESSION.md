# B2 GBFs specification session

## Session decision

Can the active GBFs route be specified precisely enough for an unaffiliated technical reviewer to assess the estimand, equations, output, comparators, and claim boundary before further implementation or outcome-driven iteration?

## Smallest useful work and inputs

- Read the current gate register, project definition, GBFs build plan, frozen Track A protocol, B0 prior-art screen, B1 case audit, current nominal implementation/tests, and sealed MNE/ambiguity outputs.
- No new participant signal samples, held-out outcomes, synthetic neural data, or model fitting were accessed or generated.
- No GPU workload was required; this was specification and code-to-contract review.

## Result

Prepared `docs/track_b/B2_GBF_SPEC.md` with the exact fixed-orientation source family, channel/reference/covariance contract, eigen-support and nullspace behavior, amplitude/polarity nuisance treatment, 20 mm Euclidean candidate rule, top-five/ranked output, descriptive threshold meaning, MNE comparator scope, assumptions, failure conditions, and falsification rules. Prepared `docs/track_b/B2_GBF_INDEPENDENT_REVIEW_PACKET.md` for an unaffiliated reviewer. Reconciled stale route pointers and corrected the B0 screen closeout language.

The result is a **formal specification draft**, not a B2 pass. Independent review remains outstanding, and the independent CPU float64 recomputation against saved real forward-model artifacts is deferred until after that review. No new model-fitting or outcome inspection occurred.

## Evidence and next action

- Active specification: `docs/track_b/B2_GBF_SPEC.md`
- Reviewer packet: `docs/track_b/B2_GBF_INDEPENDENT_REVIEW_PACKET.md`
- Stale route packet is marked historical: `docs/track_b/B2_INDEPENDENT_REVIEW_PACKET.md`
- B0 prior-art screen now accurately records the bounded route decision.

Next: obtain an unaffiliated technical review of this exact specification; resolve blocking findings; then run the predeclared real-artifact CPU float64 independent recomputation and register its evidence. Do not claim novelty or empirical localization accuracy.


## Static code-contract audit addendum

An author-side source-text audit compared `nominal.py` with the B2 equations and output contract without executing the function or reading signal values. The first audit artifact, `code_contract_audit.json`, contains one false check because its checker searched for single-quoted dictionary keys while the implementation uses double quotes. That artifact is preserved. The corrected check in `outputs/track_b/20261023T_b2_gbf_specification_v2/code_contract_audit.json` passes all 11 source-contract checks and records the float32 score-storage and report-layer source-ID/coordinate distinctions. The correction changed only the audit checker, not project code or data.

This remains a static consistency audit, not independent review, numerical recomputation, or evidence of scientific validity. No signal samples, new outcomes, model fitting, or synthetic neural data were accessed or generated.


## Frozen review handoff

A byte-identical review snapshot of `docs/track_b/B2_GBF_SPEC.md` is saved as `outputs/track_b/20261023T_b2_gbf_specification_v2/B2_GBF_SPEC_review_v1.md`. Its SHA-256 is `1b1a4a4bbc0f84b64c93cfcca9fd1f31e0b1e48ad7d673e6a96ba01dd093e7db`; the companion manifest explicitly records that review is pending. The reviewer packet now names this immutable version, so any later edit must receive a new version/hash. This improves reproducibility of the handoff but does not satisfy the independent-review criterion.


## Review specification v2

A requirements audit found that the first draft did not include a hand-worked example or explicitly explain global covariance-scale invariance. Added a two-dimensional symbolic geometry example with exact identical/orthogonal limits and clarified that a positive scalar rescaling of the noise covariance cancels after unit normalization, while covariance-shape changes can alter the cosine. This is algebraic explanation only. The new immutable copy is `outputs/track_b/20261023T_b2_gbf_specification_v3/B2_GBF_SPEC_review_v2.md`, SHA-256 `20cb11c759fedb712cd09699f07443eaed18ab2469c9abb171d044f754d792d6`; its manifest records that review is still pending. Version 1 remains preserved.


## Forward-orientation provenance correction

A metadata-only inspection of the actual pinned FIF found that the raw forward is free-orientation (256 × 24,588), contrary to the earlier shorthand “supplied fixed-orientation forward.” Track A picks 236 good channels, then converts the free solution using MNE 1.13.2 with `surf_ori=True`, `force_fixed=True`, and `use_cps=True`; the derived leadfield is 236 × 8,196, one cortical surface-normal-constrained column per vertex. The exact result and matching input hash are recorded in `outputs/track_b/20261023T_b2_gbf_orientation_audit/orientation_audit.json`. This mismatch was corrected in the active spec and reviewer packet before any independent review. No signal arrays or outcomes were accessed.

The current frozen review spec is `B2-GBF-2026-10-23-v3`, SHA-256 `6a8a2b491d6da2792bd1f149121f82864daf8e73593f37e4b10f41d410dd2c5b`. Versions 1 and 2 remain immutable and superseded. This provenance audit does not replace independent review or score recomputation.
