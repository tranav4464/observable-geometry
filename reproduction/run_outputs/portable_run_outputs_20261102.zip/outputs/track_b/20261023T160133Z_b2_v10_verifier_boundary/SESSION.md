# B2 v10 verifier pre-review validation

**Run ID:** `20261023T160133Z_b2_v10_verifier_boundary`  
**Date:** 2026-10-23  
**Specification:** `B2-GBF-2026-10-23-v10`, SHA-256 `1024c4c80ca31d1375cc13a078bc52ab5b5c58136f8c0ece7debb96f0c3e1062`.

## Result

The standalone verifier help command passed. The metadata-only access-boundary audit passed and confirms that the archive has a `data` member while the verifier source references only `leadfield` and `noise_cov`. It reads ZIP member names and parses source; it does not decompress NPZ members or load arrays.

The combined regression command passed **16 tests**: 3 AST access-guard tests, 4 B2 independent-calculator algebraic tests, and 9 existing nominal implementation tests. Full output is in `validation.json`.

## Limits

No Localize-MI model arrays, recorded EEG samples, new outcomes, model fits, or synthetic neural data were accessed/generated in this validation. It establishes syntax/help, algebraic invariants, and current source-level access restrictions only. It is not unaffiliated review and does not establish numerical agreement on the real forward model.

## Code identity

- Frozen spec: `B2-GBF-2026-10-23-v10`, SHA-256 `1024c4c80ca31d1375cc13a078bc52ab5b5c58136f8c0ece7debb96f0c3e1062`.
- Independent verifier: SHA-256 `58dc22a654cfde5ae7cfd4372fdafb205b60a304ab5687b763d7233d237cec38`.
- Access auditor: SHA-256 `a89bedf64b227ba1ff908e0f27bbc3758f7e4b61e02ae5e15dd028078b6906f9`.
- Access-guard tests: SHA-256 `3e4b6d902e79027138ea47897431b94f12f02b3142712b013d0cd244d5b2b922`.

## Next action

Obtain unaffiliated review of the exact v10 spec and verifier hashes. Resolve findings, then run the registered real-artifact CPU float64 recomputation. B2 remains IN_PROGRESS until both are satisfied.
