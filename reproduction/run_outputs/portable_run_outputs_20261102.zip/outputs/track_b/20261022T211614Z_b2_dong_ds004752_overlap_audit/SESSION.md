# Dong et al. 2026 direct scalp-to-iEEG overlap audit

## Session identity

- Run ID (UTC): `20261022T211614Z_b2_dong_ds004752_overlap_audit`
- Date/operator: 2026-10-22 UTC; Codex
- Gate and status before work: B2, `IN_PROGRESS`; prerequisites B-1, B0 and B1 are `PASS`.
- Git commit / working-tree state: repository has no Git metadata in this checkout; no files were changed before this record was started.
- Environment lock / CPU-GPU: literature-only; no compute used.
- Data and code versions/hashes: no project data or model code accessed. Sources were arXiv:2604.14202v1 (submitted 2026-04-03), arXiv:2605.18897v1 (CAST, submitted 2026-05-17), the 2025 Sensors article by Abdi-Sargezeh et al., and the official NEMAR `on004752` record.

## Decision this work can change

- One decision question: Does the newly identified Dong et al. preprint preempt the proposed held-working-memory-load scalp-to-iEEG challenge, or only generic scalp-to-iEEG reconstruction on the same dataset?
- Why is this the earliest unresolved gate on the critical path? B2 requires the closest direct prior art and a defensible exact target before any B3 model fit.
- Smallest decisive check: inspect the primary preprint's task, input/target, paired data, participant/task split, evaluation and code/data reporting; compare those claims with the official dataset task record and the candidate's held-load estimand.
- Expected artifact: source-grounded audit and updates to B2 specification, method matrix, evidence ledger, decision log and gate register.
- Stop condition: stop the novelty screen for generic reconstruction once a same-dataset direct reconstruction method is verified; retain only a narrower task-specific distinction if the paper does not test it.

## Inputs and leakage check

- Inputs opened/read: `https://arxiv.org/html/2604.14202` (full text and supplement); `https://arxiv.org/abs/2605.18897`; `https://arxiv.org/html/2605.18897`; `https://www.mdpi.com/1424-8220/25/2/494`; `https://nemar.org/dataset/on004752`.
- Metadata, signal, image, or outcome data: public paper text and dataset descriptions only.
- Development or held-out role: literature-only; no participant-level project data or outcomes accessed.
- Could any input reveal a confirmatory outcome? No. No local confirmation event rows, signal samples or labels were opened.
- Allowed transformations / preprocessing: none.

## Prespecified interpretation

- Pass condition: establish the exact overlap and report any split/task details as unreported when the source does not specify them.
- Fail/falsification condition: evidence that the proposed full-load-held-out iEEG estimand is already reported, or that the direct paper cannot be verified as using the dataset/target described.
- What result would change the next decision? Verified same-dataset scalp-to-iEEG reconstruction removes generic model/reconstruction novelty. A held-load claim can remain only as a provisional empirical challenge if no inspected source reports it; absence from this bounded screen is not proof of priority.
- Baselines / negative controls: no model evaluation in this session.

## Execution record

- Exact commands: primary-source searches and opens through the web research tool; no shell/model commands.
- Seeds and configuration: not applicable.
- Warnings, exclusions, failures: the Dong preprint's methods describe an 8:2 non-overlapping train/test partition but do not identify the partition unit in the inspected text; it is unknown whether this is participant-, session-, trial-, or window-level. The preprint labels `ds004752` as visual categorization, while the official NEMAR record calls it a verbal working-memory task. The preprint reports 15 participants in its supplement but 14 after excluding sub-10 in its methods. These are unresolved reporting discrepancies, not proof of leakage or invalid results. No author implementation repository was found in the inspected arXiv record/search.
- Outputs and checksums: `audit.json` in this run folder; source URLs embedded in that file and this record.
- CPU reference and GPU parity evidence: not applicable.
- Independent metric/oracle check: official NEMAR dataset description independently checked the experiment/task identity; no reported model score was recomputed.

## Decision and follow-up

- Outcome: pass for the narrow prior-art fact; inconclusive for exact held-load overlap.
- Interpretation limited to: generic scalp-to-iEEG reconstruction and scalp-only inference on the same dataset are claimed in a 2026 arXiv preprint. The source does not establish that the whole working-memory load was withheld from model fitting, and its split granularity is unspecified. This is an unreviewed preprint claim, not an independently reproduced result.
- Ledger/matrix/protocol updates: add Dong as same-dataset direct prior art; add Abdi-Sargezeh et al. 2025 as cross-subject IED-classification-level translation prior art; keep held-load transfer provisional and non-novel as a method. Do not train/test on the 2026 paper's claims without resolving its protocol and task discrepancies.
- Next earliest gate action: resolve remaining task-level prior art and rewrite the B2 candidate comparison around the exact measurable held-load endpoint and suitable direct baselines; then obtain an independent technical challenge of the contract before B2 can pass.
- Reviewer and review result: external independent review not obtained; no novelty conclusion is approved.

