# B2 prior-art audit: identifiability framing

## Session identity

- Run ID (UTC): `20261022T194134Z_b2_identifiability_prior_audit`
- Gate before work: B2 IN_PROGRESS
- Workspace state: no Git repository metadata available at workspace root
- Environment: read-only source research and project-record edits; no compute workload
- Data: no dataset files opened; no participant metadata, signals, or outcomes accessed

## Decision this work can change

- Decision: whether the project can describe a generic observation-conditioned identifiability framework as its mathematical innovation, and what exact contribution remains eligible for B2.
- Why B2: the task and method contribution are the earliest open scientific gate; B3–B8 depend on B2.
- Smallest decisive check: compare the proposed framing with the recent virtual-iEEG review and primary literature on profile-likelihood identifiability for partially observed dynamical models.
- Stop condition: if the generic concept is already covered, falsify that broad claim and keep only a fully specified, narrower object under review.

## Inputs and access boundary

- Primary sources reviewed: He et al., *Virtual iEEG from Scalp EEG* (arXiv:2608.26998, 2026); Raue et al., *Structural and practical identifiability analysis of partially observed dynamical models by exploiting the profile likelihood* (Bioinformatics, 2009; DOI 10.1093/bioinformatics/btp358); Yang & Liu, WBEN (NeurIPS 2025).
- Sources: [2026 virtual-iEEG review](https://arxiv.org/abs/2608.26998), [Raue et al. 2009](https://pubmed.ncbi.nlm.nih.gov/19505944/), [WBEN official proceedings](https://papers.nips.cc/paper_files/paper/2025/hash/82a6afb1f666daaeec8da4d775452bc7-Abstract-Conference.html).
- No event rows, signals, atlas files, confirmatory data, or synthetic inputs were read or generated.

## Prespecified interpretation

- Pass for the generic novelty framing: primary literature does not already articulate the concept or apply the relevant identifiability methods to partially observed dynamical models.
- Falsification: a source already distinguishes prediction from physical identifiability for scalp-to-intracranial inference, or profile likelihood already addresses identifiability in partially observed dynamical systems.
- Next-decision change: falsify the generic framework claim; require an exact algorithmic difference and task-level comparison before retaining a new-method claim.

## Findings

1. The 2026 review explicitly separates predictability from identifiability for scalp-to-iEEG inference and discusses the limits of unique contact-level waveform recovery, predictive uncertainty, input-dependence controls, and validation. The broad conceptual framing is therefore not novel. The source is a preprint/review, not independent validation of any specific method.
2. Raue et al. (2009) present profile-likelihood analysis for structural and practical identifiability in partially observed dynamical models, including confidence intervals and experiment-planning use. Thus applying generic profile likelihood to WBEN edges would not itself be a mathematical innovation.
3. WBEN is an existing linear-Gaussian state-space model that estimates latent states and connectivity jointly from scalp EEG and iEEG. A WBEN-specific audit may still be useful, but application alone does not establish novelty.
4. A narrower contribution remains untested: an exact algorithm that produces prediction-equivalent ranges for WBEN edge parameters under its joint scalp/iEEG observation model, profiles nuisance parameters, and is checked against participant-held-out real recordings. Its distinctness, estimability, and usefulness are not established; it must not be presented as the selected method until prior art and feasibility are resolved.

## Outcome and follow-up

- Outcome: generic framework novelty FALSIFIED; exact WBEN-specific contribution UNTESTED.
- Claim scope: literature positioning only. No claim is made about model performance, empirical identifiability, or usefulness.
- Records updated: `METHOD_MATRIX.md`, `EVIDENCE_LEDGER.md`, `DECISION_LOG.md`, `B2_FORMAL_SPEC.md`, `MASTER_RESEARCH_PLAN.md`, `PROJECT_DEFINITION.md`, `README.md`, and `REVIEW.html`.
- Next B2 action: specify the exact parameter/target and a real-data split, then screen that precise object against the closest profile-likelihood, prediction-profile, and network-identifiability methods before any implementation or novelty claim.
