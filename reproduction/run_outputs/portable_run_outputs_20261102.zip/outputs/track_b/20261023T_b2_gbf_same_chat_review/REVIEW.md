# Same-chat technical review: active GBFs B2 specification

**Review date:** 2026-10-23  
**Recommendation:** HOLD FOR CHANGES / required evidence  
**Reviewer status:** Same-chat Codex review. This is not unaffiliated external sign-off and does not pass B2.

## Exact materials reviewed

- Frozen specification: `B2-GBF-2026-10-23-v7`
- Frozen copy: `outputs/track_b/20261023T_b2_gbf_specification_v8/B2_GBF_SPEC_review_v7.md`
- SHA-256 verified during review: `3b13c41c59d332c70a81d8903661329e55abe5bc43aefc3116ee8f6698e14908`
- Active spec: `docs/track_b/B2_GBF_SPEC.md`
- Review packet: `docs/track_b/B2_GBF_INDEPENDENT_REVIEW_PACKET.md`
- Implementation: `src/observable_geometry/nominal.py`
- Tests: `tests/test_nominal.py`
- Protocol and records: `docs/FOUNDATION_PROTOCOL.md`, B1 case audit, B2 orientation audit, sealed Track A manifest, and B0 prior-art screen.

## Scope and recommendation

The specification defines a narrow, nominal comparison of single-source, fixed-orientation forward signatures under one participant-specific head model, one channel/reference contract, and one noise covariance. It separates that forward-signature diagnostic from the GBFs inverse. It does not claim that EEG identifies the actual active source, that the pulse artifact is physiological ground truth, or that the score is a calibrated localization error. This scope is appropriate for the present build.

The mathematics is internally consistent: eigenspace whitening followed by unit normalization yields the stated absolute cosine; profiling an unrestricted scalar between unit signatures gives residual `sqrt(1-rho^2)`; and positive global covariance scaling cancels after normalization. The Euclidean 20 mm filter and 0.95/0.99 display values are clearly described as reporting choices, not biological or inferential thresholds. Scherg et al. is explicitly acknowledged as close mathematical prior art, and the specification disclaims novelty for the cosine itself.

I recommend **HOLD FOR CHANGES / required evidence**, not fail or pivot. The bounded GBFs software route is coherent, but two required assurance items are missing. This same-chat assessment cannot satisfy the packet's unaffiliated-review condition.

## Blocking items before B2 passes and B3 proceeds

1. **Unaffiliated technical review of this exact v7 hash is still required.** The reviewer should inspect the estimand, the fixed-orientation derivation, covariance/reference contract, code-to-equation map, prior-art boundary, and interpretation. Record the reviewer's relationship to the implementation and resolve any findings. Do not describe this review as independent sign-off.
2. **Independent CPU float64 recomputation on the saved permitted real forward-model artifacts is still required.** Use a separately written calculation, compare continuous scores and ranked alternatives, predeclare numeric tolerances, and save input/output hashes in a new run directory. Do not alter the sealed Track A release or inspect new signal outcomes.
3. **Keep B3 gated until both items above and any resulting corrections are complete.** This report does not authorize model fitting or a scientific performance claim.

## Nonblocking implementation notes

- The existing function stores pair scores and residuals as float32. The spec correctly requires the new Track B interface to preserve float64 or disclose a downcast; enforce this in B3 and test it against the independent CPU reference.
- Prefer user-facing labels such as “nominal normalized signature similarity” alongside “source distinguishability” so readers do not mistake the cosine for a statistical detection probability. The spec already contains the necessary caveats; this is a presentation safeguard.
- The nine current unit tests cover useful algebraic and input invariants, including global covariance-scale invariance. They are not neural-data simulations and do not establish correctness on the real case.

## Verification performed for this review

- Confirmed the frozen specification hash matches its manifest.
- Ran `tests/test_nominal.py` using `.venv_tracka_clean`: **9 tests passed**.
- Confirmed the current gate register still marks B2 `IN_PROGRESS`; B3–B8 remain `NOT_STARTED`.
- Did not read new signal samples, fit models, generate synthetic neural data, inspect confirmation outcomes, or recompute the real-data score.

## Final decision

**HOLD FOR CHANGES / required evidence.** There is no identified mathematical defect that requires abandoning the GBFs route. B2 is not complete because unaffiliated review and the independent real-artifact CPU float64 recomputation remain outstanding. No new-method or practical-utility claim is supported by this review.
