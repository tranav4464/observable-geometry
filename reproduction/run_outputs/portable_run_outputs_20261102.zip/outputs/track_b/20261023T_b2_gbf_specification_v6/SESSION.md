# B2 specification review freeze v5

- Active route: GBFs reproduction/reverse-engineering and nominal source distinguishability under one verified participant-specific forward model.
- Frozen specification: `B2_GBF_SPEC_review_v5.md`.
- SHA-256: `702c3e8a14ecc36722353cdede3eb7ddda3235cf2e6e9d26170ccec58abe9ac1`.
- Changes from v4: clarified scalar covariance-scale invariance and added a corresponding analytical matrix test.
- Review status: awaiting unaffiliated technical review; no approval implied.
- No signal samples, new outcomes, model fitting, or synthetic neural data were accessed or generated.
