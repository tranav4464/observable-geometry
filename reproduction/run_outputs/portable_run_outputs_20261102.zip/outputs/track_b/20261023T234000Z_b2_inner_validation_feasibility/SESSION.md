# B2 inner-validation split feasibility audit

**Run ID:** `20261023T234000Z_b2_inner_validation_feasibility`  
**Decision this audit can change:** whether model and effective-covariance selection can use whole-trial inner validation without allowing held-load trials into tuning.  
**Inputs:** event TSV metadata only for development participants sub-01 through sub-03. No EDF samples or confirmation event rows were read.

## Candidate split

For each outer held-load fold, the other two loads form the outer training set. Within each session × load stratum, eligible trials (`Artifact == 0`) are sorted by `nTrial` and assigned round-robin to five inner folds. A complete trial belongs to exactly one fold. The same inner trial assignments would be used by every model and every hyperparameter candidate; normalization and all parameter fitting would be recomputed on each inner training partition.

## Result

All inner folds are nonempty in all 9 participant × held-load outer folds. Across the 45 inner folds, validation counts range from 15 to 51 complete trials and inner-training counts from 68 to 185. Both loads in each outer training set contribute to every validation fold for each development participant. Full fold-by-load and session counts are in `inner_validation_counts.json`.

## Interpretation limit

This establishes split feasibility only. It does not establish power, statistical independence of trials, model convergence, suitable hyperparameter values, predictive performance, or confirmatory adequacy. The split is a candidate to freeze before B5; it does not expose or authorize confirmation outcomes.

## Later protocol decision (2026-10-23)

This five-fold within-load random trial split remains a valid check that ordinary trial-level inner folds are nonempty. It is not the active B2 tuning design because it places both training loads in each validation fold and therefore does not test the load-shift behavior targeted by the outer evaluation. The active design is two whole-load inner folds, audited at `outputs/track_b/20261023T_b2_inner_load_holdout_audit/SESSION.md`. Preserve this original result as evidence for the rejected candidate; do not use its five-fold counts to describe the active tuning protocol.
