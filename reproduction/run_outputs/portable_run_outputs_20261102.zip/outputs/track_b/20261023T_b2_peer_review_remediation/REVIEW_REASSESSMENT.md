# B2 peer-review reassessment after protocol revisions

**Recommendation: HOLD FOR CHANGES.** This reassessment was produced by the same-chat AI reviewer that helped prepare the project materials. It is a current technical challenge, not unaffiliated external review, and cannot satisfy B2's independent-review exit criterion.

## Assessment

| Review question | Current judgment | Remaining boundary |
|---|---|---|
| Is the held-load EEG-to-iEEG task useful and clearly defined? | **Yes, as a bounded within-participant benchmark.** It predicts simultaneously recorded, reference-dependent iEEG contact waveforms from scalp EEG at a set size omitted from fitting. The no-input distribution and real-trial scalp-pairing control make the role of scalp input testable. | It is not zero-shot transfer to a new person, source localization, or evidence that a change in load caused a prediction failure. Loads 4/8 are extrapolation in set size; load 6 is interpolation. Report each separately. |
| Does prior art cover close studies and honestly mark overlap, especially Phillips et al.? | **Broad prior art is covered and generic reconstruction novelty is withdrawn.** TF-DiffEEG is now screened from the official IEEE abstract. Phillips is correctly kept as direct dependence-analysis prior art with exact task, target, and split unknown. | Full-method overlap for Phillips and TF-DiffEEG remains unknown. Do not infer absence or priority from unavailable methods. That access gap alone need not block a non-novel benchmark; an outside reviewer should assess the remaining search boundary. |
| Are split, preprocessing, metrics, and leakage controls sound? | **The written design is substantially improved.** Whole-load outer and inner splits, intact-trial grouping, train-only scaling, the empirical no-input comparator, and fixed real-trial pairing permutations are appropriate for this estimand. The `[3.95,5.95)` crop and stated 50 ms support end before the 6 s probe. Participant-level uncertainty and marginal-coverage wording are appropriate. | This is still a specification review. No fitting or code-level invariant verification has occurred. The access boundary is supported by retained documentary logs, not OS-level auditing. B3 must verify the implemented indices, FIR dependency, transform math, unit restoration, and CPU/GPU agreement before any fit. |
| Do the conclusions stay within measured scalp and iEEG signals? | **Yes in the current specification.** It targets recorded contact waveforms and explicitly rejects unique-source, anatomical, causal, arbitrary-thought, and whole-brain claims. | Do not call marginal interval coverage whole-waveform reliability or prediction a recovered neural state. Same-session results do not establish new-session or new-person transfer. |

## Required before model fitting

1. Obtain an unaffiliated technical review of this reconciled packet and current B2 specification; record its recommendation and any blocking changes.
2. If B2 then passes, complete B3's pre-fit mathematical and interface checks against implementation, including filter/window support, flow inverse/Jacobian, fold-local standardization and unit restoration, metric aggregation, and CPU/GPU numerical agreement.
3. Keep the B5 confirmation outcomes unopened until its protocol lock and access preflight pass.

No model fitting is authorized by this reassessment. B2 remains `IN_PROGRESS`. The earlier six-finding report remains at `outputs/track_b/20261023T_b2_peer_review/REVIEW.md` and records the prior spec state; this file assesses the revised written protocol only.
