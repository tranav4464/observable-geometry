# Track B research session record

## Session identity

- Run ID: `20261024_b7_resolution_overlap_audit_v2` (directory date uses local project date; recorded execution timestamp is UTC).
- Date/operator: 24 October 2026 / Codex implementation session.
- Gate and status before work: B7 NOT_STARTED; B4 PIVOT; B5/B6 not activated.
- Git commit / working-tree state: project root is not a Git checkout; files were inspected in the active workspace.
- Environment: Windows, Python 3.12.14, CPU float64; NumPy 2.5.4. Independent check used SciPy 1.18.1.
- Data and code versions/hashes: recorded in `run_manifest.json`; verifier hash is recorded there after the independent check.

## Decision this work can change

- Decision question: Does the B3 forward-signature score present a different model-derived view from the existing MNE PSF summaries, and does available evidence establish researcher decision value?
- Why this was the earliest unresolved applicable gate: B4 had already pivoted the empirical physiology route; B7 can still assess paired model diagnostics without accessing held-out outcomes.
- Smallest decisive check: verify same-model input lineage, pair all source-level metrics, calculate descriptive rank associations, and independently recalculate those statistics.
- Expected artifact: paired source table, descriptive report, independent verification, and a B7 route decision.
- Stop condition: stop the utility claim if no valid independent decision endpoint or analyst evaluation exists.

## Inputs and leakage check

- Inputs opened/read (SHA-256 in `run_manifest.json`): B3 `distinguishability_float64.npz` and manifest; Track A `mne_resolution_summary.npz`, `mne_resolution_report.json`, `prepared_bundle.npz`, `nominal_signature_library.npz`, and manifest; frozen `scripts/run_resolution_baseline.py`.
- Metadata, signal, image, or outcome data: model-derived source scores, coordinates/vertex identifiers for ordering, point-spread summaries, model metadata, and hashes only. No EEG sample, label, held-out outcome, or participant signal array was requested or materialized.
- Development or held-out role: previously sealed, development-only one-participant model artifacts; no held-out role.
- Could any input reveal a confirmatory outcome? No; the analysis contains no such outcome arrays.
- Allowed transformations: pair source-level values after hash and vertex-order verification; compute Spearman rank correlations, medians, and a descriptive top decile.

## Interpretation contract (recorded with the audit; not preregistered)

- Audit checks: same-model lineage and source ordering must verify; an independent rank-statistic implementation should reproduce the descriptive correlations.
- Falsification condition: mismatched bundle, source ordering, dimensions, hashes, or rank statistics.
- What result changes the next decision: evidence of distinct descriptive information can support retaining the report, but analyst utility requires an independent decision study and cannot be inferred from this model comparison.
- Baseline: Track A MNE minimum-norm PSF summaries; no neural-data baseline or synthetic control.

## Execution record

- Commands: `python scripts/research/audit_resolution_overlap.py`; `python scripts/research/verify_resolution_overlap.py`.
- Seeds/configuration: none; deterministic rank statistics, fixed inputs.
- Warnings/exclusions/failures: this was exploratory, not preregistered. No p-values or confidence intervals are reported because source vertices are spatially dependent. The earlier v1 audit is preserved as superseded after v2 added explicit input-lineage cross-checks.
- Outputs: `b7_resolution_overlap_report.json`, `paired_source_metrics.csv`, `run_manifest.json`, and `independent_stat_check.json`.
- CPU/GPU: CPU only; no model fitting or GPU computation.
- Independent metric/oracle check: `scipy.stats.spearmanr` matched all five rank correlations; maximum absolute difference `1.11e-16`.

## Decision and follow-up

- Outcome: exploratory paired model-output audit passed; B7 decision-utility question pivoted.
- Interpretation limited to: one verified sub-01 model and covariance; related but non-identical descriptive resolution views; no analyst utility, physiological validity, population inference, or novelty.
- Ledger/matrix/protocol updates: gate register and active project summaries updated; no confirmatory protocol changed.
- Next earliest gate action: finish local B8 release provenance and prepare the package for unaffiliated external review; do not reopen B5/B6 without a new valid endpoint.
- Reviewer and review result: independent statistic check recorded; no unaffiliated human review of B7 or the full package has occurred.

