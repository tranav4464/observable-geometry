# All-participant paired channel schema audit

## Purpose and decision

Check whether the proposed eight scalp inputs and stable within-participant recorded iEEG contact targets are available across the pinned on004752 release, including participants whose event rows and signal outcomes remain sealed. This determines metadata feasibility only; it does not establish task-trial eligibility or predictive value.

## Data boundary and procedure

- Read only EEG/iEEG `channels.tsv` metadata for all 68 paired sessions in NEMAR on004752 v1.0.0.
- Did not open `events.tsv`, EDF headers or signal payloads, or any result/score file.
- The fixed parser exclusions were applied before calculating eligible-session contact intersections: `sub-06/ses-04` and `sub-14/ses-06`.
- Checked the prespecified common scalp input labels `A1,A2,C3,C4,F3,F4,O1,O2` in every non-excluded paired session.
- Computed each participant's target labels as the intersection of SEEG channel names across that participant's non-excluded sessions.
- Saved SHA-256 hashes for every EEG and iEEG channel table in `channel_schema.json`.

## Results

- 68/68 paired sessions were parsed across all 15 participants.
- All eight candidate scalp inputs are present in every non-excluded session for every participant.
- Each participant has a stable within-participant SEEG label intersection, ranging from 16 contacts (`sub-10`) to 64 contacts (`sub-02`, `sub-04`, `sub-06`, `sub-07`, `sub-09`, `sub-14`, and `sub-15`).
- The two fixed parser exclusions reduce the eligible session counts to six for sub-06 and seven for sub-14; all other participants retain every released paired session.

## Interpretation and limits

This supports channel-schema feasibility for the candidate contact-level task across the released cohort. Label stability does not establish anatomical identity, reference equivalence, signal quality, event-count eligibility, statistical power, within-session stationarity, or prediction performance. Because no event rows were opened, the 30-trial-per-load eligibility criterion for the sealed participants remains unverified and must be applied mechanically only after the B5 protocol lock. This audit does not make the WBEN regional model comparable to the separate contact-state adaptation.

## Reproduction

```powershell
$env:PYTHONPATH = 'src'
.\.venv\Scripts\python.exe scripts\track_b\audit_all_participant_channel_schema.py `
  --output outputs\track_b\<new-run-id>\channel_schema.json
```

The script uses the standard library and reads channel tables only. The captured result is `channel_schema.json` in this run directory.
