# Development-only Harvard–Oxford contact-mapping audit

This metadata-only audit reads electrode coordinates for sub-01 through sub-03 and maps each point to the nearest voxel in the official Nilearn Harvard–Oxford 2 mm maximum-probability cortical and subcortical atlases (25% threshold). It does not load event or neural signal files and does not inspect sub-04 through sub-15.

The dataset calls coordinates MNI but has no `coordsystem.json` identifying the exact template. Therefore every atlas label is provisional and cannot yet be treated as a valid WBEN contact-to-region mapping. See `audit.json` for counts, hashes, and limits, and `contact_mapping.csv` for the row-level audit.
