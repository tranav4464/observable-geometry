# B2 access-boundary guard tests

**Run ID:** `20261023T155842Z_b2_access_guard_tests`  
**Date:** 2026-10-23  
**Decision informed:** Whether the metadata-only access auditor detects the allowed prepared-bundle keys, exposes a recorded-EEG key if referenced by verifier code, and rejects dynamic archive-key access.

## Result

The new guard tests pass together with the existing independent-calculator and nominal-scoring tests: **16 passed**. The three new tests cover allowed model-key detection, detection of `data` as an unexpected key, and rejection of nonliteral keys.

## Scope and limits

These tests operate on small Python source snippets and do not open or emulate a neural data archive. They test the AST key-extraction guard, not runtime archive behavior, the numerical verifier, real-data correctness, or unaffiliated review. The frozen B2 spec and independent verifier were not changed.

## Reproduction

```powershell
$env:PYTHONPATH='src'
.\.venv\Scripts\python.exe -m pytest tests\test_b2_access_boundary.py tests\test_b2_independent_calculator.py tests\test_nominal.py -q
```

Result: `16 passed`.

## Code identity

- Access auditor: `scripts/research/audit_signal_access_boundary.py`, SHA-256 `a89bedf64b227ba1ff908e0f27bbc3758f7e4b61e02ae5e15dd028078b6906f9`.
- New test file: `tests/test_b2_access_boundary.py`, SHA-256 `3e4b6d902e79027138ea47897431b94f12f02b3142712b013d0cd244d5b2b922`.
- Frozen B2 spec remains `B2-GBF-2026-10-23-v9`; hash remains `f4da4b7bdd59f375eae21ece9f2dd8bb1b433cdff0c8bfdc5d2862e3711afe04`.

## Next action

Keep B2 IN_PROGRESS. The access guard supplements but does not replace unaffiliated review or the post-review real-artifact CPU float64 recomputation.
