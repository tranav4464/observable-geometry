# B2 contact-state model interface and identifiability audit

## Session identity

- Run ID (UTC): `20261022T213100Z_b2_contact_state_identifiability_audit`
- Gate before work: B−1, B0, B1 PASS; B2 IN_PROGRESS
- Decision this audit can change: whether the candidate contact-state adaptation can define an identifiable prediction target and noise model without pretending to estimate sensor noise.
- Inputs: published WBEN state/observation equations; B1 unit/reference/alignment audits; B2 contact stability, preprocessing, and candidate split audits.
- Data boundary: no local recordings or event rows, no confirmation participants, no model fitting, no GPU, and no synthetic datasets or signal fixtures.

## Decision question and smallest useful test

Can a state-space baseline be specified so its state is the **recorded iEEG contact signal** that the project predicts, rather than an unobserved biological source plus an unmeasured iEEG sensor-noise component? The smallest useful test is an algebraic identifiability review of the proposed observation model, its units, train/test information flow, and a limiting case. The result is a model-interface proposal only; no empirical performance conclusion follows.

## Audit finding

The current provisional interface writes `z_t = I x_t + e_t` and `y_t = G x_t + v_t`, while allowing both process and observation noise to vary. WBEN's paper instead treats its observation covariances as known. The local dataset does not supply empty-room or per-channel noise calibration, and fixation variability is ongoing brain-plus-instrument signal, not sensor noise. Thus assigning a separate `R_z` to hardware noise, or inheriting WBEN's appendix values without an explicit scale mapping, would overinterpret the data and create an avoidable process/noise allocation choice.

## Candidate interface that removes the unsupported decomposition

For participant `p`, let `z_{r,t} ∈ R^{M_p}` be the recorded common-reference iEEG contact vector and `y_{r,t} ∈ R^8` the eight scalp channels common to all participants, for trial `r` and time `t` in the final two seconds of maintenance. Work in training-only standardized coordinates, retaining the channel means and scales to return predictions in microvolts.

Define the model state to be the recorded target itself during training, `x_{r,t} := z_{r,t}`. Fit an order-2 within-trial VAR to the training target:

`x_{r,t} = A_1 x_{r,t-1} + A_2 x_{r,t-2} + w_{r,t}`.

Fit the training-only scalp observation map:

`y_{r,t} = G x_{r,t} + v_{r,t}`.

Estimate `A_1,A_2,G` by regularized least squares using only paired training trials, with each trial a separate sequence and no lag across trial boundaries. Estimate `Q = Cov(w)` and `R_y = Cov(v)` from training residuals using a prespecified shrinkage rule. Here `Q` is the variability of the recorded target around the fitted time model and `R_y` is the scalp-map residual covariance. Neither is described as calibrated instrument noise. There is no independent iEEG measurement-noise covariance `R_z`: the target is the recorded signal by definition, so its fluctuations and measurement contributions remain part of the target process.

For the order-2 companion state `s_1=[x_1;x_0]`, estimate the joint mean and covariance from the first two standardized target samples of training trials. At test, initialize a fresh causal Kalman filter for each trial, update the lower block with `y_0`, update the joint state with `y_1`, then apply the companion transition and scalp observation updates for later samples. Supply only scalp observations `y_{r,0:t}` and output the posterior mean and conditional covariance of the current contact state. No held-load iEEG enters inference, normalization, feature selection, or hyperparameter choice. The output is a prediction of the recorded reference-dependent contact waveform. It is not an estimate of noise-free neural source activity. Left-pad unavailable FIR history at a trial start with zero in standardized coordinates, equivalent to the training mean.

In companion form, `s_t=[x_t;x_{t-1}]`, `F=[[A_1,A_2],[I,0]]`, `H=[G,0]`, and `Q_s=[[Q,0],[0,0]]`. The process covariance is positive semidefinite and singular by construction. The current `fit_wben_k1` validation requires a positive-definite process covariance and is therefore not reusable unchanged for this order-2 contact adaptation. Implement the adaptation in a separate module with explicit semidefinite-noise support and keep the paper-faithful WBEN reference unchanged.

This is a transparent **WBEN-informed contact-state Kalman adaptation**, not faithful WBEN: it uses an atlas-free target, a learned cross-modal map, observed-state least squares rather than WBEN's joint latent-state EM, and an explicitly effective residual covariance. The model is therefore a baseline/challenge candidate, not a novelty claim. If retained, its component should remain separate from the paper-faithful WBEN implementation.

## Required matched comparisons and falsifiers

All methods receive identical scalp channels, training trials, target contacts, preprocessing, and nested whole-load validation assignments:

1. Training-mean prediction per target contact.
2. Contemporaneous multi-output ridge regression `z_t <- y_t`.
3. Causal finite-lag ridge regression from a prespecified/tuned scalp history to `z_t`, so the state-space method is not compared only with a stateless predictor.
4. The contact-state Kalman adaptation above.

Select all regularization and allowed lag settings within the same inner leave-one-source-load-out folds. Exclude flagged trials using the dataset artifact field and exclude channels only by a training-derived rule shared across methods. A positive held-load score is not useful by itself: the state-space model must beat the training-mean predictor to establish predictive signal and the causal finite-lag ridge baseline to establish added value over direct temporal regression. Failure on either comparison removes the corresponding claim.

## Limiting and failure cases

- If the scalp map carries no target-relevant information and training innovations are uninformative, the filter should revert toward its dynamics prior; the held-load prediction must not be described as scalp-derived evidence.
- If `G` is rank deficient, many target directions are not observed directly by the scalp channels. The posterior covariance should expose uncertainty; a low pointwise RMSE in one contact cannot establish spatial uniqueness.
- If the held-load distribution changes the target dynamics or the scalp map, the learned stationary model may fail. This is an intended falsifier of cross-load transport, not grounds to retune on the held load.
- If training-derived covariance estimates are singular or unstable, the run must report a fit failure or use a prespecified shrinkage rule; no fallback may be selected by test performance.
- Since the state is the recorded signal, no result from this model estimates a reference-independent voltage, an anatomical source, unrecorded tissue, or the latent whole-brain state.

## Current disposition

This interface resolves the *conceptual* noise-meaning problem by folding uncalibrated target variability into the recorded-target process, but it does not yet establish numerical identifiability or useful prediction. The proposed operational contract now specifies VAR order, candidate ridge grids, windowing, target metric, and participant-level uncertainty. The exact contact/channel eligibility rule, shrinkage implementation/version, numerical fit-failure tolerances, confidence-interval adequacy, and independent review remain open. The foundation and GPU virtual environments do not currently include scikit-learn, so a Ledoit–Wolf dependency must be pinned and verified or replaced by a separately audited implementation before B3. No model has been fit. Do not implement this adaptation as a Track B result until the full B2 contract is independently challenged.

## Primary source

Yang and Liu, “Whole-brain electrophysiological network estimation with scalp EEG and intracranial EEG,” NeurIPS 2025, Section 2.1 and Appendix A.4: <https://papers.nips.cc/paper_files/paper/2025/file/82a6afb1f666daaeec8da4d775452bc7-Paper-Conference.pdf>
