# Source-code audit: on004752 coordinate pipeline

Question: what does the original dataset authors’ public code establish about electrode normalization and atlas labeling, and does it fully define WBEN’s Harvard–Oxford contact map?

## Procedure

Reviewed the pinned original MATLAB localization script, FieldTrip 20200315 `ft_volumenormalise.m`, SPM’s template documentation, and the official NeurIPS 2025 WBEN paper. This was a code/documentation audit only. No dataset signals, event rows, or confirmation-participant files were read. No synthetic data were created.

## Finding

The original source script normalizes each subject’s ACPC MRI nonlinearly with SPM12, applies FieldTrip’s `individual2sn` transform to electrode and channel coordinates, marks them as MNI, then assigns Brainnetome MPM labels using maximum voxel count. FieldTrip 20200315 defaults this call to SPM12 OldNorm `T1.nii` when no template is supplied. SPM documents that image as derived from the linear ICBM152 T1 average at 2-mm resolution with 8-mm smoothing.

This recovers the dataset-author localization pipeline. It does not prove row-by-row identity with every coordinate in the distributed BIDS tables. It also does not recover WBEN’s exact Harvard–Oxford contact-to-region map, including the atlas image/space conversion, contact assignment target, tie handling, distance cutoff, and out-of-atlas rule.

## Decision

Correct the project records: the dataset-side normalization template is no longer an unknown. Keep WBEN’s HO map unresolved; the later coordinate-space review withdraws the 374/760 Nilearn point lookup as invalid evidence. B2 remains open; no model fitting on confirmation data.

Line-referenced details and source permalinks: `source_coordinate_pipeline.json`.