# B2 independent calculator analytical tests

Four analytical unit tests passed for the standalone verifier. They check exact duplicate and orthogonal sensor signatures, source-index tie breaking, covariance global-scale invariance, float64 score output, and rejection of leadfield components outside the supported covariance subspace. These are small algebraic matrices and coordinates, not simulated or recorded EEG.

The real Localize-MI model arrays were not read and the real score was not recomputed. The unaffiliated review of B2 v9 is still outstanding.
