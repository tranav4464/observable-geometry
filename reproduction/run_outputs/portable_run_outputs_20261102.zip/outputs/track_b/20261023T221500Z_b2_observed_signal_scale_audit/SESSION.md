# Invalid first-pass signal-scale audit

**Run ID:** `20261023T221500Z_b2_observed_signal_scale_audit`  
**Status:** INVALID; do not use the reported scale values.

The first version multiplied `mne.io.Raw.get_data()` by `1e6` while treating its values as volts. In this release the EDF physical-dimension fields are blank, so MNE reports source units as `n/a` and returns the numeric EDF values without that conversion. The paired BIDS `channels.tsv` files declare `μV`. Applying the extra multiplier inflated every reported standard deviation by one million.

The JSON is retained as a failed run to preserve the audit trail. It is superseded by `outputs/track_b/20261023T223500Z_b2_observed_signal_scale_audit_v2/`, which checks EDF-source unit metadata and channel-table units before summarizing the real recordings.
