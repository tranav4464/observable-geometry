# Independent Track A review, 22 October 2026

Verdict: substantial working foundation, but not defect-free or fully closed for release. No production source or sealed result was changed during this review.

## Confirmed findings

1. Release snapshot and source manifest omit tests/. Inspected the actual sealed ZIP and manifest: both contain zero test files. scripts/verify_foundation.py:108-112 enumerates src, scripts, docs and selected root files only. The frozen release cannot reproduce its claimed test suite by itself, and test edits are outside source integrity checks. Include tests and verify required snapshot inventory.
2. Seal operation can replace a sealed manifest. scripts/verify_foundation.py:254-276 writes the ZIP and manifest unconditionally when --seal is selected; ZIP uses write mode at line 117. The runner's sealed-output guard does not protect direct invocation. Require a fresh run ID and reject resealing before writes. This was confirmed by code inspection; the accepted release was not overwritten.
3. Dashboard axis misidentifies covariance eigencomponents as channels. scripts/complete_track_a.py:65-66 labels channel order/index, but lines 137-146 export eigenbasis-whitened values. Direct computation yields 235 plotted components for 236 sensors. Label whitened component index, or explicitly transform to a documented sensor-space representation. Similarity calculations are not invalidated by this labeling defect.
4. Validation has incomplete semantic checks. In-memory probes on actual saved artifacts show validate_signature_arrays accepts threshold metadata changed from 0.95 to 0.50; the full validator recomputes 0.95 edges but omits threshold metadata comparison. validate_empirical_rows also accepts negative localization errors with matching negative summaries. These probes did not alter saved files. Require fixed protocol values, nonnegative distances, and expected unique site identities.
5. Empirical result consistency checks are incomplete. scripts/verify_foundation.py:207-230 checks pair ranges and CSV row count, but does not compare CSV values/identities to JSON or recompute the reported Pearson/Spearman correlations. This is a validator coverage finding, not evidence that current correlations or CSV values are wrong. Add full field comparisons and independently recomputed aggregates.

## Checks and limits

All 20 existing unit tests passed again. Full sealed-run verification also passed: 236 channels, 8,196 vertices, six primary sites, eleven runs, and 912 threshold edges. The faults above show why passing the existing tests cannot certify absence of defects.

Scientific limits remain: one participant, six primary sites, dependent pairs, stimulation-artifact proxy rather than physiological source truth, unresolved fixed-normal orientation compatibility, one nominal head model, and no demonstrated new-method novelty. These are separate from the software defects.

Recommended gate: close snapshot/sealing and validation gaps, correct plot labeling, add regression tests for each finding, then produce a new uniquely named sealed release. Track B literature and feasibility work can proceed, but this release should not be described as flawless or scientifically validated.

