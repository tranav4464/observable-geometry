# Track A release remediation check, 22 October 2026

**Result:** the new `outputs/tracka_remediated_20261022` run completed under the clean pinned Python 3.12 environment. All 25 unit tests passed, the full pipeline exited 0, and seal and post-seal validation both returned `PASS`. This is an engineering release check, not a claim of physiological validation or Track B novelty.

| Earlier finding | Repair and direct evidence | Status |
|---|---|
| Snapshot omitted tests | `_source_files()` includes `tests/`; independent ZIP inspection found three test files including `tests/test_validation.py`. | Repaired in new release |
| Direct reseal could overwrite | `validate(..., seal=True)` rejects an existing manifest or snapshot before artifact writes; regression test exercises the existing-manifest case. | Repaired for tested path |
| Whitened components labeled channels | Generator and rendered new report say `Whitened component index`; independent string check passed. | Repaired |
| Threshold and negative distances accepted | Frozen `.95` threshold and nonnegative site error checks added; regression tests reject `.50` and a negative error. Duplicate site identity rejection added. | Repaired for tested probes |
| CSV/JSON and correlations weakly checked | Validator compares each CSV identity and value to JSON and recomputes Pearson and Spearman from pair rows; new full run passed. | Repaired in new validator; targeted corruption tests for these checks still desirable |

**Release boundary closed in the successor run:** `outputs/tracka_release_20261022_v2` contains the updated verifier and 27 passing tests. The verifier now checks every ZIP member against the sealed manifest by default, without requiring the live working tree to remain frozen. `--check-worktree` is an optional stricter drift check. The full successor pipeline, sealing and post-seal verification returned `PASS`; direct resealing exited with an error and left the manifest hash unchanged. Gate B-1 can therefore pass for engineering foundation integrity. The archive still includes a historical copy of Track B notes; those are provenance captured at seal time, not live release dependencies.

**Scientific limits unchanged:** sub-01 only, six stimulation artifact sites, no independently tested source recoverability or physiological cortical validation.
