# B4 matched 224-channel development reproduction session

## Session identity
- Run ID: 20261023T192900Z_b4_matched_224_reproduction (UTC)
- Date/operator: 2026-10-23 UTC / Codex
- Gate: B4, status IN_PROGRESS; prerequisites B0–B3 are recorded PASS.
- Source revision: no root Git repository is present. Script SHA-256: 12E6B941CCA85EC3D42C889AAEA6C700E84DA4D368CF73D074C73887FFF47FF1.
- Sealed Track A manifest SHA-256: DC34E97C55AA7B0F3349191743293F1850E9F286B7302FB3A6B17BFFE7A6902B.
- Environment: `.venv_tracka_clean`, CPU; no GPU.

## Decision this run can change
- Question: Does a fresh rerun reproduce the six-site development comparison using its actual 224-channel intersection, and therefore clarify whether the earlier 236-channel site-association calculation was mismatched?
- Why now: The B4 audit caught that the sealed B2/B3 signature and MNE resolution outputs use 236 channels, while the existing empirical comparison uses the 224-channel intersection across all sub-01 runs. The earlier B4 site-level joins are therefore marked invalid for method comparison.
- Smallest decisive check: Re-run the existing empirical development script in a new output directory, then compare its six-site prediction-versus-observation table and primary metrics to sealed Track A values.
- Output: fresh, unsealed real-data development outputs in `outputs/20261023T192900Z_b4_matched_224_reproduction`, hashes, and a parity report. Track A stays untouched.
- Stop condition: stop if channel order/reference/covariance cannot be confirmed or exact reproduction fails; retain the failure and do not reinterpret the earlier mismatched associations.

## Data and leakage boundary
- Development-only participant: Localize-MI sub-01. All 11 sub-01 runs are already exposed by the sealed Track A analysis; this is not held-out or confirmatory data.
- This run reopens only the previously exposed sub-01 EEG epoch samples, event metadata, channel metadata, stimulation contacts, head transform and forward model needed by `scripts/run_empirical_evaluation.py`.
- No sub-02 through sub-07 signal samples or outcome results will be read. No synthetic data or synthetic neural signals will be generated.
- The primary six 1 mA stimulation sites, common 224-channel intersection, average reference, baseline covariance with 10% shrinkage, and fixed −2 to +2 ms pulse-artifact window follow the existing script unchanged. The earlier draft of this session said “20 ms”; that was a documentation error and is corrected here.

## Prespecified interpretation
- Pass: the fresh six-site CSV matches the sealed Track A `predicted_observed_similarity.csv` to absolute tolerance `1e-12`, site identities/counts and channel count match, and the report retains the pulse-artifact and single-participant limitations.
- Fail: any mismatch beyond tolerance, missing target mapping, different input boundary, or code path that touches participants outside sub-01.
- Baselines: the existing GBFs artifact-localization and MNE artifact-localization outputs are descriptive same-case comparators. Do not combine 224-channel empirical outputs with 236-channel B2/MNE summaries as if matched. No confidence interval, p-value, threshold tuning, decision utility, or novelty claim is planned.
- Result can change the decision about whether the six-site pairwise comparison is reproducible under its own declared 224-channel contract. It cannot validate population behavior or endogenous source recovery.

## Execution record
- Exact command executed: `$env:TRACKA_RUN_ID='20261023T192900Z_b4_matched_224_reproduction'; $env:PYTHONPATH='src;scripts'; .\.venv_tracka_clean\Scripts\python.exe scripts\run_empirical_evaluation.py`
- The run completed in `.venv_tracka_clean` on CPU and wrote a new output directory; no sealed Track A output was modified.
- Output report: `empirical_evaluation_report.json`; report SHA-256 `7b4ed282966b22f3420626f91a2bd2821454e4c74a611f5009b693c7547fe16f`.
- Pairwise CSV: `predicted_observed_similarity.csv`; SHA-256 `d3808dfb22318df1fc8fab6a06c4e20c8a059622dca93465029da2619396f50b`.
- The CSV is byte-for-byte identical to the sealed Track A pairwise CSV. `scripts/research/verify_channel_reproduction.py` independently verifies saved-output parity and records `PASS_DERIVED_OUTPUT_REPRODUCTION_ONLY` in `b4_reproduction_audit.json`.
- The report records 224 channels, six sites, 15 dependent pairs, Pearson `r=0.34516194307310066`, Spearman `rho=0.3428571428571428`, and median GBFs/MNE peak distances of 19.7583/28.3044 mm. These are descriptive single-participant pulse-artifact results only.
- The verification script reads only saved derived reports/CSVs; it does not read recording samples. The preceding empirical rerun did reopen already-exposed sub-01 EEG epochs. No sub-02–07 signal outcomes were opened.
